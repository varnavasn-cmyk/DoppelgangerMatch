import createMiddleware from "next-intl/middleware";

export default createMiddleware({
  locales: ["en", "fr", "es"],
  defaultLocale: "en",
  localePrefix: "as-needed",
});

export const config = {
  matcher: [
    "/((?!_next|.*\\..*).*)", // Match all routes except _next and static files
  ],
};

// middleware.ts
// import type { NextRequest } from 'next/server';
// import createMiddleware from 'next-intl/middleware';
// import { routing } from './i18n/routing';

// const intlMiddleware = createMiddleware(routing);

// export default function middleware(request: NextRequest) {
//   // Log for debugging on VPS
//   console.log('🔍 Middleware:', {
//     path: request.nextUrl.pathname,
//     locale: request.cookies.get('NEXT_LOCALE')?.value,
//     googtrans: request.cookies.get('googtrans')?.value,
//   });

//   const response = intlMiddleware(request);

//   // Ensure cookies are set in response
//   const locale = request.cookies.get('NEXT_LOCALE')?.value || 'en';
//   response.cookies.set('NEXT_LOCALE', locale, {
//     path: '/',
//     maxAge: 31536000,
//     sameSite: 'lax',
//   });

//   return response;
// }

// export const config = {
//   matcher: ['/', '/(en|fr|es)/:path*', '/((?!api|_next|_vercel|.*\\..*).*)'],
// };
