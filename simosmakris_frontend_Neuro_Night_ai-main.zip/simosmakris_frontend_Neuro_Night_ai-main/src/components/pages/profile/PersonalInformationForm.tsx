"use client";

import type React from "react";
import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Calendar } from "lucide-react";
import {
  useGetMeUserQuery,
  useUpdateUserProfileMutation,
} from "@/redux/features/users/usersApi";
import { toast } from "sonner";

// 🌍 Country List
const countries = [
  "Afghanistan",
  "Albania",
  "Algeria",
  "Andorra",
  "Angola",
  "Argentina",
  "Armenia",
  "Australia",
  "Austria",
  "Azerbaijan",
  "Bahamas",
  "Bahrain",
  "Bangladesh",
  "Barbados",
  "Belarus",
  "Belgium",
  "Belize",
  "Benin",
  "Bhutan",
  "Bolivia",
  "Bosnia and Herzegovina",
  "Botswana",
  "Brazil",
  "Brunei",
  "Bulgaria",
  "Burkina Faso",
  "Burundi",
  "Cambodia",
  "Cameroon",
  "Canada",
  "Cape Verde",
  "Central African Republic",
  "Chad",
  "Chile",
  "China",
  "Colombia",
  "Comoros",
  "Congo",
  "Costa Rica",
  "Croatia",
  "Cuba",
  "Cyprus",
  "Czech Republic",
  "Denmark",
  "Djibouti",
  "Dominica",
  "Dominican Republic",
  "East Timor",
  "Ecuador",
  "Egypt",
  "El Salvador",
  "Equatorial Guinea",
  "Eritrea",
  "Estonia",
  "Ethiopia",
  "Fiji",
  "Finland",
  "France",
  "Gabon",
  "Gambia",
  "Georgia",
  "Germany",
  "Ghana",
  "Greece",
  "Grenada",
  "Guatemala",
  "Guinea",
  "Guinea-Bissau",
  "Guyana",
  "Haiti",
  "Honduras",
  "Hungary",
  "Iceland",
  "India",
  "Indonesia",
  "Iran",
  "Iraq",
  "Ireland",
  "Israel",
  "Italy",
  "Jamaica",
  "Japan",
  "Jordan",
  "Kazakhstan",
  "Kenya",
  "Kiribati",
  "North Korea",
  "South Korea",
  "Kuwait",
  "Kyrgyzstan",
  "Laos",
  "Latvia",
  "Lebanon",
  "Lesotho",
  "Liberia",
  "Libya",
  "Liechtenstein",
  "Lithuania",
  "Luxembourg",
  "Macedonia",
  "Madagascar",
  "Malawi",
  "Malaysia",
  "Maldives",
  "Mali",
  "Malta",
  "Marshall Islands",
  "Mauritania",
  "Mauritius",
  "Mexico",
  "Micronesia",
  "Moldova",
  "Monaco",
  "Mongolia",
  "Montenegro",
  "Morocco",
  "Mozambique",
  "Myanmar",
  "Namibia",
  "Nauru",
  "Nepal",
  "Netherlands",
  "New Zealand",
  "Nicaragua",
  "Niger",
  "Nigeria",
  "Norway",
  "Oman",
  "Pakistan",
  "Palau",
  "Panama",
  "Papua New Guinea",
  "Paraguay",
  "Peru",
  "Philippines",
  "Poland",
  "Portugal",
  "Qatar",
  "Romania",
  "Russia",
  "Rwanda",
  "Saint Kitts and Nevis",
  "Saint Lucia",
  "Saint Vincent and the Grenadines",
  "Samoa",
  "San Marino",
  "Sao Tome and Principe",
  "Saudi Arabia",
  "Senegal",
  "Serbia",
  "Seychelles",
  "Sierra Leone",
  "Singapore",
  "Slovakia",
  "Slovenia",
  "Solomon Islands",
  "Somalia",
  "South Africa",
  "South Sudan",
  "Spain",
  "Sri Lanka",
  "Sudan",
  "Suriname",
  "Swaziland",
  "Sweden",
  "Switzerland",
  "Syria",
  "Taiwan",
  "Tajikistan",
  "Tanzania",
  "Thailand",
  "Togo",
  "Tonga",
  "Trinidad and Tobago",
  "Tunisia",
  "Turkey",
  "Turkmenistan",
  "Tuvalu",
  "Uganda",
  "Ukraine",
  "United Arab Emirates",
  "United Kingdom",
  "United States",
  "Uruguay",
  "Uzbekistan",
  "Vanuatu",
  "Vatican City",
  "Venezuela",
  "Vietnam",
  "Yemen",
  "Zambia",
  "Zimbabwe",
];

export function PersonalInformationForm() {
  const { data, isLoading, error } = useGetMeUserQuery({});
  const [updateProfile, { isLoading: isUpdating }] =
    useUpdateUserProfileMutation();
  const user = data?.data;

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    number: "",
    birthDate: "",
    country: "",
    gender: "" as "Male" | "Female" | "Other" | "",
  });

  // ✅ FIXED: Corrected birthDate reference & added validation
  useEffect(() => {
    if (user) {
      const birthDateValue =
        user?.Profile?.birthDate && !isNaN(Date.parse(user.Profile.birthDate))
          ? new Date(user.Profile.birthDate).toISOString().split("T")[0]
          : "";

      setFormData({
        name: user?.fullName || "",
        email: user?.email || "",
        number: user?.Profile?.number || "",
        birthDate: birthDateValue,
        country: user?.Profile?.country || "",
        gender: user?.Profile?.gender || "",
      });
    }
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const file = fileInputRef.current?.files?.[0];

      const validDate = formData.birthDate
        ? new Date(formData.birthDate).toISOString()
        : "";

      const profileData = {
        name: formData.name,
        number: formData.number,
        gender: formData.gender as "Male" | "Female" | "Other",
        birthDate: validDate,
        country: formData.country,
      };

      if (file) {
        const formDataWithFile = new FormData();
        formDataWithFile.append("file", file);
        Object.keys(profileData).forEach((key) =>
          formDataWithFile.append(
            key,
            profileData[key as keyof typeof profileData]
          )
        );
        await updateProfile(formDataWithFile).unwrap();
      } else {
        await updateProfile(profileData).unwrap();
      }

      toast.success("Profile updated successfully");
    } catch (err) {
      toast.error("Failed to update profile");
      console.error(err);
    }
  };

  const handleChangePhotoClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith("image/")) {
        toast.error("Please select an image file");
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        toast.error("Image size should be less than 5MB");
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);

      toast.success(
        "Photo selected. Click 'Save Change' to update your profile."
      );
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-cyan-400">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-red-400">Error loading user data</div>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold text-cyan-400 mb-6">
        Personal Information
      </h1>

      <form onSubmit={handleSubmit}>
        <div className="bg-[#0f1420] border border-cyan-500/30 rounded-2xl p-8">
          <p className="text-center text-gray-400 text-sm mb-8">
            Upload your Personal and account Information
          </p>

          <div className="grid grid-cols-1 lg:grid-cols-[200px_1fr] gap-8">
            {/* Avatar Section */}
            <div className="flex flex-col items-center gap-3">
              <Avatar className="w-32 h-32">
                <AvatarImage
                  src={
                    avatarPreview || user?.profilePic || "/placeholder-user.jpg"
                  }
                  alt={formData?.name}
                  className="w-32 h-32 object-cover rounded-full"
                />
                <AvatarFallback className="bg-gray-700 text-white text-2xl">
                  {formData?.name
                    ?.split(" ")
                    .map((n) => n[0])
                    .join("")
                    .toUpperCase() || "U"}
                </AvatarFallback>
              </Avatar>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />
              <button
                type="button"
                onClick={handleChangePhotoClick}
                className="text-cyan-400 text-sm hover:text-cyan-300 transition-colors"
              >
                Change Photo
              </button>
            </div>

            {/* Input Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Name */}
              <div className="space-y-2">
                <Label htmlFor="name" className="text-white text-sm">
                  Full Name
                </Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  className="bg-[#1a1f2e] border-gray-700 text-white focus:border-cyan-500"
                />
              </div>

              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email" className="text-white text-sm">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  disabled
                  className="bg-[#1a1f2e] border-gray-700 text-gray-400 cursor-not-allowed"
                />
              </div>

              {/* Birth Date */}
              <div className="space-y-2">
                <Label htmlFor="birthDate" className="text-white text-sm">
                  Date of Birth
                </Label>
                <div className="relative">
                  <Input
                    id="birthDate"
                    type="date"
                    value={formData.birthDate}
                    onChange={(e) =>
                      setFormData({ ...formData, birthDate: e.target.value })
                    }
                    className="bg-[#1a1f2e] border-gray-700 text-white focus:border-cyan-500 pr-10"
                  />
                  <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
                </div>
              </div>

              {/* Country */}
              <div className="space-y-2">
                <Label htmlFor="country" className="text-white text-sm">
                  Country
                </Label>
                <Select
                  value={formData.country}
                  onValueChange={(value) =>
                    setFormData({ ...formData, country: value })
                  }
                >
                  <SelectTrigger className="bg-[#1a1f2e] border-gray-700 text-white focus:border-cyan-500">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1f2e] border-gray-700 max-h-[300px]">
                    {countries.map((country) => (
                      <SelectItem
                        key={country}
                        value={country}
                        className="text-white hover:bg-gray-700 focus:bg-gray-700"
                      >
                        {country}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Phone Number */}
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="number" className="text-white text-sm">
                  Phone Number
                </Label>
                <Input
                  id="number"
                  type="tel"
                  value={formData.number}
                  onChange={(e) =>
                    setFormData({ ...formData, number: e.target.value })
                  }
                  className="bg-[#1a1f2e] border-gray-700 text-white focus:border-cyan-500"
                  placeholder="+880 1712345678"
                />
              </div>

              {/* Gender */}
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="gender" className="text-white text-sm">
                  Gender
                </Label>
                <Select
                  value={formData.gender}
                  onValueChange={(value) =>
                    setFormData({
                      ...formData,
                      gender: value as "Male" | "Female" | "Other",
                    })
                  }
                >
                  <SelectTrigger className="bg-[#1a1f2e] border-gray-700 text-white focus:border-cyan-500">
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1f2e] border-gray-700">
                    <SelectItem
                      value="Male"
                      className="text-white hover:bg-gray-700 focus:bg-gray-700"
                    >
                      Male
                    </SelectItem>
                    <SelectItem
                      value="Female"
                      className="text-white hover:bg-gray-700 focus:bg-gray-700"
                    >
                      Female
                    </SelectItem>
                    <SelectItem
                      value="Other"
                      className="text-white hover:bg-gray-700 focus:bg-gray-700"
                    >
                      Other
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end items-center mt-6">
          <Button
            type="submit"
            disabled={isUpdating}
            className="bg-cyan-500 hover:bg-cyan-600 text-white px-8"
          >
            {isUpdating ? "Saving..." : "Save Change"}
          </Button>
        </div>
      </form>
    </div>
  );
}
