/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import React, { useState, useEffect } from "react";
import { useTranslations } from "use-intl";

interface NavItem {
  id: string;
  title: string;
  href: string;
}

const TermsConditions: React.FC = () => {
  const [activeSection, setActiveSection] = useState<string>("");
  const t = useTranslations("Terms&Conditions");

  const navItems: NavItem[] = React.useMemo(
    () => [
      { id: "introduction", title: t("section1.title"), href: "#introduction" },
      {
        id: "intellectual-property-rights",
        title: t("section2.title"),
        href: "#intellectual-property-rights",
      },
      {
        id: "acceptable-use",
        title: t("section3.title"),
        href: "#acceptable-use",
      },
      {
        id: "registration-and-accounts",
        title: t("section4.title"),
        href: "#registration-and-accounts",
      },
      {
        id: "suspension-and-cancellation",
        title: t("section5.title"),
        href: "#suspension-and-cancellation",
      },
      {
        id: "services-and-payments",
        title: t("section6.title"),
        href: "#services-and-payments",
      },
      { id: "your-content", title: t("section7.title"), href: "#your-content" },
      {
        id: "limited-warranties",
        title: t("section8.title"),
        href: "#limited-warranties",
      },
      {
        id: "limitations-of-liability",
        title: t("section9.title"),
        href: "#limitations-of-liability",
      },
      { id: "indemnity-1", title: t("section10.title"), href: "#indemnity-1" },
      { id: "indemnity-2", title: t("section11.title"), href: "#indemnity-2" },
      {
        id: "breaches-of-terms",
        title: t("section12.title"),
        href: "#breaches-of-terms",
      },
      {
        id: "third-party-websites",
        title: t("section13.title"),
        href: "#third-party-websites",
      },
      { id: "trademarks", title: t("section14.title"), href: "#trademarks" },
      { id: "variations", title: t("section15.title"), href: "#variations" },
      {
        id: "governing-law-and-jurisdiction",
        title: t("section16.title"),
        href: "#governing-law-and-jurisdiction",
      },
      { id: "our-details", title: t("section17.title"), href: "#our-details" },
    ],
    []
  );

  useEffect(() => {
    const handleScroll = () => {
      const sections = navItems.map((item) => document.getElementById(item.id));
      const scrollPosition = window.scrollY + 100;

      for (let i = sections.length - 1; i >= 0; i--) {
        const section = sections[i];
        if (section && section.offsetTop <= scrollPosition) {
          setActiveSection(navItems[i].id);
          break;
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [navItems]);

  // const scrollToSection = (sectionId: string) => {
  //   const element = document.getElementById(sectionId);
  //   if (element) {
  //     element.scrollIntoView({ behavior: "smooth" });
  //   }
  // };

  const scrollToSection = (sectionId: string) => {
    if (typeof window !== "undefined") {
      // check browser
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
  };

  return (
    <div className="grid grid-cols-2 lg:grid-cols-8 gap-4 ">
      {/* Sidebar Navigation */}
      <div className="lg:col-span-2">
        <div className="sticky top-8 ">
          <nav className="space-y-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`block w-full leading-none text-left font-poppins px-2 text-white  py-2 transition-all duration-100 ${
                  activeSection === item.id
                    ? "  border-l-2 border-primary text-xl font-bold pl-4"
                    : "text-[18px] font-normal hover:text-teal-400 hover:bg-slate-700/50"
                }`}
              >
                {item.title}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:col-span-6 border-l-2 border-[rgba(2,204,216,0.2)] pl-8">
        <div className="space-y-15">
          <section id="introduction">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section1.subTitle")}
            </h2>
            <ol className="text-white font-poppins text-lg font-light leading-normal mt-6 space-y-2">
              <li>{t("section1.li1")}</li>
              <li>{t("section1.li2")}</li>
              <li>{t("section1.li3")}</li>
              <li>{t("section1.li4")}</li>
              <li>{t("section1.li5")}</li>
            </ol>
          </section>
          <section id="intellectual-property-rights">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section2.subTitle")}
            </h2>
            <ol className="text-white font-poppins text-lg font-light leading-normal mt-4 space-y-2">
              <li>{t("section2.li1")}</li>
              <li>{t("section2.li2")}</li>
              <li>{t("section2.li3")}</li>
            </ol>
          </section>
          <section id="acceptable-use">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section3.subTitle")}
            </h2>
            <p className="text-white font-poppins text-lg font-medium leading-normal">
              {t("section3.li1")}
            </p>
            <ol className="text-white font-poppins text-lg font-light leading-normal mt-2 list-disc ml-4 space-y-2">
              <li>{t("section3.li2")}</li>
              <li>{t("section3.li3")}</li>
              <li>{t("section3.li4")}</li>
              <li>{t("section3.li5")}</li>
              <li>{t("section3.li6")}</li>
            </ol>
            <p className="text-white font-poppins text-lg font-normalleading-normal">
              {t("section3.li7")}
            </p>
          </section>
          <section id="registration-and-accounts">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section4.subTitle")}
            </h2>
            <ol className="text-white font-poppins text-lg font-light leading-normal mt-4 space-y-2">
              <li>{t("section4.li1")}</li>
              <li>{t("section4.li2")}</li>
              <li>{t("section4.li3")}</li>
              <li>{t("section4.li4")}</li>
            </ol>
          </section>
          <section id="suspension-and-cancellation">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section5.subTitle")}
            </h2>

            <p className="text-white font-poppins text-lg font-light leading-normal mt-1">
              {t("section5.li1")}
            </p>
          </section>
          <section id="services-and-payments">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section6.subTitle")}
            </h2>
            <ol className="text-white font-poppins text-lg font-light leading-normal mt-4 space-y-2">
              <li>{t("section6.li1")}</li>
              <li>{t("section6.li2")}</li>
              <li>{t("section6.li3")}</li>
            </ol>
          </section>
          <section id="your-content">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section7.subTitle")}
            </h2>
            <ol className="text-white font-poppins text-lg font-normal leading-normal mt-4 space-y-2">
              <li>{t("section7.li1")}</li>

              <li>{t("section7.li2")}</li>
              <li>{t("section7.li3")}</li>
              <ol className="text-white font-poppins text-lg font-light leading-normal mt-2 list-disc ml-5 space-y-2">
                <li>{t("section7.ol1")}</li>
                <li>{t("section7.ol2")}</li>
                <li>{t("section7.ol3")}</li>
                <li>{t("section7.ol4")}</li>
                <li>{t("section7.ol5")}</li>
                <li>{t("section7.ol6")}</li>
                <li>{t("section7.ol7")}</li>
                <li>{t("section7.ol8")}</li>
              </ol>
              <li>{t("section7.li4")}</li>
            </ol>
          </section>
          <section id="limited-warranties">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section8.subTitle")}
            </h2>
            <p className="text-white font-poppins text-lg font-light leading-normal mt-4">
              {t("section8.li1")}
            </p>
            <ol className="text-white font-poppins text-lg font-light leading-normal mt-2 list-disc ml-5 space-y-2">
              <li>{t("section8.li2")}</li>
              <li>{t("section8.li3")}</li>
            </ol>
            <p className="text-white font-poppins text-lg font-normal leading-normal mt-4">
              {t("section8.li4")}
            </p>
          </section>
          <section id="limitations-of-liability">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section9.subTitle")}
            </h2>
            <ol className="text-white font-poppins text-lg font-light leading-normal mt-4  space-y-2">
              <li>{t("section9.li1")}</li>
              <li>{t("section9.li2")}</li>
              <li>
                <ol className="text-white font-poppins text-lg font-light leading-normal mt-2 list-disc ml-5 space-y-2">
                  <li>{t("section9.li3")}</li>
                  <li>{t("section9.li4")}</li>
                  <li>{t("section9.li5")}</li>
                </ol>
              </li>
            </ol>
          </section>
          <section id="indemnity-1">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section10.subTitle")}
            </h2>
            <p className="text-white font-poppins text-lg font-light leading-normal mt-4">
              {t("section10.li1")}
            </p>
            <ol className="text-white font-poppins text-lg font-light leading-normal mt-4  space-y-2">
              <li>{t("section10.li2")}</li>
              <li>{t("section10.li3")}</li>
              <li>
                <ol className="text-white font-poppins text-lg font-light leading-normal mt-2 list-disc ml-5 space-y-2">
                  <li>{t("section10.li4")}</li>
                  <li>{t("section10.li5")}</li>
                  <li>{t("section10.li6")}</li>
                </ol>
              </li>
            </ol>
          </section>
          <section id="indemnity-2">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section11.subTitle")}
            </h2>
            <p className="text-white font-poppins text-lg font-light leading-normal mt-2">
              {t("section11.li1")}
            </p>
          </section>
          <section id="third-party-websites">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section12.subTitle")}
            </h2>
            <p className="text-white font-poppins text-lg font-light leading-normal mt-4">
              {t("section12.li1")}
            </p>
            <ol className="text-white font-poppins text-lg font-light leading-normal mt-2 list-disc ml-5 space-y-2">
              <li>{t("section12.li2")}</li>
              <li>{t("section12.li3")}</li>
              <li>{t("section12.li4")}</li>
            </ol>
          </section>
          <section id="third-party-websites">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section13.subTitle")}
            </h2>
            <p className="text-white font-poppins text-lg font-light leading-normal mt-4">
              {t("section13.li1")}
            </p>
          </section>
          <section id="trademarks">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section14.subTitle")}
            </h2>
            <p className="text-white font-poppins text-lg font-light leading-normal mt-4">
              {t("section14.li1")}
            </p>
          </section>
          <section id="variations">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section15.subTitle")}
            </h2>
            <p className="text-white font-poppins text-lg font-light leading-normal mt-4">
              {t("section15.li1")}
            </p>
          </section>
          <section>
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section16.subTitle")}
            </h2>
            <p className="text-white font-poppins text-lg font-light leading-normal mt-4">
              {t("section16.li1")}
            </p>
          </section>
          <section id="our-details">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section17.subTitle")}
            </h2>
            <p className="text-white font-poppins text-lg font-light leading-normal mt-4">
              {t("section17.li1")}
            </p>
            <ol className="text-white font-poppins text-lg font-light leading-normal mt-4 ml-5 space-y-2">
              <li>{t("section17.li2")}</li>
              <li>{t("section17.li3")}</li>
            </ol>
          </section>
        </div>
      </div>
    </div>
  );
};

export default TermsConditions;
