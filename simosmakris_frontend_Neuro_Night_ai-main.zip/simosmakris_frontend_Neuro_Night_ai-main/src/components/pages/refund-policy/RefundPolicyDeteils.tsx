"use client";
import { useTranslations } from "use-intl";

function RefundPolicyDetails() {
  const t = useTranslations("RefundPolicy");
  return (
    <div className="flex flex-col gap-10 mt-12">
      <div className=" flex flex-col gap-4">
        <p className="text-white font-poppins text-xl font-bold leading-7 tracking-tight">
          {t("section1.title")}
        </p>
        <ol className="text-white list-disc font-poppins text-base font-light leading-6 ml-4 space-y-2">
          <li>{t("section1.li1")}</li>
          <li>{t("section1.li2")}</li>
        </ol>
      </div>
      <div className=" flex flex-col gap-4">
        <p className="text-white font-poppins text-xl font-bold leading-7 tracking-tight">
          {t("section2.title")}
        </p>
        <ol className="text-white list-disc font-poppins text-[20px] font-medium leading-[28px] tracking-[0.5px] ml-4 space-y-2">
          <li>{t("section2.subTitle")}</li>
          <ol className="text-white list-disc font-poppins text-base font-light leading-6 ml-4 space-y-2">
            <li>{t("section2.li1")}</li>
          </ol>
        </ol>
        <ol className="text-white list-disc font-poppins text-[20px] font-medium leading-[28px] tracking-[0.5px] ml-4 space-y-2">
          <li>{t("section2.subTitle1")}</li>
          <ol className="text-white list-disc font-poppins text-base font-light leading-6 ml-4 space-y-2">
            <li>{t("section2.li2")}</li>
            <li>{t("section2.li3")}</li>
          </ol>
        </ol>
      </div>
      <div className=" flex flex-col gap-4">
        <p className="text-white font-poppins text-xl font-bold leading-7 tracking-tight">
          {t("section3.title")}
        </p>
        <ol className="text-white list-disc font-poppins text-base font-light leading-6 ml-4 space-y-2">
          <li>{t("section3.li1")}</li>
          <li>{t("section3.li2")}</li>
        </ol>
      </div>
      <div className=" flex flex-col gap-4">
        <p className="text-white font-poppins text-xl font-bold leading-7 tracking-tight">
          {t("section4.title")}
        </p>
        <ol className="text-white list-disc font-poppins text-base font-light leading-6 ml-4">
          <li>{t("section4.li1")}</li>
        </ol>
      </div>
    </div>
  );
}

export default RefundPolicyDetails;
