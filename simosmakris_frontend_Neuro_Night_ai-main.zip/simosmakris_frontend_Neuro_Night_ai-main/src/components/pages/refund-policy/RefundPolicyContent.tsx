"use client";
import { useTranslations } from "next-intl";
function RefundPolicyContent() {
  const t = useTranslations("RefundPolicy");
  return (
    <div className="flex flex-col items-center justify-center gap-6">
      <h3 className="text-primary text-center font-poppins md:text-[60px]  text-4xl lg:text-[80px] font-bold leading-normal">
        {t("title")}
      </h3>
      <p className="text-white font-poppins text-lg font-light leading-xl">
        {t("description")}
      </p>
      <h6 className="text-white font-poppins text-lg font-light leading-xl">
        {t("lastdate")}
      </h6>
    </div>
  );
}

export default RefundPolicyContent;
