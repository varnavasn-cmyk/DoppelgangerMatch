"use client";
import Content from "./content";

export default function Dashboard() {
  return (
    <div>
      <Content />
    </div>
  );
}
