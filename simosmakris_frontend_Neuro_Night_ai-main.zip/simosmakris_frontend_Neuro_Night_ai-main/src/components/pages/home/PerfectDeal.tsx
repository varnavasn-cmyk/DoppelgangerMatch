"use client";
import { Button } from "@/components/ui/button";
import StoryCard, { StoryCardData } from "@/components/ui/Card/StoryCard";
import React from "react";
import { FaRegNewspaper, FaLightbulb, FaRocket } from "react-icons/fa6";
import { useTranslations } from "use-intl";

const PerfectDeal = () => {
  const t = useTranslations("home.about");
  const storyCards: StoryCardData[] = [
    {
      id: 1,
      title: t("title1"),
      description: t("desc1"),
      icon: <FaRegNewspaper size={24} />,
    },
    {
      id: 2,
      title: t("title2"),
      description: t("desc2"),
      icon: <FaLightbulb size={24} />,
    },
    {
      id: 3,
      title: t("title3"),
      description: t("desc3"),
      icon: <FaRocket size={24} />,
    },
  ];
  return (
    <div className=" xl:w-[1200px] xl:px-0 lg:px-20 md:px-6 sm:px-3 px-1 md:py-12 py-8 lg:py-20 mx-auto">
      <Button className="inline-flex items-center justify-center gap-2.5 px-2.5 py-0.5 rounded-[27px] border border-[#01E3EA] bg-transparent text-[#01E3EA] hover:text-black">
        {t("title")}
      </Button>
      <div className="my-4 flex-col lg:flex-row  justify-between items-start gap-6">
        <h4 className="text-white font-poppins md:text-3xl text-xl  lg:text-[39px] font-normal leading-none w-full text-wrap md:w-[331px] ">
          {t("subtitle")}
        </h4>
        <p className="text-white font-poppins md:text-sm text-[12px] lg:text-[15px] font-normal w-full lg:w-[602px] leading-[28px] tracking-normal lg:tracking-[0.5px] ">
          {t("description")}
        </p>
      </div>
      <div className="flex lg:flex-row flex-col gap-6 justify-center mt-10">
        {storyCards.map((card) => (
          <StoryCard key={card.id} card={card} />
        ))}
      </div>
    </div>
  );
};

export default PerfectDeal;
