"use client";
import BlogCard from "@/components/ui/Card/BlogCard";
import { usePrefixedPath } from "@/lib/localePath";
import { useGetAllBlogsQuery } from "@/redux/features/users/usersApi";
import { useRouter } from "next/navigation";
import { useTranslations } from "use-intl";
export interface Blog {
  id: string;
  title: string;
  description: string;
  image: string;
  category: string | null;
  views: number;
  createdAt: string;
  updatedAt: string;
}
const Blog = () => {
  const { data } = useGetAllBlogsQuery({});
  const blogData = data?.data || [];
  const getPrefixedPath = usePrefixedPath();
  const router = useRouter();
  const t = useTranslations("home.blog");
  return (
    <div className=" xl:w-[1200px] xl:px-0 lg:px-20 md:px-6 sm:px-3 px-1 md:py-12 py-8 lg:py-20 mx-auto">
      <div className="flex flex-col items-center justify-center gap-3 md:gap-5 md:mb-8 mb-4 lg:mb-16">
        <h2 className="text-[#02CCD8] font-poppins md:text-3xl text-2xl lg:text-[48px] mb-2 md:mb-4 lg:mb-8 font-normal leading-none">
          {t("title")}
        </h2>
        <h6 className="text-[#8896AB] font-poppins md:text-lg  text-sm lg:text-xl text-center lg:w-[1005px] w-full font-medium  ">
          {t("discrition")}
        </h6>
      </div>
      <div className="flex flex-wrap gap-8 justify-center">
        {blogData?.map((blog: Blog) => (
          <BlogCard
            key={blog.id}
            blog={blog}
            onReadMore={() => router.push(getPrefixedPath(`/blog/${blog.id}`))}
          />
        ))}
      </div>
    </div>
  );
};
export default Blog;
