import React from "react";
import Banner from "./Banner/Banner";
// import LoginWithGoogle from "@/components/LoginWithGoogle";
// import Example from "./Example/Example";
import { Container } from "@/components/ui-library/container";
import WorkProcess from "./WorkProcess";
import PerfectDeal from "./PerfectDeal";
import PricingPlan from "@/components/shared/PlanPricing/PricingPlan";
import Blog from "./Blog";
import FAQ from "./FAQ";
import Doppelganger from "./Doppelganger";

const HomeComponent = () => {
  return (
    <Container>
      <Banner />
      <PricingPlan />
      <WorkProcess />
      <PerfectDeal />
      <Doppelganger />
      <Blog />
      <FAQ />
      {/* <LoginWithGoogle /> */}
    </Container>
  );
};

export default HomeComponent;
