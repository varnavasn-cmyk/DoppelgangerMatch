"use client";
import { PepleIcon, SearchIcon, UploadIcon } from "@/assets/svg";
import { useTranslations } from "use-intl";
import React from "react";

const WorkProcess = () => {
  const t = useTranslations("home.worksteps");
  return (
    <div className=" xl:w-[1200px] xl:px-0 lg:px-20 md:px-6 sm:px-3 px-1 md:py-12 py-8 lg:py-20 mx-auto">
      <div>
        <h2 className="text-white font-poppins text-xl md:text-3xl lg:text-[40px] font-normal  w-[293px] mt-4 leading-none">
          {t("title")}
        </h2>
        <p className="text-white font-poppins md:text-sm text-[12px] lg:text-[18px] font-normal mt-2 leading-none">
          {t("step1title")}
        </p>
      </div>
      <div className="flex items-start flex-wrap  md::flex-nowrap lg:justify-center justify-rigth  lg:gap-40 ">
        <div>
          <div className="flex  items-center mt-10">
            <div>
              <div className="w-[36px] h-[36px] shrink-0 fill-[rgba(255,255,255,0.1)]">
                <UploadIcon />
              </div>
              <h5 className="text-white font-poppins text-[18px] font-bold leading-none">
                {t("title1")}
              </h5>
            </div>
            <div>
              <h2 className="text-[rgba(0,255,255,0.1)] font-poppins text-[100px] font-black leading-none">
                1
              </h2>
            </div>
          </div>
          <p className="text-white font-poppins text-[14px] w-[217px] font-normal leading-none">
            {t("desc1")}
          </p>
        </div>
        <div>
          <div className="flex  items-center mt-10">
            <div>
              <div className="w-[36px] h-[36px] shrink-0 fill-[rgba(255,255,255,0.1)]">
                <SearchIcon />
              </div>
              <h5 className="text-white font-poppins text-[18px] font-bold leading-none">
                {t("title2")}
              </h5>
            </div>
            <div>
              <h2 className="text-[rgba(0,255,255,0.1)] font-poppins text-[100px] font-black leading-none">
                2
              </h2>
            </div>
          </div>
          <p className="text-white font-poppins text-[14px] w-[217px] font-normal leading-none">
            {t("desc2")}
          </p>
        </div>
        <div>
          <div className="flex  items-center mt-10">
            <div>
              <div className="w-[36px] h-[36px] shrink-0 fill-[rgba(255,255,255,0.1)]">
                <PepleIcon />
              </div>
              <h5 className="text-white font-poppins text-[18px] font-bold leading-none">
                {t("title3")}
              </h5>
            </div>
            <div>
              <h2 className="text-[rgba(0,255,255,0.1)] font-poppins text-[100px] font-black leading-none">
                3
              </h2>
            </div>
          </div>
          <p className="text-white font-poppins text-[14px] w-[217px] font-normal leading-none">
            {t("desc3")}
          </p>
        </div>
      </div>
    </div>
  );
};

export default WorkProcess;
