"use client";
import Faqs from "@/components/shared/FAQ/faqs";
import { Button } from "@/components/ui/button";
import { usePrefixedPath } from "@/lib/localePath";
import { useRouter } from "next/navigation";

const FAQ = () => {
  const router = useRouter();
  const getPrefixedPath = usePrefixedPath();
  return (
    <section className=" xl:w-[1200px] xl:px-0 lg:px-20 md:px-6 sm:px-3 px-1 md:py-12 py-8 lg:py-20 mx-auto">
      <div className=" xl:w-[1200px] xl:px-0 lg:flex-row flex justify-between lg:px-20 md:px-6 sm:px-3 px-1 md:py-12 py-8 lg:py-20 mx-auto">
        <div>
          <Button variant="outline" className="rounded-full">
            FAQ
          </Button>
          <h2 className="lg:w-[456px] w-full text-[color:var(--White-900,#FFF)] mt-3 font-poppins md:text-3xl text-xl lg:text-[48px] font-bold ">
            Frequently Asked Questions
          </h2>
          <p className="lg:w-[456px] w-full text-[color:var(--Gray-400,#8896AB)] mt-4 font-poppins md:text-md text-sm lg:text-xl font-medium ">
            Flex is the only saas business platform that lets you run your
            business on one platform, seamlessly across all digital channels.
          </p>
        </div>
        <div>
          <div className="mt-4 w-full lg:w-[610px] ">
            <Faqs />
          </div>
          <Button onClick={() => router.push(getPrefixedPath("/faq"))}>
            View FAQ page
          </Button>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
