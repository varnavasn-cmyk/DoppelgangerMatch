import bannerimg from "@/assets/home/banner.png";
import ImageUploadFlow from "@/components/shared/uploadResults/demeyUpload";
import Image from "next/image";
import { useTranslations } from "next-intl";

const Banner = () => {
  const t = useTranslations("home.banner");
  return (
    <div className=" xl:w-[1200px] xl:px-0 lg:px-20 md:px-6 sm:px-3 px-1 md:py-12 py-8 lg:py-20 mx-auto">
      <div className="h-auto flex flex-col gap-8 justify-center items-center relative">
        <div className="flex  flex-col gap-3 sm:gap-6 justify-center items-center ">
          <h1 className="text-[#02CCD8] font-poppins md:text-4xl text-3xl sm:text-[80px]  font-bold leading-none text-center lg:text-nowrap ">
            {t("title")}
          </h1>
          <p className="text-white font-poppins text-[12px] text-center md:text-[20px] font-normal leading-none  -tracking-tight  md:mt-3">
            {t("subtitle")}
          </p>
          <ImageUploadFlow />
        </div>
        <div className="absolute w-full -z-10 flex justify-center items-center">
          <div className="mt-10 relative flex justify-center items-center">
            <Image
              src={bannerimg}
              alt="Banner Image"
              width={502}
              height={534}
              className="w-full h-auto rounded-[16px] opacity-20"
            />
            <div
              className="w-[125.176px] h-[717px] shrink-0 
           bg-[linear-gradient(360deg,#1B3B4B_0%,rgba(27,59,75,0)_94.95%)] 
           mix-blend-plus-lighter 
           blur-[14.44px] absolute left-0 right-0 bottom-0 mx-auto opacity-10"
            ></div>
            <div
              className="bg-[linear-gradient(360deg,#1B3B4B_0%,rgba(27,59,75,0)_94.95%)] opacity-10 mix-blend-plus-lighter blur-[46.89px] absolute w-full lg:w-[824px] h-full shrink-0
          "
              style={{
                clipPath: "polygon(0 0%, 100% 0, 64% 100%, 35% 100%)",
              }}
            ></div>
            <div className="absolute top-0 left-0 right-0 bottom-0 mx-auto w-full md:w-[602px] h-[381px] rounded-[602px] bg-[#0889A5] blur-[250px] opacity-15"></div>
            <div className="absolute bottom-0 left-0 right-0  w-full h-full flex justify-center items-center opacity-10 ">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="998"
                height="891"
                viewBox="0 0 998 891"
                fill="none"
              >
                <g
                  style={{ mixBlendMode: "plus-lighter" }}
                  filter="url(#filter0_f_2006_44)"
                >
                  <path
                    d="M561.595 804L436.439 804L87.0001 87L911 87L561.595 804Z"
                    fill="url(#paint0_linear_2006_44)"
                  />
                </g>
                <defs>
                  <filter
                    id="filter0_f_2006_44"
                    x="0.33654"
                    y="0.336388"
                    width="997.327"
                    height="890.327"
                    filterUnits="userSpaceOnUse"
                    colorInterpolationFilters="sRGB"
                  >
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend
                      mode="normal"
                      in="SourceGraphic"
                      in2="BackgroundImageFix"
                      result="shape"
                    />
                    <feGaussianBlur
                      stdDeviation="43.3318"
                      result="effect1_foregroundBlur_2006_44"
                    />
                  </filter>
                  <linearGradient
                    id="paint0_linear_2006_44"
                    x1="512.427"
                    y1="804"
                    x2="512.427"
                    y2="123.244"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stopColor="#1B3B4B" />
                    <stop offset="1" stopColor="#1B3B4B" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Banner;
