"use client";
import Image from "next/image";
import findimg from "@/assets/home/lookalike.png";
import celebritionimg from "@/assets/home/celebrities.png";
import facebook from "@/assets/icons/facebook.png";
import sochat from "@/assets/icons/sochat.svg";
import youtube from "@/assets/icons/youtube.png";
import instagram from "@/assets/icons/instagram.png";
import tiktok from "@/assets/icons/tiktok.png";
import React, { useState } from "react";
import { useTranslations } from "use-intl";

const Doppelganger = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const tDoppel = useTranslations("home.doppelganger");
  const tCeleb = useTranslations("home.Celebrities");
  return (
    <div className=" xl:w-[1200px] xl:px-0 lg:px-20 md:px-6 sm:px-3 px-1 md:py-12 py-8 lg:py-20 mx-auto">
      <section className="flex flex-col  justify-center md:gap-10 gap-4 lg:gap-10 items-center md:mb-10 mb-8 lg:mb-20 ">
        <h2 className="text-white font-poppins md:text-3xl text-xl lg:text-[50px] font-normal leading-normal w-full lg:w-[800px]">
          {tDoppel("title")}
          {"  "}
          <span className="text-[#02CCD8] font-poppins font-bold leading-normal">
            {tDoppel("title1")}
          </span>{" "}
          {tDoppel("title2")}
        </h2>
        <p className="lg:w-[792px] w-full  text-white text-center font-poppins md:text-sm text-[12px] lg:text-[15px] text-wrap font-normal tracking-normal">
          {tDoppel("description")}
        </p>
        <div className="relative flex justify-center items-center">
          <Image
            src={findimg}
            alt="find lookalike"
            height={650}
            width={1050}
            className="lg:my10 my-4  w-full h-auto object-cover lg:h-[650px]"
          />
          <div className="lg:block hidden h-[1177.441px] -rotate-60 absolute -z-10 -bottom-30 right-0 left-80  rounded-[1177.441px] bg-[#02CCD8] blur-[150px]"></div>
        </div>
      </section>
      <section className="flex lg:flex-row  flex-col justify-between items-center gap-4 lg:gap-10 md:mt-10 md:gap-6 lg:mt-20">
        <div className="flex lg:flex-row flex-col justify-center gap-6 items-center">
          <Image
            src={celebritionimg}
            alt="decorative line"
            width={588}
            height={432}
            className="lg:w-[588px] w-full h-full object-cover lg:h-[432px]"
          />
          <div className="flex flex-wrap lg:flex-col flex-row gap-2 md:gap-5 ">
            <Image
              src={facebook}
              alt="decorative line"
              width={44}
              height={44}
              className="w-11 h-11"
            />
            <Image
              src={instagram}
              alt="decorative line"
              width={44}
              height={44}
              className="w-11 h-11"
            />
            <Image
              src={youtube}
              alt="decorative line"
              width={44}
              height={44}
              className="w-11 h-11"
            />
            <Image
              src={tiktok}
              alt="decorative line"
              width={44}
              height={44}
              className="w-11 h-11"
            />
            <Image
              src={sochat}
              alt="decorative line"
              width={44}
              height={44}
              className="w-11 h-11"
            />
          </div>
        </div>
        <div>
          <h3 className="text-white font-poppins md:text-2xl text-lg lg:text-[30px] font-normal leading-normal">
            <span className="text-[#02CCD8]  font-bold leading-normal">
              {tCeleb("title")}{" "}
            </span>{" "}
            {tCeleb("title1")}
          </h3>
          <p className="lg:w-[457px] w-full text-white  lg:text-right text-left font-poppins text-[12px] lg:text-[13px] font-normal  tracking-normal [font-feature-settings:'liga'_off,'clig'_off]">
            {tCeleb("description")}
          </p>
        </div>
      </section>
      <section className="flex justify-center flex-col items-center md:mt-10 mt-6 lg:mt-20">
        <h3 className="text-white text-center font-poppins text-lg md:text-3xl lg:text-[40px] font-normal leading-normal w-full xl:w-[1010px]">
          {tCeleb("subtitle")}
          <span className="text-[#02CCD8] font-poppins font-bold leading-normal">
            {tCeleb("subtitle1")}
          </span>{" "}
        </h3>
        <p className="lg:w-[820px] w-full text-white text-center font-poppins text-[13px] md:mt-12 mt-6 lg:mt-[30px] font-normal leading-[28px] tracking-[0.5px] ">
          {tCeleb("subdesc1")}
        </p>
        <div className="relative lg:w-[996px] w-full h-full lg:h-[590px] rounded-xl overflow-hidden shadow-lg md:mt-12 mt-6 lg:mt-25">
          {!isPlaying && (
            <div
              className="absolute inset-0 bg-/10 flex items-center justify-center cursor-pointer transition duration-300 hover:bg-black/40 z-10"
              onClick={() => setIsPlaying(true)}
            >
              <div className="lg:w-16 lg:h-16 w-full h-full bg-black/20 lg:rounded-full flex items-center justify-center">
                <div className="ml-1 w-0 h-0 border-t-8 border-t-transparent border-b-8 border-b-transparent border-l-12 border-l-primary"></div>
              </div>
            </div>
          )}

          <video
            className=" lg:w-[996px] w-full h-auto lg:h-[590px] object-cover  "
            src="https://www.pexels.com/download/video/8193758/" // Replace with actual video URL
            poster="https://images.unsplash.com/photo-1736957764199-8b3f7b6c117d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHwyfHx8ZW58MHx8fHx8"
            autoPlay={isPlaying}
            controls={isPlaying}
            playsInline
          />
        </div>
      </section>
    </div>
  );
};

export default Doppelganger;
