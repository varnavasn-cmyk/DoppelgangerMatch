"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import { signupSchema, SignupFormSchema } from "./utils/validation";
import { AuthCard } from "./AuthForm";
import TextField from "./TextField";
import PasswordField from "./PasswordField";
import { LucideMail, LucideUser2, Key, RotateCw } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import logoImage from "@/assets/login-logo.png";
import GoogleIcon from "@/assets/auth-icon/google.png";
// import InstagramIcon from "@/assets/auth-icon/instagram.png";
import FacebookIcon from "@/assets/auth-icon/facebook.png";
import TiktokIcon from "@/assets/auth-icon/tik-tok.png";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { loginPath } from "@/paths";
import { useState } from "react";
import SignupButton from "./SignupButton";
import captchaBgImage from "../../../assets/captcha-bg.svg";
import { env } from "@/env";
import { usePrefixedPath } from "@/lib/localePath";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";

type SignupResponse = {
  success: boolean;
  message: string;
};

export default function SignupForm({ callbackUrl }: { callbackUrl: string }) {
  function generateCaptcha() {
    const chars =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    return Array.from(
      { length: 6 },
      () => chars[Math.floor(Math.random() * chars.length)]
    ).join(" ");
  }
  const getPrefixedPath = usePrefixedPath();
  const router = useRouter();
  const t = useTranslations("signup");

  const [captchaValue, setCaptchaValue] = useState(generateCaptcha());
  const [isRotating, setIsRotating] = useState(false);

  const form = useForm<SignupFormSchema>({
    mode: "all",
    resolver: zodResolver(signupSchema(t)),
    defaultValues: {
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
      captchaInput: "",
      acceptTerms: false,
      callbackUrl: callbackUrl ?? null,
    },
  });

  // CAPTCHA refresh
  const handleRefresh = () => {
    setIsRotating(true);
    setCaptchaValue(generateCaptcha());
    setTimeout(() => setIsRotating(false), 500);
  };

  // const backgroundStyle = {
  //   backgroundImage:
  //     "repeating-linear-gradient(45deg, rgba(255,255,255,0.05) 0px, rgba(255,255,255,0.05) 2px, transparent 2px, transparent 4px), repeating-linear-gradient(135deg, rgba(255,255,255,0.05) 0px, rgba(255,255,255,0.05) 2px, transparent 2px, transparent 4px), linear-gradient(to right, #e0f7fa, #b2ebf2)",
  //   minHeight: "150px",
  //   padding: "20px",
  // };

  const backgroundStyle = {
    backgroundImage: `url('${captchaBgImage.src}')`,
    minHeight: "150px",
    padding: "10px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "cover",
  };

  const cardStyle = {
    height: "150px",
    width: "100%",
    padding: "10px",
    borderRadius: "10px",
  };

  const onSubmit = async (formData: SignupFormSchema) => {
    if (
      formData.captchaInput.replace(/\s+/g, "") !==
      captchaValue.replace(/\s+/g, "")
    ) {
      toast.error("Captcha does not match!");
      return;
    }

    try {
      const response = await fetch("api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: formData.name,
          email: formData.email,
          password: formData.password,
        }),
      });

      const result: SignupResponse = await response.json().catch(() => null);

      if (!response.ok || !result?.success) {
        toast.error(result?.message || "Registration failed");
        return;
      }

      toast.success(
        result.message || "Please check your email for verification."
      );
      await new Promise((res) => setTimeout(res, 1000));
      router.push("/sign-up-success");
      // window.location.href =  "https://mail.google.com/mail/u/0/#inbox";
    } catch (error) {
      console.error("Signup Request Error:", error);
      toast.error("Something went wrong. Please try again later.");
    }
  };

  const handleGoogleLogin = () => {
    window.location.href = `${env.NEXT_PUBLIC_API_URL}/auth/google`;
  };

  const handleFacebookLogin = () => {
    window.location.href = `${env.NEXT_PUBLIC_API_URL}/auth/facebook`;
  };

  const handleTiktokLogin = () => {
    window.location.href = `${env.NEXT_PUBLIC_API_URL}/auth/tiktok`;
  };
  // const handleInstagramLogin = () => {
  //   // https://nondemocratically-weakhanded-ghislaine.ngrok-free.dev/api/v1/auth/instagram
  //   window.location.href = `${env.NEXT_PUBLIC_API_URL}/auth/instagram`;
  // };

  const redirectLoginUrl = callbackUrl
    ? `${loginPath()}?callbackUrl=${callbackUrl}`
    : loginPath();

  return (
    <AuthCard>
      <AuthCard.Header>
        <div className="flex items-center justify-center py-6 ">
          <Link href={getPrefixedPath("/")}>
            <Image
              className="cursor-pointer object-cover w-32 h-12"
              src={logoImage}
              alt="logo"
            />
          </Link>
        </div>
        <AuthCard.Title className="-mb-[30px]">{t("title")}</AuthCard.Title>
      </AuthCard.Header>

      <AuthCard.Content>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <fieldset className="space-y-2">
              <TextField label="Full Name" name="name" placeholder="Full Name">
                <LucideUser2 className="size-9 text-muted-foreground p-2.5 absolute left-0 bottom-0" />
              </TextField>

              <TextField
                label="Email Address"
                name="email"
                placeholder={t("email")}
              >
                <LucideMail className="size-9 text-muted-foreground p-2.5 absolute left-0 bottom-0" />
              </TextField>

              <PasswordField
                label="Password"
                name="password"
                type="password"
                placeholder={t("password")}
              >
                <Key className="size-9 text-muted-foreground p-2.5 absolute left-0 bottom-0" />
              </PasswordField>

              <PasswordField
                label="Confirm Password"
                name="confirmPassword"
                type="password"
                placeholder={t("confirmPassword")}
              >
                <Key className="size-9 text-muted-foreground p-2.5 absolute left-0 bottom-0" />
              </PasswordField>

              {/* CAPTCHA Section */}
              {/* style={backgroundStyle} */}
              <div style={backgroundStyle} className="font-sans rounded-lg">
                <div
                  style={cardStyle}
                  className="
                w-full 
                space-y-4
                "
                >
                  {/* CAPTCHA Display + Refresh */}
                  <div className="flex items-center justify-between gap-2">
                    {/* CAPTCHA Text Box */}
                    <div className="px-2 py-2 border border-gray-300 rounded-lg bg-white">
                      <span className="font-poppins tracking-widest text-sm text-gray-700 select-none">
                        {captchaValue}
                      </span>
                    </div>

                    {/* Refresh Button */}
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={handleRefresh}
                      aria-label="Refresh CAPTCHA"
                      className="bg-transparent border-gray-600 hover:bg-transparent cursor-pointer"
                      disabled={isRotating}
                    >
                      <RotateCw
                        size={24}
                        className={`text-gray-700 ${
                          isRotating ? "animate-spin" : ""
                        }`}
                      />
                    </Button>
                  </div>

                  {/* CAPTCHA Input with RHF */}
                  <FormField
                    control={form.control}
                    name="captchaInput"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <TextField
                            label=""
                            name="captchaInput"
                            placeholder="Type here Captcha"
                            value={field.value}
                            onChange={field.onChange}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              {/* Terms */}
              <FormField
                control={form.control}
                name="acceptTerms"
                render={({ field }) => (
                  <FormItem className="flex items-center space-x-2 mt-2">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <label className="text-xs font-medium text-black">
                      {t("agree")}{" "}
                      <Link
                        href={getPrefixedPath("/terms")}
                        className="animated-underline font-bold"
                      >
                        {t("terms")}
                      </Link>
                    </label>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </fieldset>

            <div className="mt-4">
              <SignupButton
                disabled={
                  !form.formState.isValid || form.formState.isSubmitting
                }
                isLoading={form.formState.isSubmitting}
                className="w-full font-extrabold bg-[#01DAE2] rounded-lg cursor-pointer"
                type="submit"
              >
                {t("button")}
              </SignupButton>
            </div>
          </form>
        </Form>

        {/* Social Login */}
        <div className="space-y-4">
          <div className="flex items-center justify-center space-x-2 mt-4">
            <span className="h-px w-16 bg-muted" />
            <span className="text-xs text-black"> {t("or")} </span>
            <span className="h-px w-16 bg-muted" />
          </div>
          <div className="flex flex-row items-center justify-around gap-2 mt-4 w-[60%] mx-auto">
            <Button
              type="button"
              className="border-4 border-gray-50 hover:glow-border transition-all duration-200 bg-transparent! cursor-pointer"
              onClick={handleGoogleLogin}
            >
              <Image src={GoogleIcon} alt="google" width={20} height={20} />
            </Button>

            <Button
              type="button"
              className="border-4 border-gray-50 hover:glow-border transition-all duration-200 bg-transparent! cursor-pointer"
              onClick={handleFacebookLogin}
            >
              <Image src={FacebookIcon} alt="facebook" width={20} height={20} />
            </Button>

            {/* <Button
              type="button"
              className="border-4 border-gray-50 hover:glow-border transition-all duration-200 bg-transparent! cursor-pointer"
              onClick={handleInstagramLogin}
            >
              <Image
                src={InstagramIcon}
                alt="instagram"
                width={20}
                height={20}
              />
            </Button> */}

            <Button
              type="button"
              className="border-4 border-gray-50 hover:glow-border transition-all duration-200 bg-transparent! cursor-pointer"
              onClick={handleTiktokLogin}
            >
              <Image src={TiktokIcon} alt="tiktok" width={20} height={20} />
            </Button>
          </div>
        </div>
      </AuthCard.Content>

      <AuthCard.Footer>
        <AuthCard.Text>{t("li")} </AuthCard.Text>
        <AuthCard.Link
          href={`${redirectLoginUrl}`}
          className="text-black! text-xs font-bold animated-underline"
        >
          {t("li2")}
        </AuthCard.Link>
      </AuthCard.Footer>
    </AuthCard>
  );
}
