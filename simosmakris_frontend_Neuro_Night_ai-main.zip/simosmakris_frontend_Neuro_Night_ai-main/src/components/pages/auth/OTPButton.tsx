// /* eslint-disable @typescript-eslint/no-explicit-any */
// "use client";

// import { useState } from "react";
// import { toast } from "sonner";
// import { useSearchParams } from "next/navigation";
// import { env } from "@/env";

// export default function OTPButton() {
//   const [loading, setLoading] = useState(false);
//   const [cooldown, setCooldown] = useState(0);
//   const searchParams = useSearchParams();

//   const encodedEmail = searchParams.get("email");
//   const email = encodedEmail ? decodeURIComponent(encodedEmail) : "";

//   async function handleSendOTP() {
//     if (loading || cooldown > 0) return;

//     setLoading(true);

//     try {
//       // mock request — replace with your backend later
//       const response = await fetch(
//         env.NEXT_PUBLIC_API_URL + "/auth/forgot-password",
//         {
//           method: "POST",
//           headers: {
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify({ email }),
//         }
//       );

//       if (!response.ok) throw new Error("Failed to send OTP");

//       const result = await response.json();

//       if (result.success) {
//         toast.success(result.message || "OTP sent successfully");
//         setCooldown(180); //! 3mins cooldown before resend
//         startCooldown();
//       } else {
//         toast.error(result.message || "Failed to send OTP");
//       }
//     } catch (err: any) {
//       toast.error(err.message || "Something went wrong");
//     } finally {
//       setLoading(false);
//     }
//   }

//   function startCooldown() {
//     // eslint-disable-next-line prefer-const
//     let timer = setInterval(() => {
//       setCooldown((prev) => {
//         if (prev <= 1) {
//           clearInterval(timer);
//           return 0;
//         }
//         return prev - 1;
//       });
//     }, 1000);
//   }

//   return (
//     <div className="flex items-center">
//       <p className="text-xs text-black">
//         {cooldown > 0
//           ? "Please wait before requesting a new OTP."
//           : "Didn’t get the code? You can request a new one."
//         }
//       </p>
//       <button
//         onClick={handleSendOTP}
//         disabled={loading || cooldown > 0}
//         className="text-xs text-black animated-underline ml-1 font-bold cursor-pointer"
//       >
//         {loading
//           ? "Sending..."
//           : cooldown > 0
//             ? `Resend in ${ cooldown }s`
//             : "Resend OTP"}
//       </button>
//     </div>
//   );
// }


/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import { useState, useEffect, useRef } from "react";
import { toast } from "sonner";
import { useSearchParams } from "next/navigation";
import { env } from "@/env";

export default function OTPButton() {
  const [loading, setLoading] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const searchParams = useSearchParams();
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const encodedEmail = searchParams.get("email");
  const email = encodedEmail ? decodeURIComponent(encodedEmail) : "";

  // Cleanup timer on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  async function handleSendOTP() {
    if (loading || cooldown > 0) return;

    setLoading(true);

    try {
      const response = await fetch(
        env.NEXT_PUBLIC_API_URL + "/auth/forgot-password",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email }),
        }
      );

      if (!response.ok) throw new Error("Failed to send OTP");

      const result = await response.json();

      if (result.success) {
        toast.success(result.message || "OTP sent successfully");
        setCooldown(180); // 3 mins cooldown
        startCooldown();
      } else {
        toast.error(result.message || "Failed to send OTP");
      }
    } catch (err: any) {
      toast.error(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  function startCooldown() {
    // Clear existing timer if any
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    timerRef.current = setInterval(() => {
      setCooldown((prev) => {
        if (prev <= 1) {
          if (timerRef.current) {
            clearInterval(timerRef.current);
            timerRef.current = null;
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }

  // Format cooldown time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${ mins }:${ secs.toString().padStart(2, "0") }`;
  };

  return (
    <div className="flex items-center">
      <p className="text-xs text-black">
        {cooldown > 0
          ? "Please wait before requesting a new OTP."
          : "Didn't receive the code? You can request a new one."}
      </p>
      <button
        onClick={handleSendOTP}
        disabled={loading || cooldown > 0}
        className="text-xs text-black animated-underline ml-1 font-bold cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {loading
          ? "Sending..."
          : cooldown > 0
            ? `Resend on (${ formatTime(cooldown) })`
            : "Resend OTP"}
      </button>
    </div>
  );
}