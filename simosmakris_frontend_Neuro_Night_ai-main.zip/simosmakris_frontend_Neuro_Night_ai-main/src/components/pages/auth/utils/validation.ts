"use client";
import z from "zod";
import {
  MAX_PASSWORD_LENGTH,
  MIN_PASSWORD_LENGTH,
  PASSWORD_REGEX,
} from "./constants";
import { useTranslations } from "next-intl";

export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),

  password: z
    .string({ message: "Password is required" })
    .min(MIN_PASSWORD_LENGTH, {
      message: `Password must be at least ${MIN_PASSWORD_LENGTH} characters long`,
    })
    .max(MAX_PASSWORD_LENGTH, {
      message: `Password must not exceed ${MAX_PASSWORD_LENGTH} characters`,
    })
    .trim(),

  rememberMe: z.boolean(),
  callbackUrl: z.string().optional(),
});

// export const signupSchema = z
//   .object({
//     name: z
//       .string({ message: "Fullname is required" })
//       .min(3, { message: "Fullname must be at least 3 characters long" })
//       .max(25, { message: "Fullname must be at most 25 characters long" })
//       .trim(),

//     email: z.string().email("Invalid email address"),

//     password: z
//       .string({ message: "Password is required" })
//       .min(MIN_PASSWORD_LENGTH, {
//         message: `Password must be at least ${MIN_PASSWORD_LENGTH} characters long`,
//       })
//       .max(MAX_PASSWORD_LENGTH, {
//         message: `Password must not exceed ${MAX_PASSWORD_LENGTH} characters`,
//       })
//       .regex(PASSWORD_REGEX, {
//         message:
//           "Password must include uppercase, lowercase, number, and special character (!@#$%^&* etc.)",
//       })
//       .trim(),

//     confirmPassword: z
//       .string({ message: "Please retype your password" })
//       .min(MIN_PASSWORD_LENGTH, {
//         message: `Confirm password must be at least ${MIN_PASSWORD_LENGTH} characters long`,
//       })
//       .max(MAX_PASSWORD_LENGTH, {
//         message: `Confirm password must not exceed ${MAX_PASSWORD_LENGTH} characters`,
//       }),
//     captchaInput: z
//       .string({ message: "Captcha is required" })
//       .min(1, { message: "Please type the captcha" }),

//     acceptTerms: z
//       .boolean({
//         message: "You must accept the terms and conditions",
//       })
//       .refine((val) => val === true, {
//         message: "You must accept the terms and conditions",
//       }),
//     callbackUrl: z.string().nullable(),
//   })
//   .refine((data) => data.password === data.confirmPassword, {
//     message: "Passwords do not match",
//     path: ["confirmPassword"],
//   });

export const signupSchema = (t: ReturnType<typeof useTranslations>) =>
  z
    .object({
      name: z
        .string({ message: t("signup.name") })
        .min(3, { message: t("signup.fullname") })
        .max(25, { message: t("signup.fullname") })
        .trim(),

      email: z
        .string({ message: t("signup.email") })
        .email(t("signup.invalidemail")),

      password: z
        .string({ message: t("signup.password") })
        .min(MIN_PASSWORD_LENGTH, {
          message: t("signup.invalidpassword"),
        })
        .trim(),

      confirmPassword: z
        .string({ message: t("signup.confirmPassword") })
        .min(MIN_PASSWORD_LENGTH, {
          message: t("signup.invalidconfirmpassword"),
        }),

      captchaInput: z
        .string({ message: t("signup.captcha") })
        .min(1, { message: t("signup.captcha") }),

      acceptTerms: z
        .boolean({ message: t("signup.agree") })
        .refine((val) => val === true, {
          message: `${t("signup.agree")}${t("signup.terms")}`,
        }),

      callbackUrl: z.string().nullable(),
    })
    .refine((data) => data.password === data.confirmPassword, {
      message: t("signup.invalidconfirmpassword"),
      path: ["confirmPassword"],
    });

export const forgotPassword = z.object({
  email: z.string().email("Invalid email address"),
});

// export const resetPassword = z.object({
//   email: z.string().email("Invalid email address").optional(),
//   password: z
//     .string({ message: "Password is required" })
//     .min(MIN_PASSWORD_LENGTH, {
//       message: `Password must be at least ${MIN_PASSWORD_LENGTH} characters long`,
//     })
//     .max(MAX_PASSWORD_LENGTH, {
//       message: `Password must not exceed ${MAX_PASSWORD_LENGTH} characters`,
//     })
//     .regex(PASSWORD_REGEX, {
//       message:
//         "Password must include uppercase, lowercase, number, and special character (!@#$%^&* etc.)",
//     })
//     .trim(),

//   confirmPassword: z
//     .string({ message: "Password is required" })
//     .min(MIN_PASSWORD_LENGTH, {
//       message: `Password must be at least ${MIN_PASSWORD_LENGTH} characters long`,
//     })
//     .max(MAX_PASSWORD_LENGTH, {
//       message: `Password must not exceed ${MAX_PASSWORD_LENGTH} characters`,
//     })
//     .regex(PASSWORD_REGEX, {
//       message:
//         "Password must include uppercase, lowercase, number, and special character (!@#$%^&* etc.)",
//     })
//     .trim(),

//   token: z.string().optional(),
// })

// .refine((data) => data.password === data.confirmPassword, {
//   message: "Passwords do not match",
//   path: ["confirmPassword"],
// });

export const resetPassword = z.object({
  new_password: z
    .string({ message: "Password is required" })
    .min(MIN_PASSWORD_LENGTH, {
      message: `Password must be at least ${MIN_PASSWORD_LENGTH} characters long`,
    })
    .max(MAX_PASSWORD_LENGTH, {
      message: `Password must not exceed ${MAX_PASSWORD_LENGTH} characters`,
    })
    .regex(PASSWORD_REGEX, {
      message:
        "Password must include uppercase, lowercase, number, and special character (!@#$%^&* etc.)",
    })
    .trim(),

  confirm_new_password: z
    .string({ message: "Please confirm your password" })
    .min(MIN_PASSWORD_LENGTH, {
      message: "Confirm password must be at least 8 characters long",
    })
    .max(MAX_PASSWORD_LENGTH, {
      message: "Confirm password must not exceed 64 characters",
    }),

  token: z.string(),
});

export type LoginFormSchema = z.infer<typeof loginSchema>;
export type SignupFormSchema = z.infer<ReturnType<typeof signupSchema>>;
export type ForgotPasswordFormSchema = z.infer<typeof forgotPassword>;
export type ResetPasswordFormSchema = z.infer<typeof resetPassword>;
