"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";

import { Form } from "@/components/ui/form";
import { env } from "@/env";
import { loginPath } from "@/paths";
import AuthLayout from "./AuthLayout";
import { AuthCard } from "./AuthForm";
import PasswordField from "./PasswordField";
import logoImage from "@/assets/login-logo.png";
import ResetPasswordButton from "./ResetPasswordButton";
import Image from "next/image";
import Link from "next/link";
import { Key } from "lucide-react";
import { usePrefixedPath } from "@/lib/localePath";

// ✅ Zod schema
const resetPasswordSchema = z
  .object({
    newPassword: z.string().min(8, "Password must be at least 8 characters"),
    confirmPassword: z.string().min(8, "Confirm password is required"),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

type ResetPasswordFormSchema = z.infer<typeof resetPasswordSchema>;

export function ResetPasswordForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const getPrefixedPath = usePrefixedPath();

  const email: string | null = searchParams.get("email");

  // const otp: string | null = searchParams.get("otp");

  const form = useForm<ResetPasswordFormSchema>({
    mode: "all",
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      newPassword: "",
      confirmPassword: "",
    },
  });

  const onSubmit = async (values: ResetPasswordFormSchema): Promise<void> => {
    if (!email) {
      toast.error("Invalid request. Email is missing.");
      return;
    }
    try {
      const res = await fetch(
        `${env.NEXT_PUBLIC_API_URL}/auth/reset-password`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email,
            newPassword: values.newPassword,
            confirmPassword: values.confirmPassword,
          }),
        }
      );

      const data: { message?: string } = await res.json();

      if (!res.ok) {
        throw new Error(data?.message || "Failed to reset password");
      }

      toast.success("Password reset successful!", {
        description: "You can now log in with your new password.",
      });

      await new Promise((resolve) => setTimeout(resolve, 1000));
      router.push(getPrefixedPath(loginPath()));
    } catch (err: unknown) {
      let message = "Please try again later.";
      if (err instanceof Error) {
        message = err.message;
      }

      toast.error("Something went wrong", {
        description: message,
      });
    }
  };

  return (
    <AuthLayout>
      <AuthCard>
        <AuthCard.Header>
          <div className="flex items-center justify-center p-6">
            <Link href={getPrefixedPath("/")}>
              <Image
                className="cursor-pointer object-cover w-32 h-12"
                src={logoImage}
                alt="logo"
              />
            </Link>
          </div>
          <AuthCard.Title>New Password</AuthCard.Title>
          <AuthCard.Subtitle className="-mb-[30px]">
            Your New Password Must Be Different form Previously Used password.
          </AuthCard.Subtitle>
        </AuthCard.Header>

        <AuthCard.Content>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <fieldset className="space-y-2">
                <PasswordField
                  label="New Password"
                  name="newPassword"
                  type="password"
                  placeholder="Enter your new password"
                >
                  <Key className="size-9 text-muted-foreground p-2.5 absolute left-0 bottom-0" />
                </PasswordField>

                <PasswordField
                  label="Confirm Password"
                  name="confirmPassword"
                  type="password"
                  placeholder="Confirm your new password"
                >
                  <Key className="size-9 text-muted-foreground p-2.5 absolute left-0 bottom-0" />
                </PasswordField>
              </fieldset>
              <div className="mt-4">
                <ResetPasswordButton
                  disabled={
                    !form.formState.isValid || form.formState.isSubmitting
                  }
                  className="w-full"
                  type="submit"
                  isLoading={form.formState.isSubmitting}
                >
                  Save
                </ResetPasswordButton>
              </div>
            </form>
          </Form>
        </AuthCard.Content>
      </AuthCard>
    </AuthLayout>
  );
}
