
// import Image from "next/image";
// import authIntro from "@/assets/images/robot.webp";
import Container from "@/components/Container";
// import Logo from "@/components/Logo";

export default function AuthLayout({ children }: React.PropsWithChildren) {
  return (
    <Container size="lg">
      {/* <div className="flex mt-28 items-center justify-center">
        <Logo />
      </div> */}
      <div className="flex flex-col md:flex-row items-center gap-4 justify-center">
        <div className="md:flex-1">{children}</div>
      </div>
    </Container>
  );
}
