"use client";

import { useForm } from "react-hook-form";
import { LoginFormSchema, loginSchema } from "./utils/validation";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import { forgotPasswordPath, signupPath } from "@/paths";
import { AuthCard } from "./AuthForm";
import TextField from "./TextField";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Key, LucideMail } from "lucide-react";
import PasswordField from "./PasswordField";
import Link from "next/link";
import AuthButton from "./AuthButton";
import Image from "next/image";
import logoImage from "@/assets/login-logo.png";
import { useEffect } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import GoogleIcon from "@/assets/auth-icon/google.png";
// import InstagramIcon from "@/assets/auth-icon/instagram.png";
import FacebookIcon from "@/assets/auth-icon/facebook.png";
import TiktokIcon from "@/assets/auth-icon/tik-tok.png";
import { Button } from "@/components/ui/button";
import { useAppDispatch } from "@/redux/hooks";
import { setUser } from "@/redux/features/auth/authSlice";
import { env } from "@/env";
import { useSearchParams } from "next/navigation";
import { usePrefixedPath } from "@/lib/localePath";
import { useTranslations } from "next-intl";

type AuthResponse = {
  success: boolean;
  message: string;
  data?: {
    user?: {
      id: string;
      role: string;
      email: string;
      fullName: string;
    };
    accessToken?: string;
    refreshToken?: string;
    isVerified?: boolean;
  };
  errors?: { field: string; message: string }[];
};

export default function LoginForm({ callbackUrl }: { callbackUrl: string }) {
  const dispatch = useAppDispatch();
  const form = useForm<LoginFormSchema>({
    mode: "all",
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
      rememberMe: false,
      callbackUrl: callbackUrl,
    },
  });
  const getPrefixedPath = usePrefixedPath();
  const t = useTranslations("login");

  const searchParams = useSearchParams();
  const status = searchParams.get("status");
  const socialToken = localStorage.getItem("accessToken");
  console.log("Social Token", socialToken);

  useEffect(() => {
    if (status === "verified_success") {
      toast.success("✅ Email verified successfully. You can now log in.");
    } else if (status === "already_verified") {
      toast.info("Your email was already verified.");
    } else if (status === "verification_failed") {
      toast.error("❌ Verification link expired or invalid.");
    }
  }, [status]);

  // ✅ Load saved credentials from localStorage on mount
  useEffect(() => {
    const savedEmail = localStorage.getItem("savedEmail");
    const savedPassword = localStorage.getItem("savedPassword");
    const savedRememberMe = localStorage.getItem("savedRememberMe") === "true";

    if (savedEmail && savedPassword && savedRememberMe) {
      form.setValue("email", savedEmail);
      form.setValue("password", savedPassword);
      form.setValue("rememberMe", true);

      // ✅ Trigger validation so that Login button becomes active
      form.trigger();
    }
  }, [form]);

  const onSubmit = async (formData: LoginFormSchema) => {
    const refinedEmail = formData.email.trim().toLowerCase();
    formData.email = refinedEmail;
    try {
      // Save to localStorage if "Remember Me" is checked
      if (formData.rememberMe) {
        localStorage.setItem("savedEmail", formData.email);
        localStorage.setItem("savedPassword", formData.password);
        localStorage.setItem("savedRememberMe", "true");
      } else {
        // Clear localStorage if unchecked
        localStorage.removeItem("savedEmail");
        localStorage.removeItem("savedPassword");
        localStorage.removeItem("savedRememberMe");
      }

      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const result: AuthResponse = await response.json().catch(() => null);

      console.log("Login Response:", result);
      if (result) {
        dispatch(
          setUser({
            user: result?.data?.user || null,
            access_token: result?.data?.accessToken || null,
            refresh_token: result?.data?.refreshToken || null,
          })
        );
      }

      // ❌ Handle errors
      if (!response.ok || !result?.success) {
        if (result?.errors?.length) {
          result.errors.forEach((err) =>
            toast.error(`${err.field}: ${err.message}`)
          );
        } else {
          toast.error(result?.message || "Login failed.");
        }
        return;
      }

      // 🔹 Check verification
      if (result.data?.isVerified === false) {
        toast.info("Please verify your account first.");
        await new Promise((r) => setTimeout(r, 1000));
        window.location.href =
          "/auth/verify-otp?email=" + encodeURIComponent(formData.email);
        return;
      }

      // ✅ Success
      toast.success(result.message || "Login successful!");

      // 🔹 Redirect
      // const roles = result.data?.user?.role?.toLowerCase();
      const roles = result.data?.user?.role;
      console.log(roles, "find user role");
      if (roles === "SUPER_ADMIN" || roles === "ADMIN") {
        window.location.href = "/dashboard/admin";
      } else {
        window.location.href = "/";
      }
    } catch (error) {
      console.error("Login Request Error:", error);
      toast.error(
        error instanceof Error
          ? error.message
          : "Something went wrong. Please try again later."
      );
    }
  };

  const handleGoogleLogin = () => {
    window.location.href = `${env.NEXT_PUBLIC_API_URL}/auth/google`;
  };

  const handleFacebookLogin = () => {
    window.location.href = `${env.NEXT_PUBLIC_API_URL}/auth/facebook`;
  };

  const handleTiktokLogin = () => {
    window.location.href = `${env.NEXT_PUBLIC_API_URL}/auth/tiktok`;
  };
  // const handleInstagramLogin = () => {
  //   // https://nondemocratically-weakhanded-ghislaine.ngrok-free.dev/api/v1/auth/instagram
  //   window.location.href = `${ env.NEXT_PUBLIC_API_URL }/auth/instagram`;
  // };

  const redirectSignupUrl = callbackUrl
    ? `${signupPath()}?callbackUrl=${callbackUrl}`
    : signupPath();

  return (
    <AuthCard>
      <AuthCard.Header>
        <div className="flex items-center justify-center p-6">
          <Link href={getPrefixedPath("/")}>
            <Image
              className="cursor-pointer object-cover w-32 h-12"
              src={logoImage}
              alt="logo"
            />
          </Link>
        </div>
        <AuthCard.Title className="-mb-[30px]">{t("title")}</AuthCard.Title>
      </AuthCard.Header>

      <AuthCard.Content>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <TextField type="hidden" name="callbackUrl" />
            <fieldset className="space-y-4">
              <TextField
                label="Email"
                name="email"
                placeholder={t("email")}
                autoComplete="email"
              >
                <LucideMail className="size-9 text-muted-foreground p-2.5 absolute left-0 bottom-0" />
              </TextField>

              <PasswordField
                label="Password"
                name="password"
                type="password"
                placeholder={t("password")}
                autoComplete="current-password"
              >
                <Key className="size-9 text-muted-foreground p-2.5 absolute left-0 bottom-0" />
              </PasswordField>

              <div className="flex items-center justify-between">
                <FormField
                  control={form.control}
                  name="rememberMe"
                  render={({ field }) => (
                    <FormItem className="flex items-center space-x-2">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <label className="text-xs font-medium text-black">
                        {t("remember")}
                      </label>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Link
                  className="text-xs text-black! animated-underline"
                  href={getPrefixedPath(forgotPasswordPath())}
                >
                  {t("forgot")}
                </Link>
              </div>
            </fieldset>

            <div className="mt-4">
              <AuthButton
                disabled={
                  !form.formState.isValid || form.formState.isSubmitting
                }
                isLoading={form.formState.isSubmitting}
                className="w-full font-extrabold bg-[#01DAE2] rounded-lg cursor-pointer"
                type="submit"
              >
                {t("button")}
              </AuthButton>
            </div>
          </form>
        </Form>

        <div className="space-y-4">
          <div className="flex items-center justify-center space-x-2 mt-4">
            <span className="h-px w-16 bg-muted" />
            <span className="text-xs text-black">{t("or")}</span>
            <span className="h-px w-16 bg-muted" />
          </div>

          <div className="flex flex-row items-center justify-around gap-2 mt-4 w-[60%] mx-auto">
            <Button
              type="button"
              className="border-4 border-gray-50 hover:glow-border transition-all duration-200 bg-transparent! cursor-pointer"
              onClick={handleGoogleLogin}
            >
              <Image src={GoogleIcon} alt="google" width={20} height={20} />
            </Button>

            <Button
              type="button"
              className="border-4 border-gray-50 hover:glow-border transition-all duration-200 bg-transparent! cursor-pointer"
              onClick={handleFacebookLogin}
            >
              <Image src={FacebookIcon} alt="facebook" width={20} height={20} />
            </Button>

            {/* <Button
              type="button"
              className="border-4 border-gray-50 hover:glow-border transition-all duration-200 bg-transparent! cursor-pointer"
              onClick={handleInstagramLogin}
            >
              <Image
                src={InstagramIcon}
                alt="instagram"
                width={20}
                height={20}
              />
            </Button> */}

            <Button
              type="button"
              className="border-4 border-gray-50 hover:glow-border transition-all duration-200 bg-transparent! cursor-pointer"
              onClick={handleTiktokLogin}
            >
              <Image src={TiktokIcon} alt="tiktok" width={20} height={20} />
            </Button>
          </div>
        </div>
      </AuthCard.Content>

      <AuthCard.Footer>
        <AuthCard.Text>{t("li")}</AuthCard.Text>
        <AuthCard.Link
          href={`${redirectSignupUrl}`}
          className="text-black! text-xs font-bold animated-underline"
        >
          {t("li2")}
        </AuthCard.Link>
      </AuthCard.Footer>
    </AuthCard>
  );
}
