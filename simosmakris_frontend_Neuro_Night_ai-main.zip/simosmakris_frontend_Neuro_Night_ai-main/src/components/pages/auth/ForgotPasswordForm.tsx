"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import { AuthCard } from "./AuthForm";
import TextField from "./TextField";
import { Form } from "@/components/ui/form";
import { LucideMail } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import logoImage from "@/assets/login-logo.png";
import { forgotPassword, ForgotPasswordFormSchema } from "./utils/validation";
import ForgotPasswordButton from "./ForgotPasswordButton";

export default function ForgotPasswordForm() {
  const form = useForm<ForgotPasswordFormSchema>({
    mode: "all",
    resolver: zodResolver(forgotPassword),
    defaultValues: {
      email: "",
    },
  });

  const onSubmit = async (formData: ForgotPasswordFormSchema) => {
    try {
      const response = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const result = await response.json().catch(() => null);

      if (!response.ok || !result?.success) {
        toast.error(result?.message || "Request failed.");
        return;
      }

      toast.success(result.message || "Please check your email for verification.");
      //! Redirect to reset password page
      window.location.href = `/verify-otp?email=${ formData.email }`;
    } catch (error) {
      console.error("Forgot Password Request Error:", error);
      if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error("Something went wrong. Please try again later.");
      }
    }
  };

  return (
    <AuthCard>
      <AuthCard.Header>
        <div className="flex items-center justify-center p-6">
          <Link href="/">
            <Image
              className="cursor-pointer object-cover w-32 h-12"
              src={logoImage}
              alt="logo"
            />
          </Link>
        </div>
        <AuthCard.Title>Forgot Password</AuthCard.Title>
        <AuthCard.Subtitle className="-mb-[30px]">
          Please Enter Your Email Address to Receive a Verification Code.
        </AuthCard.Subtitle>
      </AuthCard.Header>
      <AuthCard.Content>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <fieldset className="space-y-4">
              <TextField
                label="Email"
                name="email"
                placeholder="Enter your email"
                autoComplete="email"
              >
                <LucideMail className="size-9 text-muted-foreground p-2.5 absolute left-0 bottom-0" />
              </TextField>
            </fieldset>
            <div className="mt-4 mb-10">
              <ForgotPasswordButton
                disabled={!form.formState.isValid || form.formState.isSubmitting}
                isLoading={form.formState.isSubmitting}
                className="w-full font-extrabold bg-[#01DAE2] rounded-lg"
                type="submit"
              >
                Send
              </ForgotPasswordButton>
            </div>
          </form>
        </Form>
      </AuthCard.Content>
    </AuthCard>
  );
}
