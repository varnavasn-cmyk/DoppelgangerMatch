"use client";
import { useTranslations } from "next-intl";
export default function DisclaimerContent() {
  const t = useTranslations("disclaimer");
  return (
    <div>
      <div className="flex flex-col items-center justify-center gap-20">
        <h3 className="text-primary text-center font-poppins md:text-[60px] text-4xl lg:text-[80px] font-bold leading-normal">
          {t("title")}
        </h3>
        <h6 className="text-white font-poppins text-lg font-light leading-xl">
          {t("dis")}
        </h6>
      </div>
      <div className=" flex flex-col gap-6 mt-12">
        <h6 className="text-white font-poppins text-xl font-medium leading-7 tracking-tight">
          {t("section1.title")}
        </h6>
        <ol className="text-white list-disc font-poppins text-base font-light leading-6 ml-4 space-y-2">
          <li>{t("section1.li1")}</li>
          <li>{t("section1.li2")}</li>
        </ol>
        <p className="text-white font-poppins text-xl font-normal leading-7 tracking-tight">
          {t("section1.dis")}
        </p>
      </div>
    </div>
  );
}
