"use client";
import { useTranslations } from "use-intl";
function CookiesPolicyDetels() {
  const t = useTranslations("CookiesPolicy");
  return (
    <div className=" flex flex-col gap-6 mt-24">
      <p className="text-white font-poppins text-lg font-light leading-[27px] tracking-[0.5px]">
        {t("discrition")}
      </p>
      <div>
        <h6 className="text-white font-poppins text-[20px] font-semibold leading-[150%] tracking-[0.5px]">
          {t("subTitle")}
        </h6>
        <p className="text-white font-poppins text-lg font-medium leading-[150%] tracking-[0.5px]">
          {t("subDiscrition")}
        </p>
        <div className="mt-6">
          <p className="text-white font-poppins text-xl font-semibold leading-[150%] tracking-[0.5px] mb-4">
            {t("subTitle1")}
          </p>
          <ol className="text-white font-poppins list-decimal text-[18px] font-normal leading-[150%] tracking-[0.5px] ml-6 space-y-2">
            <li>{t("li1")}</li>
            <li>{t("li2")}</li>
            <li>{t("li3")}</li>
            <li>{t("li4")}</li>
          </ol>
        </div>
        <div className="mt-6">
          <p className="text-white font-poppins text-xl font-semibold leading-[150%] tracking-[0.5px] mb-4">
            {t("subTitle2")}
          </p>
          <ol className="text-white font-poppins text-lg list-disc space-y-2  font-normal leading-[150%] tracking-[0.5px] ml-6">
            <li>{t("li5")}</li>
            <li>{t("li6")}</li>
            <li>{t("li7")}</li>
            <li>{t("li8")}</li>
          </ol>
        </div>
        <div className="mt-6">
          <h6 className="text-white font-poppins text-xl font-semibold leading-[150%] tracking-[0.5px] mb-4">
            {t("subTitle3")}
          </h6>
          <p className="text-white font-poppins text-[18px] font-normal leading-[150%] tracking-[0.5px]">
            {t("li9")}
          </p>
          <ol className="text-white font-poppins text-lg list-disc space-y-2  font-normal leading-[150%] tracking-[0.5px] ml-6">
            <li>{t("li10")}</li>
            <li>{t("li11")}</li>
            <li>{t("li12")}</li>
          </ol>
        </div>
        <div className="mt-6">
          <h6 className="text-white font-poppins text-xl font-bold leading-[150%] tracking-[0.5px] mb-1">
            {t("subTitle4")}
          </h6>
          <p className="text-white font-poppins text-lg font-normal leading-[150%] tracking-[0.5px]">
            {t("li13")}
          </p>
          <div className="mt-6">
            <p className="text-white font-poppins text-lg font-normal leading-[150%] tracking-[0.5px]">
              {t("li14")}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CookiesPolicyDetels;
