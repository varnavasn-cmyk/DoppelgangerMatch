"use client";
import ContactForm from "@/components/From/contactFrom";
import { useTranslations } from "use-intl";
function ContactUsPage() {
  const t = useTranslations("contact-us");
  return (
    <section className="xl:w-[1200px]  xl:px-0 lg:px-20 md:px-10 sm:px-5 px-4 md:py-14 py-8 lg:py-20 mx-auto ">
      <div className="flex flex-col items-center justify-center gap-2">
        <h3 className="text-primary text-center font-poppins md:text-[60px]  text-4xl lg:text-[80px] font-bold leading-normal">
          {t("title")}
        </h3>
        <h6 className="text-[#8896AB] text-center font-poppins text-xl lg:w-[788px] font-medium leading-[30px]">
          {t("description")}
        </h6>
      </div>
      <div className="flex justify-center items-center w-full">
        <div className="rounded-[30px] my-16 w-[80%] bg-[rgba(2,204,216,0.1)] shadow-[0_0_10px_rgba(2,204,216,0.2)] inline-flex p-[50px_49px] flex-col justify-center items-start gap-[15px]">
          <ContactForm />
        </div>
      </div>
    </section>
  );
}

export default ContactUsPage;
