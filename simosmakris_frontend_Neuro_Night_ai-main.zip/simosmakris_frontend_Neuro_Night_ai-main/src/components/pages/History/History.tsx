"use client";
import { UploadFileIcon } from "@/assets/svg";
import { useState } from "react";
import PhotoContent from "./PhotoContent";
import CelebrityContent from "./CelebrityContent";
import VideoContent from "./VideoContent";
import { useGetUserHistoryCountQuery } from "@/redux/features/users/usersApi";
import { Spin } from "antd";

type TabType = "photo" | "celebrity" | "video" | null;

// Component for Video tab content

function History() {
  const [activeTab, setActiveTab] = useState<TabType>(null);
  const { data, isLoading } = useGetUserHistoryCountQuery({});
  const userHistoryCount = data?.data;
  const renderTabContent = () => {
    switch (activeTab) {
      case "photo":
        return <PhotoContent />;
      case "celebrity":
        return <CelebrityContent />;
      case "video":
        return <VideoContent />;
      default:
        return <PhotoContent />;
    }
  };

  return (
    <div>
      <div className="flex flex-row items-center justify-between mb-10">
        <button
          onClick={() => {
            console.log("Photo button clicked");
            setActiveTab(activeTab === "photo" ? null : "photo");
          }}
          className={`flex w-[356px] h-[194px] p-[28px] items-center gap-[24px] flex-shrink-0 rounded-[12px] transition-all duration-200 hover:bg-[#1E293B] ${ activeTab === "photo"
            ? " bg-[#1E293B] ring-2 ring-primary"
            : "bg-[#0F172A]"
            }`}
        >
          <UploadFileIcon />
          <div className="flex flex-col items-start ">
            <h2 className="text-white font-poppins text-lg font-light leading-normal">
              Total Lookalike
            </h2>

            <h6 className="text-xl font-bold">Photo</h6>
            {isLoading ? (
              <Spin />
            ) : (
              <p className="text-white font-poppins text-xl font-semibold leading-normal">
                {userHistoryCount?.totalNormal || 0}
              </p>
            )}
          </div>
        </button>

        <button
          onClick={() => {
            console.log("Celebrity button clicked");
            setActiveTab(activeTab === "celebrity" ? null : "celebrity");
          }}
          className={`flex w-[356px] h-[194px] p-[28px] items-center gap-[24px] flex-shrink-0 rounded-[12px] transition-all duration-200 hover:bg-[#1E293B] ${ activeTab === "celebrity"
            ? "bg-[#1E293B] ring-2 ring-primary"
            : "bg-[#0F172A]"
            }`}
        >
          <UploadFileIcon />
          <div className="flex flex-col items-start ">
            <h2 className="text-white font-poppins text-lg font-light leading-normal">
              Total Celebrity
            </h2>
            <h6 className="text-xl font-bold">Lookalike</h6>
            {isLoading ? (
              <Spin />
            ) : (
              <p className="text-white font-poppins text-xl font-semibold leading-normal">
                {userHistoryCount?.totalCelebrity || 0}
              </p>
            )}
          </div>
        </button>

        <button
          onClick={() => {
            console.log("Video button clicked");
            setActiveTab(activeTab === "video" ? null : "video");
          }}
          className={`flex w-[356px] h-[194px] p-[28px] items-center gap-[24px] flex-shrink-0 rounded-[12px] transition-all duration-200 hover:bg-[#1E293B] ${ activeTab === "video"
            ? "bg-[#1E293B] ring-2 ring-primary"
            : "bg-[#0F172A]"
            }`}
        >
          <UploadFileIcon />
          <div className="flex flex-col items-start ">
            <h2 className="text-white font-poppins text-lg font-light leading-normal">
              Total Morphing Video <br />
            </h2>
            <h6 className="text-xl  font-bold">Video</h6>
            {isLoading ? (
              <Spin />
            ) : (
              <p className="text-white font-poppins text-xl font-semibold leading-normal">
                {userHistoryCount?.totalmorph || 0}
              </p>
            )}
          </div>
        </button>
      </div>

      {/* Tab Content - Shows below the buttons */}
      {renderTabContent()}
    </div>
  );
}

export default History;
