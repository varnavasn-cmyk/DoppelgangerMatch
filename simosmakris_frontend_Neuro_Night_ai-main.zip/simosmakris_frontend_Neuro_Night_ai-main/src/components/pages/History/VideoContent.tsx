/* eslint-disable @typescript-eslint/no-explicit-any */
import { MorphingVideoPlayer } from "@/components/shared/uploadResults/morphing-video-player";
import { VideoShareModal } from "@/components/shared/uploadResults/VideoShareModal";
import { DatePickerDemo } from "@/components/ui/date-picker";
import { useGetUserHistoryMorphvideoQuery } from "@/redux/features/users/usersApi";
import { Spin } from "antd";

import { useState } from "react";

function VideoContent() {
  const [selectedDate, setSelectedDate] = useState<Date>();
  const { data, isLoading } = useGetUserHistoryMorphvideoQuery({
    date: selectedDate,
  });
  const [showModal, setShowModal] = useState(false);
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-32">
        <Spin />
      </div>
    );
  }

  const morphVideos = data?.data?.morphVideos;
  const normalMorphVideos = data?.data?.normalMorphVideos;

  return (
    <section>
      <div className="flex items-start justify-between mb-10">
        <div>
          <h6 className="text-white font-poppins text-xl font-semibold leading-normal">
            All Celebrity Lookalike Photos
          </h6>
          <p className="text-white font-poppins text-sm font-normal leading-normal">
            Today 09-09-2025
          </p>
        </div>
        <DatePickerDemo date={selectedDate} onDateChange={setSelectedDate} />
      </div>
      <div className="grid grid-cols-1 mb-4 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 max-w-7xl mx-auto">
        {morphVideos?.map((videoData: any) => (
          <div key={videoData.id} className="flex justify-center">
            <MorphingVideoPlayer
              video={videoData}
              onDownloadClick={() => setShowModal(true)}
            />

            <VideoShareModal
              video={videoData}
              open={showModal}
              onOpenChange={setShowModal}
            />
          </div>
        ))}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 max-w-7xl mx-auto">
        {normalMorphVideos?.map((videoData: any) => (
          <div key={videoData.id} className="flex justify-center">
            <MorphingVideoPlayer
              video={videoData}
              onDownloadClick={() => setShowModal(true)}
            />

            <VideoShareModal
              video={videoData}
              open={showModal}
              onOpenChange={setShowModal}
            />
          </div>
        ))}
      </div>
    </section>
  );
}

export default VideoContent;
