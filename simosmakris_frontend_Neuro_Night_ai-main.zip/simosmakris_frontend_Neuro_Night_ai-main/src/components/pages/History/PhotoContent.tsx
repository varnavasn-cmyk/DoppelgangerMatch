/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import React, { useState } from "react";
import { DatePickerDemo } from "@/components/ui/date-picker";
import Image from "next/image";
import ImageCard from "@/components/ui/Card/ImageCard";
import { useGetUserHistoryLookLikeQuery } from "@/redux/features/users/usersApi";
import Skeleton from "antd/es/skeleton";

function PhotoContent() {
  const [selectedDate, setSelectedDate] = useState<Date>();
  const { data, isLoading } = useGetUserHistoryLookLikeQuery({
    date: selectedDate,
  });

  return (
    <section>
      <div className="flex items-start justify-between mb-10">
        <div>
          <h6 className="text-white font-poppins text-xl font-semibold leading-normal">
            All Lookalike Photo
          </h6>
          <p className="text-white font-poppins text-sm font-normal leading-normal">
            Today 09-09-2025
          </p>
        </div>
        <DatePickerDemo date={selectedDate} onDateChange={setSelectedDate} />
      </div>
      <div>
        <h2 className="text-white  font-poppins text-2xl font-semibold leading-normal">
          Lookalike Photo
        </h2>
        {isLoading ? (
          <Skeleton active />
        ) : (
          data?.data?.map((item: any) => (
            <div key={item.id} className="mb-10">
              <div className="mt-10 flex items-center justify-start">
                <Image
                  src={item?.bestMatchUrl}
                  alt="uploaded photo"
                  width={196}
                  height={234}
                  className="w-[196px] h-[234px] object-cover rounded-lg"
                />
              </div>

              <h2 className="text-white  font-poppins mt-8 mb-6 text-2xl font-semibold leading-normal">
                Results
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-6 max-w-7xl mx-auto">
                {item?.allMatches?.map((imageData: any, index: number) => (
                  <div key={index} className="flex justify-center">
                    <ImageCard imageData={imageData} />
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
      </div>
    </section>
  );
}

export default PhotoContent;
