/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import React, { useState, useEffect } from "react";
import { useTranslations } from "use-intl";

interface NavItem {
  id: string;
  title: string;
  href: string;
}

const PrivacyPolicy: React.FC = () => {
  const [activeSection, setActiveSection] = useState<string>("");
  const t = useTranslations("Privacy-Policy");

  const navItems: NavItem[] = [
    { id: "info-consent", title: t("section1.title"), href: "#info-consent" },
    {
      id: "what-we-do",
      title: t("section2.title"),
      href: "#what-we-do",
    },
    { id: "disclosure", title: t("section3.title"), href: "#disclosure" },
    { id: "security", title: t("section4.title"), href: "#security" },
    { id: "gdpr", title: t("section5.title"), href: "#gdpr" },
    {
      id: "changes",
      title: t("section6.title"),
      href: "#changes",
    },
    {
      id: "contact",
      title: t("section7.title"),
      href: "#contact",
    },
  ];

  useEffect(() => {
    if (typeof window === "undefined") return; // SSR-safe

    const handleScroll = () => {
      const sections = navItems.map((item) => document.getElementById(item.id));
      const scrollPosition = window.scrollY + 100;

      for (let i = sections.length - 1; i >= 0; i--) {
        const section = sections[i];
        if (section && section.offsetTop <= scrollPosition) {
          setActiveSection(navItems[i].id);
          break;
        }
      }
    };

    window.addEventListener("scroll", handleScroll);

    handleScroll();

    return () => window.removeEventListener("scroll", handleScroll);
  }, [navItems]);

  const scrollToSection = (sectionId: string) => {
    if (typeof window === "undefined") return;

    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-6 gap-8">
      {/* Sidebar Navigation */}
      <div className="lg:col-span-2">
        <div className="sticky top-8 ">
          <nav className="space-y-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`block w-full leading-none text-left font-poppins px-2 text-white  py-2 transition-all duration-100 ${
                  activeSection === item.id
                    ? "  border-l-2 border-primary text-xl font-bold pl-4"
                    : "text-[18px] font-normal hover:text-teal-400 hover:bg-slate-700/50"
                }`}
              >
                {item.title}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:col-span-4">
        <div className="space-y-15">
          <section id="info-consent">
            <h2 className="text-white font-poppins text-[20px] font-bold leading-none mb-2">
              {t("section1.subTitle")}
            </h2>
            <div className="flex flex-col gap-2">
              <p className="text-white font-poppins text-lg/7 font-light ">
                {t("section1.li1")}
              </p>
              <p className="text-white font-poppins text-lg/7  font-light ">
                {t("section1.li2")}
              </p>
              <div>
                <p className="text-white font-poppins text-xl font-medium leading-none">
                  {t("section1.li3")}
                </p>
                <ol
                  className="text-white font-poppins text-lg/7 
                font-light ml-4 list-disc mt-4 "
                >
                  <li>{t("section1.li4")}</li>
                </ol>
              </div>
            </div>
          </section>

          <section id="what-we-do">
            <h2 className="text-white font-poppins text-[20px] font-bold leading-none mb-2">
              {t("section2.subTitle")}
            </h2>
            <div className="flex flex-col gap-2">
              <p className="text-white font-poppins text-lg/7 font-light mb-2 ">
                {t("section2.li1")}
              </p>
              <ol className="text-white font-poppins text-[16px] font-light list-disc ml-4 space-y-2 leading-[24px]">
                <li>{t("section2.li2")}</li>
                <li>{t("section2.li3")}</li>
                <li>{t("section2.li4")}</li>
                <li>{t("section2.li5")}</li>
                <li>{t("section2.li6")}</li>
                <li>{t("section2.li7")}</li>
              </ol>
              <div className="mt-4 space-y-4">
                <p className="text-white font-poppins text-lg/7 font-light leading-[24px]">
                  {t("section2.li8")}
                </p>
                <p className="text-white font-poppins text-lg/7 font-light leading-[24px]">
                  {t("section2.li9")}
                </p>
                <p className="text-white font-poppins text-lg/7 font-light leading-[24px]">
                  {t("section2.li10")}
                </p>
              </div>
            </div>
          </section>

          <section id="disclosure">
            <h2 className="text-white font-poppins text-xl font-bold">
              {t("section3.subTitle")}
            </h2>
            <div className="flex flex-col gap-2 mt-2">
              <p className="text-white font-poppins text-lg/7 font-light ">
                {t("section3.li1")}
              </p>
              <ol className="text-white font-poppins text-[16px] font-light list-disc ml-4 space-y-2 leading-[24px]">
                <li>{t("section3.li2")}</li>
                <li>{t("section3.li3")}</li>
                <li>{t("section3.li4")}</li>
              </ol>
            </div>
          </section>

          <section id="security">
            <h2 className="text-white font-poppins text-[20px] font-bold leading-none mb-2">
              {t("section4.subTitle")}
            </h2>
            <p className="text-white font-poppins text-lg/7 font-light leading-[24px]">
              {t("section4.li1")}
            </p>
          </section>

          <section id="gdpr">
            <h2 className="text-white font-poppins text-[20px] font-bold leading-none mb-2">
              {t("section5.subTitle")}
            </h2>
            <p className="text-white font-poppins text-[18px] font-normal ">
              {t("section5.li1")}
            </p>
            <ol className="text-white font-poppins text-[18px] font-normal ml-4 list-disc mt-4 space-y-2 leading-[28px]">
              <li>{t("section5.li1")}</li>
              <li>{t("section5.li2")}</li>
              <li>{t("section5.li3")}</li>
              <li>{t("section5.li4")}</li>
              <li>{t("section5.li5")}</li>
              <li>{t("section5.li6")}</li>
              <li>{t("section5.li7")}</li>
            </ol>
            <p className="text-white font-poppins text-[18px] font-medium leading-6 mt-3">
              {t("section5.li8")}
            </p>
            <p className="text-white font-poppins text-[18px] font-light leading-6 mt-3">
              {t("section5.li9")}
            </p>
          </section>

          <section id="changes">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section6.subTitle")}
            </h2>
            <div className="text-white font-poppins text-[18px] font-light leading-normal space-y-4 mt-4">
              <p>{t("section6.li1")}</p>
              <p>{t("section6.li2")}</p>
            </div>
          </section>

          <section id="contact">
            <h2 className="text-white font-poppins text-xl font-bold leading-normal">
              {t("section7.subTitle")}
            </h2>
            <div>
              <h6 className="text-white font-poppins text-lg font-normal leading-normal">
                {t("section7.li1")}
              </h6>
              <ol className="text-white font-poppins text-lg font-light leading-normal space-y-1 mt-1 list-disc ml-4">
                <li>{t("section7.li2")}</li>
                <li>{t("section7.li3")}</li>
                <li>{t("section7.li4")}</li>
                <li>{t("section7.li5")}</li>
              </ol>
              <div className="mt-4 space-y-1">
                <h6 className="text-white font-poppins text-lg font-normal leading-normal">
                  {t("section7.li6")}
                </h6>
                <p className="text-white font-poppins text-lg font-light leading-normal">
                  {t("section7.li7")}
                </p>
                <p className="text-white font-poppins text-lg font-light leading-normal">
                  {t("section7.li8")}
                </p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
