// components/StripeWrapper.tsx
"use client";

import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import { ReactNode } from "react";
import { useAppSelector } from "@/redux/hooks";
import { RootState } from "@/redux/store";

// Initialize Stripe outside of component to avoid recreating the object
const stripePromise = loadStripe(
  process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!
);

interface StripeWrapperProps {
  children: ReactNode;
}

export function StripeWrapper({ children }: StripeWrapperProps) {
  const subData = useAppSelector((state: RootState) => state.subscription);
  const clientSecret = subData?.clientSecret;
  // Show loading state while waiting for clientSecret
  if (!clientSecret) {
    return (
      <div className="min-h-screen bg-transparent py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          <div className="bg-transparent p-6 rounded-lg ">
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
              <span className="ml-4 text-primary font-medium">
                Initializing payment...
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const options = {
    clientSecret,
  };

  return (
    <Elements stripe={stripePromise} options={options}>
      {children}
    </Elements>
  );
}
