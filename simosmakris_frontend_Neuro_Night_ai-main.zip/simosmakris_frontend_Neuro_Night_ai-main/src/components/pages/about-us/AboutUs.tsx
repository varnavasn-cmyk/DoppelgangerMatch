"use client";
import { useTranslations } from "use-intl";

function AboutUs() {
  const t = useTranslations("about-us");
  return (
    <section className="xl:w-[1200px]  xl:px-0 lg:px-20 md:px-10 sm:px-5 px-4 py-20 mx-auto">
      <h3 className="text-primary text-center font-poppins md:text-[60px] sm:text-[36px] text-3xl lg:text-[80px] font-bold leading-normal md:mb-[60px] mb-10 lg:mb-[108px]">
        {t("title")}
      </h3>
      <div>
        <div className="flex flex-col gap-2 mb-12">
          <h5 className="text-white font-poppins text-[20px] font-bold leading-[28px] tracking-[0.5px]">
            {t("title1")}
          </h5>
          <p className="text-white font-poppins text-[18px] font-light leading-[150%] tracking-[0.5px] text-wrap ">
            {t("desc1")}
          </p>
        </div>
        <div className="flex flex-col gap-2 mb-12">
          <h5 className="text-white font-poppins text-[20px] font-bold leading-[28px] tracking-[0.5px]">
            {t("title2")}
          </h5>
          <p className="text-white font-poppins text-[18px] font-light leading-[150%] tracking-[0.5px]  text-wrap">
            {t("desc2")}
          </p>
        </div>
        <div className="flex flex-col gap-2 mb-12">
          <h5 className="text-white font-poppins text-[20px] font-bold leading-[28px] tracking-[0.5px]">
            {t("title3")}
          </h5>
          <p className="text-white font-poppins text-[18px] font-light leading-[150%] tracking-[0.5px] text-wrap ">
            {t("desc3")}
          </p>
        </div>
        <div>
          <h6>{t("title4")}</h6>
          <ol className="text-white list-disc font-poppins text-[18px] font-medium leading-[38px] tracking-[0.5px] ml-4">
            <li>{t("li1")}</li>
            <li>{t("li2")}</li>
            <li>{t("li3")}</li>
            <li> {t("li4")}</li>
            <li>{t("li5")}</li>
          </ol>
          <p className="text-white font-poppins text-[18px] font-light leading-[150%] tracking-[0.5px] mt-3 text-wrap">
            {t("li6")}
          </p>
        </div>
      </div>
    </section>
  );
}

export default AboutUs;
