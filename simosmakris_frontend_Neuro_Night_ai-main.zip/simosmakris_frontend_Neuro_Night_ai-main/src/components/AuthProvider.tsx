"use client";

import React, { createContext, useContext, useState } from "react";



interface User {
  id: string;
  email: string;
  role: string;
  fullName: string;
  profilePic: string;
  phone: string;
  isVerified: boolean;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  token?: string | undefined;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Type guard to validate User structure
function isValidUser(user: User): user is User {
  return (
    user &&
    typeof user.id === "string" &&
    typeof user.email === "string" &&
    typeof user.role === "string" &&
    typeof user.fullName === "string" &&
    typeof user.profilePic === "string" &&
    typeof user.phone === "string" &&
    typeof user.isVerified === "boolean"

  );
}

export function AuthProvider({
  children,
  initialUser,
  token,
}: {
  children: React.ReactNode;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  initialUser?: any;
  token?: string;
}) {
  // Validate and normalize the initialUser data
  const normalizedInitialUser =
    initialUser && isValidUser(initialUser)
      ? {
        ...initialUser,
      }
      : null;

  const [user, setUser] = useState<User | null>(normalizedInitialUser);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });

      if (response.ok) {
        const { user: userData } = await response.json();
        if (isValidUser(userData)) {
          setUser({
            ...userData,
          });
          return true;
        }
      }
      return false;
    } catch {
      return false;
    }
  };

  const logout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } catch (error) {
      console.error("Logout error:", error);
    } finally {
      setUser(null);
      window.location.href = "/";
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        token,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
