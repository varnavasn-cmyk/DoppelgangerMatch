import Loading from "./Loading";


export default function PageLoader() {
  return (
    <div className="grid h-screen place-items-center">
      <Loading />
    </div>
  );
}
