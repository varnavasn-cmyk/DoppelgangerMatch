"use client";
/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState } from "react";
import { SlSocialFacebook } from "react-icons/sl";
import { FaInstagram, FaYoutube } from "react-icons/fa";
import { SiTiktok } from "react-icons/si";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/Checkbox/Checkbox";
import { toast } from "sonner";
import Link from "next/link";
import { usePrefixedPath } from "@/lib/localePath";
import { useTranslations } from "next-intl";

const Footer = () => {
  const [email, setEmail] = useState("");
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const getPrefixedPath = usePrefixedPath();
  const t = useTranslations("home.footer");

  const handleSubscribe = async () => {
    if (!email) {
      toast.error("Please enter your email.");
      return;
    }
    if (!/\S+@\S+\.\S+/.test(email)) {
      toast.error("Please enter a valid email address.");
      return;
    }
    if (!agreed) {
      toast.error("You must accept the terms to subscribe.");
      return;
    }

    try {
      setLoading(true);

      const res = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}/subscriber/create-subscriber`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email, accepted: agreed }),
        }
      );

      if (!res.ok) {
        throw new Error("Subscription failed");
      }

      toast.success("Subscribed successfully!");
      setEmail("");
      setAgreed(false);
    } catch (error: any) {
      toast.error(error.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section>
      <div className="flex w-full lg:flex-row md:flex-col flex-col ">
        <div className=" xl:w-[1200px] xl:px-0 lg:px-20 md:px-6 sm:px-3 px-1 md:py-12 py-8 lg:py-20 mx-auto">
          <div className="flex justify-between ">
            <div>
              <h5 className="text-white font-poppins text-[18px] font-bold leading-[28px]">
                {t("title")}
              </h5>

              <div className="flex items-center mt-5">
                <Input
                  className="bg-white xl:w-[360px] text-black h-12"
                  type="email"
                  placeholder={t("placholder")}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                <Button
                  className="bg-primary text-white px-6 py-6 font-bold rounded-lg ml-4"
                  onClick={handleSubscribe}
                  disabled={loading}
                >
                  {loading ? "Subscribing..." : "Subscribe"}
                </Button>
              </div>

              <div className="flex  items-center mt-5 gap-3">
                <Checkbox
                  id="terms"
                  checked={agreed}
                  onCheckedChange={(checked) => setAgreed(!!checked)}
                  className="bg-white"
                />
                <p>{t("actiove")}</p>
              </div>
              <Label
                htmlFor="terms"
                className="lg:w-[318px] w-full text-wrap text-white font-poppins text-[14px] font-normal leading-normal"
              >
                {t("subscribe")}
              </Label>
            </div>
            <div className=""></div>
          </div>
        </div>

        <div className="relative">
          <div className="absolute right-0">
            <div className="xl:w-[606px] lg:w-[506px] lg:h-[200px] h-[150px] w-[300px] sm:w-[406px] md:w-[600px]   xl:h-[258px] shrink-0 bg-[rgba(2,204,216,0.5)] [clip-path:polygon(100%_0,100%_100%,0_100%,13%_0)]"></div>
          </div>
          <div className="absolute right-0">
            <div className="relative">
              <div className="xl:w-[504px] lg:w-[406px] lg:h-[200px] h-[150px] w-[270px] sm:w-[356px]  md:w-[500px] xl:h-[258px] shrink-0 bg-[rgba(2,204,216,0.5)] [clip-path:polygon(100%_0,100%_100%,0_100%,16%_0)]"></div>
              <div className="absolute translate-x-1/2 -translate-y-1/2 top-1/2  md:left-10 -left-20 ">
                <div className="flex gap-4  ">
                  <div
                    onClick={() =>
                      window.open(
                        "https://www.facebook.com/share/14N3of1dGLu/?mibextid=wwXIfr",
                        "_blank"
                      )
                    }
                    className="w-[44px] h-[44px] shrink-0 rounded-[10px] bg-white flex justify-center items-center"
                  >
                    <SlSocialFacebook className="text-primary text-3xl" />
                  </div>
                  <div
                    onClick={() =>
                      window.open(
                        "https://www.instagram.com/doppelgangermatchofficial?igsh=MTQzeDA5Z2U0YTh4bw%3D%3D&utm_source=qr",
                        "_blank"
                      )
                    }
                    className="w-[44px] h-[44px] shrink-0 rounded-[10px] bg-white flex justify-center items-center"
                  >
                    <FaInstagram className="text-primary text-3xl" />
                  </div>
                  <div
                    onClick={() =>
                      window.open(
                        "https://www.tiktok.com/@doppelgangermatch",
                        "_blank"
                      )
                    }
                    className="w-[44px] h-[44px] shrink-0 rounded-[10px] bg-white flex justify-center items-center"
                  >
                    <SiTiktok className="text-primary text-3xl" />
                  </div>
                  <div
                    onClick={() =>
                      window.open(
                        "https://www.youtube.com/@DoppelgangerMatch",
                        "_blank"
                      )
                    }
                    className="w-[44px] h-[44px] shrink-0 rounded-[10px] bg-white flex justify-center items-center"
                  >
                    <FaYoutube className="text-primary text-3xl" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="flex justify-center  lg:pt-0 md:pt-6 flex-col items-center mt-40 pb-10">
        <ul className="text-white font-poppins text-nowrap  flex-wrap lg:flex-nowrap md:items-center md:w-full md:justify-center text-[15px] font-normal leading-normal flex md:gap-12 gap-4 ">
          <li>
            <Link href={getPrefixedPath("/about-us")}>About Us</Link>
          </li>
          <li>
            <Link href={getPrefixedPath("/privacy-policy")}>
              Privacy Policy
            </Link>
          </li>
          <li>
            <Link href={getPrefixedPath("/terms&conditions")}>
              Terms & Conditions
            </Link>
          </li>
          <li>
            <Link href={getPrefixedPath("/cookies-policy")}>
              Cookies Policy
            </Link>
          </li>
          <li>
            <Link href={getPrefixedPath("/refund-policy")}>Refund Policy</Link>
          </li>
          <li>
            <Link href={getPrefixedPath("/disclaimer")}>Disclaimer</Link>
          </li>
        </ul>
        <p className="text-[#02CCD8] text-center font-inter text-[16px] font-normal leading-[26px] mt-12">
          {t("copyright")}
        </p>
      </div>
    </section>
  );
};

export default Footer;
