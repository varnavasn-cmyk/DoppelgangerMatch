"use client";
import { usePathname } from "next/navigation";
import { usePrefixedPath } from "@/lib/localePath";
import { useState } from "react";
import { FiArrowDownCircle } from "react-icons/fi";
const Faqs = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const path = usePathname();
  const getPrefixedPath = usePrefixedPath();

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const faqData = [
    {
      question: "How does Doppelganger Match work?",
      answer:
        "Upload a photo, and our AI scans your facial features to find people and celebrities who look like you. In seconds, you’ll see your top matches with similarity scores.",
    },
    {
      question: "What kind of photo should I upload?",
      answer:
        "For the best results, use a clear, well-lit photo with your face visible and facing forward. Avoid sunglasses, masks, or heavy filters.",
    },
    {
      question: "Can I find both normal and celebrity lookalikes?",
      answer:
        "Yes! Doppelganger Match lets you discover both everyday users and celebrities who resemble you. The free version gives you up to 3 matches with a watermark. Premium plans unlock more results, HD downloads, and watermark-free images.",
    },
    {
      question: "What is the Morphing Video feature?",
      answer:
        "It’s a short HD video that smoothly transforms your face into your lookalike. Morphing Videos are a premium-only feature available after purchasing a Lookalike or Celebrity Match plan.",
    },
    {
      question: "Is Doppelganger Match free to use?",
      answer:
        "Yes. You can try it for free with 3 matches (with watermark). To get unlimited results, celebrity lookalikes, high-resolution downloads, and morphing videos, you’ll need a premium plan.",
    },
    {
      question: "Are my photos and data safe?",
      answer:
        "Absolutely. We process your photos securely and never share them without your consent. You can delete your uploads or account at any time.",
    },
    {
      question: "Can I use my results for professional purposes?",
      answer:
        "No. Doppelganger Match is designed for fun and entertainment only. Results should not be used for legal, medical, or official identity verification.",
    },
    {
      question: "Do you offer refunds?",
      answer:
        "Refunds are only available if you were charged by mistake due to a technical issue. One-time purchases like morphing videos are non-refundable.",
    },
    {
      question: "How do I delete my account?",
      answer:
        "You can delete your account anytime from your profile settings. Once deleted, your data and photos are permanently removed.",
    },
    {
      question: "Can I share my results on social media?",
      answer:
        "Yes! You can easily share your lookalike results and morphing videos directly on platforms like Instagram, TikTok, and Facebook.",
    },
    {
      question: "What makes Doppelganger Match different?",
      answer:
        "We combine a large global image database with advanced AI to give you fun, accurate, and diverse matches — all while keeping your data private.",
    },
    {
      question: "Will my lookalike be from anywhere in the world?",
      answer:
        "Yes! Our database is global, so your doppelganger could be from your country or anywhere else in the world 🌍.",
    },
    {
      question: "Can I try again with another photo?",
      answer:
        "Of course! Uploading different photos may give you new matches or even a surprise celebrity twin.",
    },
    {
      question: "What’s the most popular feature?",
      answer:
        "Most users love the Morphing Video — watching your face seamlessly transform into your lookalike is pure magic ✨.",
    },
  ];

  return (
    <div>
      {(path === "/" || path === getPrefixedPath("/")
        ? faqData.slice(0, 5)
        : faqData
      ).map((item, index) => (
        <div key={index} className="mb-4">
          <div
            className="flex justify-between items-center cursor-pointer"
            onClick={() => toggleAccordion(index)}
          >
            <h6 className="lg:w-[456px] w-full text-white font-poppins text-base md:text-xl font-bold">
              Q-{index + 1}. {item.question}
            </h6>
            <FiArrowDownCircle
              className={`transform transition-transform text-2xl duration-300 text-primary ${
                activeIndex === index ? "rotate-180" : ""
              }`}
            />
          </div>

          {activeIndex === index && (
            <div className="mt-2 pt-2 border-t-[1px] border-primary/20">
              <p className="lg:w-[536px] w-full text-[#C9C9C9] font-poppins md:text-base text-sm font-medium leading-[24px]">
                {item.answer}
              </p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default Faqs;
