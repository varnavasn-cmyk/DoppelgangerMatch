"use client";
import { Button } from "@/components/ui/button";
import PricePlan from "@/components/ui/Card/PricePlan";
import { usePrefixedPath } from "@/lib/localePath";
import { useGetPlansQuery } from "@/redux/features/users/usersApi";
import Skeleton from "antd/es/skeleton";
import { useTranslations } from "use-intl";
import { usePathname } from "next/navigation";

type Feature = string;
export interface Plan {
  active: boolean;
  amount: number;
  createdAt: string;
  currency: string;
  description: string;
  features: Feature[];
  freeTrialDays: number | null;
  id: string;
  interval: string;
  intervalCount: number;
  planName: string;
  planType: string;
  priceId: string;
  productId: string;
  updatedAt: string;
}

const PricingPlan = () => {
  const path = usePathname();
  const { data, isLoading } = useGetPlansQuery({});
  const t = useTranslations("plan-page");
  const getPrefixedPath = usePrefixedPath();
  const planPrices = data?.data || [];
  return (
    <div className=" xl:w-[1200px] xl:px-0 lg:px-20 md:px-6 sm:px-3 px-1 md:py-12 py-8 lg:py-20 mx-auto">
      {path === getPrefixedPath("/price") || path === "/price" ? null : (
        <div className="flex flex-col justify-center items-center">
          <Button variant="outline" className="rounded-full">
            Pricing
          </Button>
          <h5 className="text-[#02CCD8] text-center font-poppins md:text-3xl text-xl lg:text-[48px] font-normal leading-[60px] tracking-[-0.96px] my-4">
            {t("title")}
          </h5>
          <p className="text-white text-center font-poppins text-[12px] md:text-[18px] font-normal leading-[30px]">
            {t("description")}
          </p>
        </div>
      )}

      <div className="flex gap-8 flex-wrap justify-center my-8">
        {isLoading ? (
          <Skeleton active />
        ) : (
          planPrices?.map((plan: Plan) => (
            <PricePlan key={plan.id} plan={plan} />
          ))
        )}
      </div>
    </div>
  );
};

export default PricingPlan;
