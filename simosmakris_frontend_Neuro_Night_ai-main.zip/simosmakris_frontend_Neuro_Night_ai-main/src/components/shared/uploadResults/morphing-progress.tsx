
/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowRight } from "lucide-react";
import { DotLottieReact } from "@lottiefiles/dotlottie-react";

interface MorphingProgressProps {
  progress: number;
  status: string;
  isMorphing?: boolean;
  morphingStatus?: string;
  onReset?: () => void;
}

export function MorphingProgress({
  progress,
  status,
  isMorphing = false,
  morphingStatus = "Analyzing...",
}: MorphingProgressProps) {
  const [currentMorphingProgress, setCurrentMorphingProgress] = useState(0);
  const [currentMorphingStatus, setCurrentMorphingStatus] =
    useState(morphingStatus);

  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const hasSubmittedRef = useRef(false); // Prevent multiple submissions
  const submitDataRef = useRef<any>(null); // Track what data was submitted

  // Handle morphing progress simulation
  useEffect(() => {
    if (isMorphing) {
      setCurrentMorphingProgress(0);
      setCurrentMorphingStatus("Analyzing Morphing...");

      // Simulate progress up to 95% while API is processing
      let currentProgress = 0;
      progressIntervalRef.current = setInterval(() => {
        currentProgress += Math.random() * 10;
        if (currentProgress >= 95) {
          currentProgress = 95;
          if (progressIntervalRef.current) {
            clearInterval(progressIntervalRef.current);
          }
        }
        setCurrentMorphingProgress(Math.min(currentProgress, 95));
      }, 500);
    } else if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
      progressIntervalRef.current = null;
    }
  }, [isMorphing]);

  // 🔹 GUARANTEED SINGLE API CALL - FIXED


  // Reset when component unmounts or morphing completes
  useEffect(() => {
    return () => {
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
      // Optional: Reset submission state when component unmounts
      hasSubmittedRef.current = false;
      submitDataRef.current = null;
    };
  }, []);

  // Determine which progress to display
  const displayProgress = isMorphing ? currentMorphingProgress : progress;
  const displayStatus = isMorphing ? currentMorphingStatus : status;

  return (
    <div className="flex flex-col items-center gap-8 w-full max-w-4xl mx-auto">
      {/* Robot Character */}
      <div className="relative w-full max-w-3xl">
        <div className="border-2 border-dashed border-gray-600 rounded-2xl p-12 flex items-center justify-center bg-gradient-to-br from-teal-950/30 to-blue-950/30">
          <div className="relative w-64 h-64">
            <DotLottieReact
              src="https://lottie.host/fca9ff6a-f4d6-4aa8-9d3f-162ebbea0e0d/uLGlavgi1E.lottie"
              loop
              autoplay
            />
          </div>
        </div>
      </div>

      {/* Progress Section */}
      <div className="w-full space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-purple-400 text-lg font-medium">
            {displayStatus}
          </span>
          <span className="text-purple-400 text-lg font-medium">
            {Math.round(displayProgress)}%
          </span>
        </div>

        {/* Progress Bar */}
        <div className="relative h-3 bg-gray-700 rounded-full overflow-hidden">
          <div
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-purple-500 to-purple-600 rounded-full transition-all duration-500 ease-out"
            style={{
              width: `${
                isMorphing ? currentMorphingProgress : displayProgress
              }%`,
            }}
          />
        </div>

        <p className="text-gray-400 text-center text-sm">
          {isMorphing
            ? "Processing morphing transformations... Shapes are being analyzed and converted."
            : "Watch shapes morph into perfection as every detail transforms seamlessly into a stunning final design."}
        </p>

        {displayProgress < 100 && (
          <div className="flex items-center justify-center gap-2 text-purple-400 font-medium">
            <span>
              {isMorphing ? "Morphing in progress..." : "Analyzing..."}
            </span>
            <ArrowRight className="w-5 h-5" />
          </div>
        )}
      </div>
    </div>
  );
}
