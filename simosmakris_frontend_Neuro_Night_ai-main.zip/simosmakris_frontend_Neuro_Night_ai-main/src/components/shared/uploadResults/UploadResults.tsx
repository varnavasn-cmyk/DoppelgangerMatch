/* eslint-disable @typescript-eslint/no-unused-vars */
"use client";
import { useState } from "react";
import { UploadPhotoIcon } from "@/assets/svg";
import { Button } from "@/components/ui/button";
import { GoDotFill } from "react-icons/go";
import webIcon from "@/assets/icons/webcam.svg";
import Image from "next/image";
import { usePathname } from "next/navigation";
import SimpleWebcamModal from "@/components/ui/webcam/WebcamModal";

const UploadResults = () => {
  const path = usePathname();
  const [isWebcamModalOpen, setIsWebcamModalOpen] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);

  const handleWebcamClick = () => {
    setIsWebcamModalOpen(true);
  };

  const handleImageCapture = (imageData: string) => {
    setCapturedImage(imageData);
    // You can also convert base64 to file if needed for upload
    console.log("Image captured:", imageData);

    // Optional: Convert to File object for upload
    // const file = dataURLtoFile(imageData, 'webcam-photo.jpg');
    // handleFileUpload(file);
  };

  // Utility function to convert base64 to File (optional)
  const dataURLtoFile = (dataurl: string, filename: string) => {
    const arr = dataurl.split(",");
    const mime = arr[0].match(/:(.*?);/)![1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  };

  return (
    <>
      <div
        className=" w-[886px]  flex flex-col rounded-[20px] border border-[rgba(1,218,226,0.7)] ]"
        style={{
          marginTop: path === "/upload-photo" ? "40px" : "54px",
        }}
      >
        <div className="items-center text-center ">
          {path === "/upload-photo" ? (
            <div className="flex flex-col items-start px-10">
              <h3 className="text-white font-poppins text-xl font-bold leading-none pt-4">
                Select Photo
              </h3>
              <p className="text-white font-poppins text-xl text-nowrap font-normal leading-none tracking-[-0.22px] pb-4 pt-2">
                Choose a high-quality photo with a clear view of your face for
                the best results
              </p>
            </div>
          ) : (
            <p className="text-white font-poppins text-[20px] text-nowrap font-normal leading-none tracking-[-0.22px] py-4 ">
              Choose a high-quality photo with a clear view of your face for the
              best results
            </p>
          )}

          <div className="w-full h-[1px] bg-[rgba(1,218,226,0.2)]" />

          {/* Show captured image if available */}
          {capturedImage && (
            <div className="p-6">
              <div className="mb-4">
                <p className="text-white font-poppins text-lg font-semibold mb-2">
                  Captured Photo:
                </p>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={capturedImage}
                  alt="Captured from webcam"
                  className="max-w-md mx-auto rounded-lg border border-[rgba(1,218,226,0.7)]"
                />
              </div>
              <div className="flex gap-4 justify-center">
                <Button
                  onClick={() => setCapturedImage(null)}
                  variant="outline"
                  className="border-[1px] border-primary"
                >
                  Remove Photo
                </Button>
                <Button
                  onClick={handleWebcamClick}
                  variant="outline"
                  className="border-[1px] border-primary"
                >
                  Take Another Photo
                </Button>
                <Button
                  onClick={() => console.log("uploading captured image")}
                  className="bg-primary text-white hover:bg-[rgba(0,176,185,0.8)]"
                >
                  Upload Photo
                </Button>
              </div>
            </div>
          )}

          <div className="flex justify-center flex-col items-center h-full py-10 gap-6">
            <button
              onClick={() => console.log("upload")}
              className="w-[519px] h-[218px] shrink-0 rounded-[15px] bg-[#02CCD8]  flex flex-col justify-center items-center gap-4 cursor-pointer hover:bg-[rgba(0,176,185,0.8)] transition duration-300"
            >
              <UploadPhotoIcon />
              <h4 className="text-white font-poppins text-[30px] font-semibold leading-none tracking-[-0.33px]">
                Upload a Photo
              </h4>
              <p className="text-white font-poppins text-[12px] font-normal leading-none tracking-[-0.132px]">
                Click to browse or drag and drop your image here
              </p>
              <div className="text-white font-poppins text-[12px] font-normal leading-none tracking-[-0.132px] flex gap-1">
                Supports JPG, PNG, WebP
                <GoDotFill />
                Max 3MB
              </div>
            </button>
            <h5 className="text-white font-poppins text-[18px] font-bold leading-none tracking-[-0.198px]">
              Or
            </h5>
            <Button
              onClick={handleWebcamClick}
              variant="outline"
              className="text-sm  border-[1px] border-primary rounded-lg font-bold"
            >
              Use Webcam <WebCamIcon />
            </Button>
          </div>
        </div>
      </div>

      {/* Webcam Modal */}
      <SimpleWebcamModal
        isOpen={isWebcamModalOpen}
        onClose={() => setIsWebcamModalOpen(false)}
        onImageCapture={handleImageCapture}
      />
    </>
  );
};

export default UploadResults;

export function WebCamIcon() {
  return <Image src={webIcon} alt="webcam icon" className="size-6" />;
}
