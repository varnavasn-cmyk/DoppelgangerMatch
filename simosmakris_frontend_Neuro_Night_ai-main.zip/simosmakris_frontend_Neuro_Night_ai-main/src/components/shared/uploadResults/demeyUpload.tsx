/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";
import { useState, useRef, useEffect, use } from "react";
import type React from "react";
import { usePathname, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { X, Check } from "lucide-react";
import { GoDotFill } from "react-icons/go";
import Image from "next/image";
import SimpleWebcamModal from "@/components/ui/webcam/WebcamModal";
import { useAppDispatch, useAppSelector } from "@/redux/hooks";
import { store, type RootState } from "@/redux/store";
import ImageCard, { type CardData } from "@/components/ui/Card/ImageCard";
import { UnlockVideoIcon, UploadPhotoIcon } from "@/assets/svg";
import { WebCamIcon } from "./UploadResults";
import { LoadingOutlined } from "@ant-design/icons";
import {
  useFreeUploadLookAlikeImageMutation,
  useGetMeUserQuery,
  useGetPlansQuery,
  useUploadLookACelebritiesImageMutation,
  useUploadLookAlikeImageMutation,
  useUploadMakeMorphingVideoMutation,
} from "@/redux/features/users/usersApi";
import { toast } from "sonner";
import { MorphingProgress } from "./morphing-progress";
import {
  MorphingVideoPlayer,
  MorphVideoResponse,
} from "./morphing-video-player";
import {
  canGuestUpload,
  getGuestUploadCount,
  incrementGuestUploadCount,
  MAX_FREE_UPLOADS,
} from "@/lib/uploadLimit";
import {
  clearMorphCredentials,
  selectMorphCredentials,
  setMorphCredentials,
} from "@/redux/features/users/morphSlice";
import { useSelector } from "react-redux";
import { VideoShareModal } from "./VideoShareModal";
import {
  resetSubmit,
  selectSubmitData,
} from "@/redux/features/payment/submitSlice";
import Swal from "sweetalert2";
import { Spin } from "antd";
import { usePrefixedPath } from "@/lib/localePath";

interface UploadedImage {
  id: string;
  file: File;
  preview: string;
  status: "uploading" | "analyzing" | "complete" | "error";
  progress: number;
  apiResponse?: any;
}
import { useTranslations } from "next-intl";

interface ImageUploadFlowProps {
  maxImages?: number;
  onImagesComplete?: (images: UploadedImage[]) => void;
}

const ImageUploadFlow = ({
  maxImages = 1,
  onImagesComplete,
}: ImageUploadFlowProps) => {
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isWebcamModalOpen, setIsWebcamModalOpen] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [response, setResponse] = useState<any>(null);
  const [showModal, setShowModal] = useState(false);
  const [morphingProgress, setMorphingProgress] = useState(0);
  const [morphingStatus, setMorphingStatus] = useState("Ready to morph");
  const [showMorphingUI, setShowMorphingUI] = useState(false);
  const [morphResult, setMorphResult] = useState<MorphVideoResponse | null>(
    null
  );
  const getPrefixedPath = usePrefixedPath();
  const hasExecutedRef = useRef(false); // ✅ Prevents double execution
  const router = useRouter();
  const dispatch = useAppDispatch();
  const submitData = useSelector(selectSubmitData);
  const [uploadMakeMorphingVideo, { isLoading: isMorphing }] =
    useUploadMakeMorphingVideoMutation();
  const [freeUploadNormalImage] = useFreeUploadLookAlikeImageMutation();
  const token = useAppSelector((state: RootState) => state?.auth?.access_token);
  const [uploadLookAlikeImage] = useUploadLookAlikeImageMutation();
  const [uploadCelebrityLookAlikeImage] =
    useUploadLookACelebritiesImageMutation();
  const {
    data,
    refetch,
    isLoading: userLoading,
    isFetching,
  } = useGetMeUserQuery({});
  useEffect(() => {
    refetch();
  }, [refetch]);
  const t = useTranslations("home.banner");

  const { data: plan, isLoading } = useGetPlansQuery({});
  const planPrices = plan?.data || [];
  const celebrityLookalikeId = planPrices.find(
    (p: any) => p.planType === "CELEBRITY_LOOKALIKE"
  )?.id;
  const LookalikeId = planPrices.find(
    (p: any) => p.planType === "LOOKALIKE"
  )?.id;
  const MORPHINGId = planPrices.find((p: any) => p.planType === "MORPHING")?.id;
  const path = usePathname();
  const morphData = useSelector(selectMorphCredentials);
  const user = useAppSelector((state: RootState) => state.auth.access_token);

  console.log("User Access Token:", user);

  // morphing video submit function
  const handleSubmit = async (data: {
    id: string;
    user_image_key: string;
    celebrity_image_key: string;
    bucket: string;
  }) => {
    // Reset states
    setShowMorphingUI(true);
    setMorphingProgress(0);
    setMorphingStatus("Analyzing Morphing...");
    setMorphResult(null);

    // Build payload with fallbacks
    const id = response?.celebrity?.id || morphData?.id;
    const payload = {
      user_image_key:
        data.user_image_key ||
        response?.celebrity?.morphCredentials?.user_image_key ||
        morphData?.user_image_key,
      celebrity_image_key:
        data.celebrity_image_key ||
        response?.celebrity?.morphCredentials?.celebrity_image_key ||
        morphData?.celebrity_image_key,
      bucket: data.bucket || morphData?.bucket || "normal",
    };

    // Validate required fields
    if (
      !payload.user_image_key ||
      !payload.celebrity_image_key ||
      !payload.bucket
    ) {
      toast.error("Missing required morphing data");
      setShowMorphingUI(false);
      console.error("❌ Incomplete payload:", payload);
      return;
    }

    console.log("📦 Sending payload:", payload);

    try {
      // Start progress animation
      const progressInterval = setInterval(() => {
        setMorphingProgress((prev) => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + Math.random() * 15;
        });
      }, 500);

      // ----------------------------
      // 🔹 Use fetch with cache control
      // ----------------------------
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/morph-video/create-morph-video/${id}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`, // include if needed
          },
          body: JSON.stringify(payload),
          cache: "force-cache",
        }
      );

      const apiResponse = await response.json();

      clearInterval(progressInterval);

      if (apiResponse?.success) {
        dispatch(resetSubmit());
        dispatch(clearMorphCredentials());
        setMorphingStatus("Morphing Complete");
        toast.success("Morph video successfully created!");
        setMorphResult(apiResponse?.data);
        console.log("✅ Execution complete", apiResponse?.data);

        // Animate final progress fill
        for (let i = 0; i <= 100; i += 10) {
          setMorphingProgress(i);
          await new Promise((resolve) => setTimeout(resolve, 300));
        }

        setMorphingStatus("Complete!");
      } else {
        throw new Error(
          apiResponse?.message || "API response indicates failure"
        );
      }
    } catch (error) {
      console.error("❌ Morphing failed:", error);
      setMorphingStatus("Error");
      toast.error("Failed to create morph video!");
    }
  };
  useEffect(() => {
    if (submitData && !hasExecutedRef.current) {
      console.log("✅ Component B: Executing handleSubmit");
      hasExecutedRef.current = true;
      handleSubmit(submitData);
    }
  }, []);

  if (userLoading || isFetching) {
    return (
      <div className="flex justify-center items-center">
        <LoadingOutlined style={{ fontSize: 48 }} spin />
      </div>
    );
  }
  const userPlan = data?.data;
  console.log(userPlan, "by userPland buy plan");

  const handleWebcamClick = () => {
    setIsWebcamModalOpen(true);
  };

  const handleImageCapture = (imageData: string) => {
    setCapturedImage(imageData);
  };

  const dataURLtoFile = (dataurl: string, filename: string) => {
    const arr = dataurl.split(",");
    const mime = arr[0].match(/:(.*?);/)![1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  };

  const handleFileSelect = (files: FileList | null) => {
    if (!files) return;
    if (user) {
      if (
        userPlan?.hasLookalike === false &&
        userPlan?.hasCelebrityLookalike === false
      ) {
        Swal.fire({
          icon: "info",
          title: "Purchase Plan",
          text: "Purchase Celebrity or Lookalike Plan to continue",
          showConfirmButton: false,
          showCancelButton: true,
          cancelButtonText: "Plan Page",
          cancelButtonColor: "#6461FC",
          allowOutsideClick: false,
        }).then((result) => {
          if (result.dismiss === Swal.DismissReason.cancel) {
            router.push(getPrefixedPath("/price")); // change to your actual plan route
          }
        });
        return;
      }
    }
    if (!user) {
      if (!canGuestUpload()) {
        Swal.fire({
          icon: "info",
          title: "Upgrade Required",
          text: `You've used all ${MAX_FREE_UPLOADS} free uploads. Purchase a Celebrity or Lookalike Plan to continue.`,
          showConfirmButton: false,
          showCancelButton: true,
          cancelButtonText: "Go to Plans",
          cancelButtonColor: "#6461FC",
          timer: 3000,
          allowOutsideClick: false,
          customClass: {
            title: "font-bold text-lg",
            popup: "rounded-xl p-6",
            cancelButton: "px-4 py-2 text-white font-medium",
          },
        }).then((result) => {
          if (result.dismiss === Swal.DismissReason.cancel) {
            router.push(getPrefixedPath("/login")); // Replace with your actual plans route
          }
        });

        return; // stop further execution
      }
    }

    const newImages: UploadedImage[] = [];
    const remainingSlots = maxImages - images.length;
    const filesToProcess = Math.min(files.length, remainingSlots);

    for (let i = 0; i < filesToProcess; i++) {
      const file = files[i];
      if (file.type.startsWith("image/")) {
        const id = Date.now() + i + "";
        const preview = URL.createObjectURL(file);

        newImages.push({
          id,
          file,
          preview,
          status: "uploading",
          progress: 0,
        });
      }
    }

    setImages((prev) => [...prev, ...newImages]);

    newImages.forEach((image) => {
      uploadToBackend(image.file);
    });
  };

  const handleRetryUpload = (file: File | null) => {
    setImages((prev) => prev.filter((img) => img.file !== file));
    toast.info("Image removed. Please upload again.");
  };

  const uploadToBackend = async (file: File) => {
    try {
      const maxSizeInBytes = 3 * 1024 * 1024; // 3MB

      if (file.size > maxSizeInBytes) {
        const fileSizeInMB = (file.size / (1024 * 1024)).toFixed(2);
        toast.error(
          `File size exceeds 3MB limit! Current size: ${fileSizeInMB}MB`
        );

        setImages((prev) =>
          prev.map((img) =>
            img.file === file
              ? {
                  ...img,
                  status: "error" as const,
                  progress: 0,
                }
              : img
          )
        );
        return;
      }

      const formData = new FormData();
      formData.append("file", file);

      setImages((prev) =>
        prev.map((img) => (img.file === file ? { ...img, progress: 10 } : img))
      );

      let apiResponse: any;

      if (userPlan?.hasLookalike === true) {
        const response = await uploadLookAlikeImage(formData);
        apiResponse = response.data;
      } else if (userPlan?.hasCelebrityLookalike === true) {
        const response = await uploadCelebrityLookAlikeImage(formData);
        apiResponse = response.data;
      } else {
        if (!user) {
          try {
            const response = await freeUploadNormalImage(formData);
            console.log(response, "free user response data");

            apiResponse = response;
            console.log(apiResponse, "upload image daata ");
            incrementGuestUploadCount();

            // Show remaining uploads
            const remaining = MAX_FREE_UPLOADS - getGuestUploadCount();
            if (remaining <= 2) {
              toast.success(
                `Upload successful! ${remaining} free uploads remaining.`
              );
            }
          } catch (error) {
            console.error("Upload error:", error);
            toast.error("Upload failed. Please try again.");
            throw error;
          }
        }
      }

      setImages((prev) =>
        prev.map((img) => (img.file === file ? { ...img, progress: 30 } : img))
      );

      setImages((prev) =>
        prev.map((img) =>
          img.file === file
            ? { ...img, status: "analyzing", progress: 40 }
            : img
        )
      );

      setResponse(apiResponse?.data || null);

      for (let progress = 50; progress <= 90; progress += 10) {
        await new Promise((resolve) => setTimeout(resolve, 200));
        setImages((prev) =>
          prev.map((img) => (img.file === file ? { ...img, progress } : img))
        );
      }

      setImages((prev) => {
        const updated = prev.map((img) =>
          img.file === file
            ? {
                ...img,
                status: "complete" as const,
                progress: 100,
                apiResponse: apiResponse,
              }
            : img
        );

        const allComplete = updated.every((img) => img.status === "complete");
        if (allComplete && onImagesComplete) {
          onImagesComplete(updated);
        }

        return updated;
      });
    } catch (error) {
      console.error("[v0] Upload error:", error);
      toast.error(
        error instanceof Error
          ? error.message
          : "Upload failed. Please try again."
      );

      setImages((prev) =>
        prev.map((img) =>
          img.file === file
            ? {
                ...img,
                status: "error" as const,
                progress: 0,
              }
            : img
        )
      );
    }
  };

  // 🎯 Listen for submitData and execute once

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragOver(false);
    if (event.dataTransfer.files.length > 0) {
      handleFileSelect(event.dataTransfer.files);
    }
  };

  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragOver(false);
  };

  const handleClick = () => {
    const morphData = {
      id: response?.uploadImage?.id,
      user_image_key: response?.uploadImage?.morphCredentials?.user_image_key,
      normal_name: response?.uploadImage?.morphCredentials?.normal_name,
      celebrity_image_key:
        response?.uploadImage?.morphCredentials?.normal_image_key,
      bucket: "normal",
    };

    // ✅ Check if morph data is valid
    if (
      morphData.id &&
      morphData.user_image_key &&
      morphData.celebrity_image_key
    ) {
      // Dispatch the Redux action
      dispatch(setMorphCredentials(morphData));

      // ✅ Ensure Redux has updated before routing
      // We'll check the Redux store after a short delay
      setTimeout(() => {
        const updated = morphData;

        if (
          updated?.id === morphData.id &&
          updated?.user_image_key === morphData.user_image_key &&
          updated?.celebrity_image_key === morphData.celebrity_image_key
        ) {
          router.push(getPrefixedPath(`/payment/${MORPHINGId}`));
        } else {
          console.warn("Redux store not updated yet — skipping navigation.");
        }
      }, 300);
    } else {
      console.warn("Morph credentials are incomplete — dispatch skipped.");
    }
  };

  const handleCelebrityClick = () => {
    const morphData = {
      id: response?.celebrity?.id,
      user_image_key: response?.celebrity?.morphCredentials?.user_image_key,
      normal_name: response?.celebrity?.morphCredentials?.celebrity_name,
      celebrity_image_key:
        response?.celebrity?.morphCredentials?.celebrity_image_key,
      bucket: "celebrity",
    };

    // ✅ Check if morph data is valid
    if (
      morphData.id &&
      morphData.user_image_key &&
      morphData.celebrity_image_key
    ) {
      // Dispatch the Redux action
      dispatch(setMorphCredentials(morphData));

      // ✅ Ensure Redux has updated before routing
      // We'll check the Redux store after a short delay
      setTimeout(() => {
        const updated = morphData;

        if (
          updated?.id === morphData.id &&
          updated?.user_image_key === morphData.user_image_key &&
          updated?.celebrity_image_key === morphData.celebrity_image_key
        ) {
          router.push(getPrefixedPath(`/payment/${MORPHINGId}`));
        } else {
          console.warn("Redux store not updated yet — skipping navigation.");
        }
      }, 300);
    } else {
      console.warn("Morph credentials are incomplete — dispatch skipped.");
    }
  };

  console.log(response, "response data");

  return (
    <div>
      {/* Upload Section */}
      {images.length < maxImages && !capturedImage && !morphResult && (
        <>
          <h2 className="text-white text-center font-poppins text-sm md:text-xl lg:text-2xl  text-wrap font-medium leading-normal">
            {t("description")}
          </h2>
          <div
            className={`${
              path === getPrefixedPath("/upload-photo")
                ? "mt-4 md:mt-10"
                : "mt-8 md:mt-14"
            } lg:w-[886px] w-full flex flex-col rounded-[20px] border border-[rgba(1,218,226,0.7)]`}
          >
            <div className="items-center text-center">
              {path === getPrefixedPath("/upload-photo") ||
              path === "/upload-photo" ? (
                <div className="flex flex-col items-start px-4 md:px-10">
                  <h3 className="text-white font-poppins text-[12px] px-4 md:text-xl  font-bold leading-none pt-4">
                    Select Photo
                  </h3>
                  <p className="text-white  font-poppins text-[12px] md:text-xl  text-wrap text-start px-4  font-normal leading-none tracking-[-0.22px] pb-4 pt-2">
                    {t("uploadtitle")}
                  </p>
                </div>
              ) : (
                <p className="text-white font-poppins text-[12px] md:text-[20px] text-wrap  px-4   font-normal leading-none -tracking-tighter py-4">
                  {t("uploadtitle")}
                </p>
              )}

              <div className="w-full h-[1px] bg-[rgba(1,218,226,0.2)]" />

              {capturedImage && (
                <div className="p-6">
                  <div className="mb-4">
                    <p className="text-white font-poppins text-lg font-semibold mb-2">
                      Captured Photo:
                    </p>
                    <Image
                      src={capturedImage || "/placeholder.svg"}
                      width={500}
                      height={500}
                      alt="Captured from webcam"
                      className="max-w-md mx-auto rounded-lg border border-[rgba(1,218,226,0.7)]"
                    />
                  </div>
                  <div className="flex gap-4 justify-center">
                    <Button
                      onClick={() => setCapturedImage(null)}
                      variant="outline"
                      className="border-[1px] border-primary"
                    >
                      Remove Photo
                    </Button>
                    <Button
                      onClick={handleWebcamClick}
                      variant="outline"
                      className="border-[1px] border-primary bg-transparent"
                    >
                      Take Another Photo
                    </Button>
                    <Button
                      onClick={() => {
                        if (capturedImage) {
                          const file = dataURLtoFile(
                            capturedImage,
                            "webcam-photo.jpg"
                          );
                          const fileList = new DataTransfer();
                          fileList.items.add(file);
                          handleFileSelect(fileList.files);
                          setCapturedImage(null);
                        }
                      }}
                      className="bg-primary text-white hover:bg-[rgba(0,176,185,0.8)]"
                    >
                      {t("uploadbutton")}
                    </Button>
                  </div>
                </div>
              )}

              <div className="flex justify-center mx-2 sm:mx-0 flex-col items-center h-full py-4 md:py-10 gap-2 md:gap-6">
                <div
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  className={`w-full md:w-[519px] h-[218px] flex items-center justify-center rounded-[15px] bg-[#02CCD8]  cursor-pointer transition duration-300 hover:bg-[rgba(0,176,185,0.8)] ${
                    isDragOver ? "bg-[rgba(0,176,185,0.9)]" : ""
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-white  font-poppins text-[30px] font-semibold leading-none tracking-[-0.33px]"
                    style={{ all: "unset", cursor: "pointer" }}
                  >
                    <div className="flex flex-col items-center justify-center gap-2">
                      <UploadPhotoIcon />
                      <h4 className="text-white font-poppins text-2xl md:text-[30px] font-semibold leading-none tracking-[-0.33px]">
                        {t("uploadbutton")}
                      </h4>
                      <p className="text-white text-wrap px-2 font-poppins text-[12px] font-normal leading-none tracking-[-0.132px]">
                        {t("uploaddis")}
                      </p>
                      <div className="text-white font-poppins text-[12px] font-normal leading-none tracking-[-0.132px] flex gap-1">
                        {t("uploadsize")}
                        <GoDotFill />
                        {t("max")}
                      </div>
                    </div>
                  </button>
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => handleFileSelect(e.target.files)}
                />

                <h5 className="text-white font-poppins text-sm md:text-xl font-bold leading-none tracking-[-0.198px]">
                  {t("or")}
                </h5>

                <Button
                  onClick={handleWebcamClick}
                  variant="outline"
                  className="text-sm border-[1px] border-primary rounded-lg font-bold bg-transparent"
                >
                  {t("webcam")} <WebCamIcon />
                </Button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Morphing UI Section - Show when morphing or video ready */}
      {showMorphingUI && (
        <div className="mt-12">
          {!morphResult ? (
            <MorphingProgress
              progress={morphingProgress}
              status={morphingStatus}
              isMorphing={true}
              morphingStatus="Analyzing shape transformations..."
            />
          ) : (
            <>
              <MorphingVideoPlayer
                video={morphResult}
                onDownloadClick={() => setShowModal(true)}
              />

              <VideoShareModal
                video={morphResult}
                open={showModal}
                onOpenChange={setShowModal}
              />
            </>
          )}
        </div>
      )}

      {/* Image Processing Cards - Hide when showing morphing UI */}
      {!showMorphingUI && (
        <div>
          {images.map((image) => (
            <div
              key={image.id}
              className="flex flex-col gap-8 justify-center items-center"
            >
              <div className="w-full flex flex-col items-center gap-8">
                <div className="flex w-full md:w-[589px]  h-[248px] px-0 md:px-[196px] justify-center items-center shrink-0 relative">
                  <div
                    className="absolute top-0 left-0 right-0 h-[1px]"
                    style={{
                      background:
                        "repeating-linear-gradient(90deg, #fff, #fff 8px, transparent 8px, transparent 16px)",
                    }}
                  ></div>

                  <div
                    className="absolute top-0 right-0 bottom-0 w-[1px]"
                    style={{
                      background:
                        "repeating-linear-gradient(180deg, #fff, #fff 8px, transparent 8px, transparent 16px)",
                    }}
                  ></div>

                  <div
                    className="absolute bottom-0 left-0 right-0 h-[1px]"
                    style={{
                      background:
                        "repeating-linear-gradient(90deg, #fff, #fff 8px, transparent 8px, transparent 16px)",
                    }}
                  ></div>

                  <div
                    className="absolute top-0 left-0 bottom-0 w-[1px]"
                    style={{
                      background:
                        "repeating-linear-gradient(180deg, #fff, #fff 8px, transparent 8px, transparent 16px)",
                    }}
                  ></div>

                  <div className="relative w-64 h-56  overflow-hidden">
                    <Image
                      src={image.preview || "/placeholder.svg"}
                      height={192}
                      width={256}
                      alt="Upload preview"
                      className="w-full h-full object-cover"
                    />

                    {(image.status === "uploading" ||
                      image.status === "analyzing") && (
                      <div className="absolute inset-0 flex items-center justify-center ">
                        <div className="w-12 h-12 border-4 border-t-4 border-t-transparent bg-transparent border-[#9B51E0] rounded-full animate-spin" />
                      </div>
                    )}

                    {image.status === "complete" && (
                      <div className="absolute top-2 right-2 w-8 h-8 bg-[#27AE60] rounded-full flex items-center justify-center">
                        <Check className="w-5 h-5 text-white" />
                      </div>
                    )}

                    {image.status === "error" && (
                      <div
                        className="absolute top-2 right-2 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center cursor-pointer"
                        onClick={() => handleRetryUpload(image.file)}
                      >
                        <X className="w-5 h-5 text-white" />
                      </div>
                    )}
                  </div>
                </div>

                <div className=" w-full md:max-w-[70vw] flex flex-col gap-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span
                        className={`text-sm font-medium ${
                          image.status === "error"
                            ? "text-red-400"
                            : image.status === "complete"
                            ? "text-[#27AE60]"
                            : "text-[#9B51E0]"
                        }`}
                      >
                        {image.status === "uploading" && "Uploading..."}
                        {image.status === "analyzing" &&
                          "Analyzing Lookalike.."}
                        {image.status === "complete" && "Lookalike Complete"}
                        {image.status === "error" && "Upload Failed"}
                      </span>
                      <span className="text-white text-sm font-bold">
                        {image.progress}%
                      </span>
                    </div>

                    <Progress
                      value={image.progress}
                      className={`h-2 ${
                        image.status === "error"
                          ? "bg-red-900"
                          : image.status === "complete"
                          ? "bg-[#27AE60]"
                          : "bg-[#9B51E0]"
                      }`}
                    />
                  </div>

                  <p className="text-[#fff] font-Poppins text-sm not-italic font-normal text-center md:py-4 py-2 leading-normal tracking-[-0.154px]">
                    {image.status === "uploading" &&
                      "Uploading your photo to our servers..."}
                    {image.status === "analyzing" &&
                      "Extracting facial embeddings and comparing against our database"}
                    {image.status === "complete" &&
                      "Analysis complete! Your lookalike has been found."}
                    {image.status === "error" &&
                      "Failed to upload image. Please try again."}
                  </p>

                  {(image.status === "uploading" ||
                    image.status === "analyzing") && (
                    <span className="text-[#9B51E0] font-Poppins text-center text-2xl not-italic font-medium leading-normal tracking-[-0.264px]">
                      &ldquo;Analyzing...&rdquo; →
                    </span>
                  )}

                  {image.status === "error" && (
                    <Button
                      onClick={() => uploadToBackend(image.file)}
                      variant="outline"
                      size="sm"
                      className="border-red-500 text-red-400 hover:bg-red-500/10"
                    >
                      Retry Upload
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Celebrity Matches Grid - Hide when showing morphing UI */}
      {!showMorphingUI && (
        <div className="w-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 -120">
          {response?.allMatches?.map((match: CardData) => (
            <ImageCard key={match.id} imageData={match} />
          ))}

          {response?.matches?.map((match: CardData) => (
            <ImageCard key={match.id} imageData={match} />
          ))}

          {response?.data?.map((match: CardData) => (
            <ImageCard key={match.id} imageData={match} />
          ))}
        </div>
      )}

      {response?.allMatches?.length > 0 && (
        <div className="flex flex-row justify-between items-center mt-12">
          <button
            onClick={() =>
              router.push(getPrefixedPath(`/payment/${celebrityLookalikeId}`))
            }
            className="inline-flex h-[55px] cursor-pointer px-6 py-4 justify-center font-poppins items-center gap-2 shrink-0 rounded-[16px] border border-[#02CCD8]"
          >
            Unlock My Celebrity Doppelganger Match
          </button>

          <button
            onClick={handleClick}
            disabled={userPlan?.enableMorphing === false}
            className="text-[#F9FAFB] text-center font-Poppins cursor-pointer text-[18px] font-medium leading-normal 
         rounded-[16px] bg-[#02CCD8] inline-flex h-[55px] px-[24px] py-[16px] 
         justify-center items-center gap-[8px] shrink-0"
          >
            <UnlockVideoIcon /> <span> Unlock My Morphing Video</span>
          </button>
        </div>
      )}

      {/* Morphing Button - Only show when response is ready and not showing morphing UI */}
      {response?.celebrity && !showMorphingUI && (
        <div className="flex justify-between items-center  gap-4 mt-10 mb-20">
          <button
            onClick={() =>
              router.push(getPrefixedPath(`/payment/${LookalikeId}`))
            }
            className="inline-flex h-[55px] cursor-pointer px-6 py-4 justify-center font-poppins items-center gap-2 shrink-0 rounded-[16px] border border-[#02CCD8]"
          >
            Unlock My Lookalike Doppelganger Match
          </button>
          <Button
            variant="outline"
            onClick={handleCelebrityClick}
            size="sm"
            className="text-[#F9FAFB] text-center bg-[#02CCD8] cursor-pointer font-Poppins text-lg not-italic font-medium leading-normal flex h-14 px-6 py-4 justify-center items-center gap-2 hover:bg-[#02CCD8]/80"
            disabled={isMorphing}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="40"
              height="44"
              viewBox="0 0 32 33"
              fill="none"
            >
              <path
                d="M22.667 21.1666V18.5L26.1337 13.8777C26.4694 13.4301 26.9963 13.1666 27.5558 13.1666C28.5377 13.1666 29.3337 13.9626 29.3337 14.9444V24.7222C29.3337 25.704 28.5377 26.5 27.5558 26.5C26.9963 26.5 26.4694 26.2365 26.1337 25.7889L22.667 21.1666Z"
                stroke="white"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M13.9593 8.53341C13.9683 8.48886 14.0319 8.48886 14.0411 8.53341C14.5138 10.8459 16.3209 12.6531 18.6334 13.1257C18.6779 13.1348 18.6779 13.1985 18.6334 13.2076C16.3209 13.6802 14.5138 15.4875 14.0411 17.7999C14.0319 17.8445 13.9683 17.8445 13.9593 17.7999C13.4866 15.4875 11.6794 13.6802 9.36691 13.2076C9.32236 13.1985 9.32236 13.1348 9.36691 13.1257C11.6794 12.6531 13.4866 10.8459 13.9593 8.53341Z"
                stroke="white"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M7.40209 9.83264C6.19912 9.98965 5.32508 10.2918 4.61641 10.8734C4.34636 11.0951 4.09874 11.3427 3.87712 11.6127C2.6665 13.0879 2.6665 15.2797 2.6665 19.663C2.6665 24.0464 2.66657 26.4085 3.87717 27.8836C4.0988 28.1536 4.34642 28.4013 4.61646 28.6229C6.0916 29.8334 8.28326 29.8334 12.6666 29.8334C17.0498 29.8334 19.2416 29.8334 20.7166 28.6229C20.9868 28.4013 21.2344 28.1536 21.456 27.8836C22.6665 26.4085 22.6665 24.2168 22.6665 19.8334C22.6665 16.9241 22.6665 14.9801 22.3125 13.5704"
                stroke="white"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M20.1611 3.57952C20.2736 3.029 21.0601 3.029 21.1727 3.57952C21.4212 4.79541 22.3715 5.74561 23.5873 5.99413C24.1379 6.10666 24.1379 6.89325 23.5873 7.00578C22.3715 7.2543 21.4212 8.2045 21.1727 9.4204C21.0601 9.97092 20.2736 9.97092 20.1611 9.4204C19.9125 8.2045 18.9624 7.2543 17.7464 7.00578C17.1959 6.89325 17.1959 6.10666 17.7464 5.99413C18.9624 5.74561 19.9125 4.79541 20.1611 3.57952Z"
                fill="white"
              />
            </svg>
            {isMorphing ? "Creating..." : "Unlock My Morphing Video"}
          </Button>
        </div>
      )}

      {isWebcamModalOpen && (
        // <SimpleWebcamModal
        //   isOpen={isWebcamModalOpen}
        //   onClose={() => setIsWebcamModalOpen(false)}
        //   onImageCapture={handleImageCapture}
        // />
        <SimpleWebcamModal
          isOpen={isWebcamModalOpen}
          onClose={() => setIsWebcamModalOpen(false)}
          onImageCapture={uploadToBackend}
        />
      )}
    </div>
  );
};

export default ImageUploadFlow;
