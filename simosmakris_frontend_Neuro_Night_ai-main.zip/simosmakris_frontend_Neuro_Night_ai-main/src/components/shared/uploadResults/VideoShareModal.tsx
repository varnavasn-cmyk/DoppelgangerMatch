"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Download, Copy, Check, Loader2 } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { FacebookShareButton, TwitterShareButton } from "react-share";
import { FaFacebook } from "react-icons/fa";
import Image from "next/image";
import { BsTwitterX } from "react-icons/bs";
import { RootState } from "@/redux/store";
import { useAppSelector } from "@/redux/hooks";

export interface MorphVideoResponse {
  id: string;
  userId: string;
  celebrityId: string;
  videoKey: string;
  videoUrl: string;
  status: "GENERATING" | "COMPLETED" | "FAILED";
  watermark: boolean;
  createdAt: string;
}

interface VideoShareModalProps {
  video: MorphVideoResponse;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function VideoShareModal({
  video,
  open,
  onOpenChange,
}: VideoShareModalProps) {
  const [copied, setCopied] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const videoUrl = video?.videoUrl;
  const currentUrl = "https://doppelgangermatch.com/upload-photo";
  const shareTitle = "Check out my celebrity lookalike morphing video!";
  const shareHashtags = ["CelebrityLookalike", "MorphingVideo", "AI"];
  const token = useAppSelector((state: RootState) => state.auth.access_token);

  const shareUrl = `${currentUrl}/${video.id}`;

  const handleDownload = async () => {
    if (typeof window === "undefined" || !video?.id) return;
    setIsDownloading(true);

    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/morph-video/download/${video.id}`,
        {
          method: "GET",
          headers: {
            Accept: "application/octet-stream",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (!res.ok) throw new Error(`Failed: ${res.statusText}`);

      const blob = await res.blob();
      const blobUrl = window.URL.createObjectURL(blob);

      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = `morphing-video-${video.id}.mp4`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (err) {
      console.error("Download error:", err);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleCopyLink = async () => {
    if (!shareUrl || typeof window === "undefined") return;

    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy link:", err);
      const textArea = document.createElement("textarea");
      textArea.value = shareUrl;
      textArea.style.position = "fixed";
      textArea.style.left = "-9999px";
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand("copy");
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handlePlatformShare = (platform: string) => {
    if (typeof window === "undefined") return;

    const encodedUrl = encodeURIComponent(shareUrl);
    switch (platform) {
      case "instagram":
        handleCopyLink();
        window.open("https://www.instagram.com/", "_blank");
        alert(
          "Opening Instagram! Link copied to clipboard - you can paste it in your post caption."
        );
        break;

      case "tiktok":
        handleCopyLink();
        window.open("https://www.tiktok.com/upload", "_blank");
        alert(
          "Opening TikTok upload page! Link copied to clipboard - you can paste it in your video caption."
        );
        break;

      case "snapchat":
        const url = `https://www.snapchat.com/share?link=${encodedUrl}`;
        window.open(url, "_blank", "width=600,height=400");
        break;

      default:
        break;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl h-[50vh] overflow-y-auto rounded-2xl bg-white p-0 border-0 shadow-2xl">
        {/* Header with Gradient */}
        <div className="bg-gradient-to-r from-cyan-500 to-blue-500 p-6 relative"></div>

        <div className="p-6 space-y-6">
          {/* Video Preview */}
          <div className="relative rounded-xl overflow-hidden bg-gray-100 aspect-video max-w-md mx-auto shadow-lg">
            <video
              src={videoUrl}
              className="w-full h-full object-cover"
              controls
              muted
              playsInline
              preload="metadata"
            />
          </div>

          {/* Social Media Share Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gray-300 to-transparent" />
              <p className="text-sm font-semibold text-gray-700 px-3">
                Share to social media
              </p>
              <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gray-300 to-transparent" />
            </div>

            <div className="flex justify-around items-start gap-6">
              {/* Facebook */}
              <div className="flex flex-col items-center gap-2">
                <FacebookShareButton
                  url={`${shareUrl}`}
                  hashtag={`#${shareHashtags[0]} ${shareUrl}`}
                  className="hover:opacity-80 transition-opacity"
                >
                  <button className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <div className="mb-2">
                      <FaFacebook size={36} className="text-blue-600 mb-2" />
                    </div>
                    <span className="text-sm font-semibold text-gray-600">
                      Facebook
                    </span>
                  </button>
                </FacebookShareButton>
              </div>

              {/* Twitter (X) */}
              <div className="flex flex-col items-center gap-2">
                <TwitterShareButton
                  url={shareUrl}
                  title={shareTitle}
                  hashtags={shareHashtags}
                  className="hover:opacity-80 transition-opacity"
                >
                  <button className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <div className="w-10 h-10 bg-black rounded-full mb-2 flex items-center justify-center">
                      <BsTwitterX size={20} className="text-white " />
                    </div>
                    <span className="text-xs font-semibold text-gray-600 my-1">
                      X
                    </span>
                  </button>
                </TwitterShareButton>
              </div>

              {/* Instagram */}
              <div className="flex flex-col items-center gap-2">
                <button
                  onClick={() => handlePlatformShare("instagram")}
                  className="hover:opacity-80 flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Image
                    src="/Instagram.png"
                    alt="Instagram"
                    width={24}
                    height={24}
                    className="object-center w-10 h-10 rounded-full mb-2"
                  />

                  <span className="text-xs font-semibold text-gray-600 mt-1">
                    Instagram
                  </span>
                </button>
              </div>

              {/* TikTok */}
              <div className="flex flex-col items-center gap-2">
                <button
                  onClick={() => handlePlatformShare("tiktok")}
                  className="hover:opacity-80 flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Image
                    src="/tiktok.png"
                    alt="TikTok"
                    width={24}
                    height={24}
                    className="object-center w-10 h-10 rounded-full mb-3"
                  />
                  <span className="text-xs font-semibold text-gray-600">
                    TikTok
                  </span>
                </button>
              </div>

              {/* Snapchat */}
              <div className="flex flex-col items-center gap-2">
                <button
                  onClick={() => handlePlatformShare("snapchat")}
                  className="hover:opacity-80  flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Image
                    src="/snapchat.png"
                    alt="Snapchat"
                    width={24}
                    height={24}
                    className="object-center w-10 h-10 rounded-full mb-2"
                  />
                  <span className="text-xs font-semibold text-gray-600 mt-1">
                    Snapchat
                  </span>
                </button>
              </div>
            </div>
          </div>

          {/* Copy Link Section */}
          <div className="space-y-3 bg-gray-50 rounded-xl p-4">
            <p className="text-sm font-semibold text-gray-700 text-center">
              Or copy direct link
            </p>
            <div className="flex gap-2">
              <input
                type="text"
                value={shareUrl}
                readOnly
                className="flex-1 px-4 py-3 bg-white border-2 border-gray-200 rounded-lg text-sm text-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
              />
              <Button
                onClick={handleCopyLink}
                className={`px-6 py-3 rounded-lg transition-all font-semibold ${
                  copied
                    ? "bg-green-500 hover:bg-green-600"
                    : "bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600"
                } text-white shadow-lg`}
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Download Video Button */}
          <button
            onClick={handleDownload}
            disabled={isDownloading}
            className={`
        relative w-full px-6 py-4 rounded-xl font-bold text-base text-white
        transition-all duration-300 overflow-hidden
        ${
          isDownloading
            ? "bg-gradient-to-r from-blue-500 to-cyan-500 scale-95 shadow-lg animate-pulse"
            : "bg-gradient-to-r from-blue-500 via-sky-500 to-cyan-500 hover:from-blue-600 hover:via-sky-600 hover:to-cyan-600 hover:shadow-2xl hover:scale-[1.03]"
        }
        disabled:opacity-80 disabled:cursor-not-allowed
      `}
          >
            {/* Shiny hover overlay */}
            {!isDownloading && (
              <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] hover:translate-x-[100%] transition-transform duration-700 ease-in-out" />
            )}

            {/* Button content */}
            <span className="relative z-10 flex items-center justify-center gap-2">
              {isDownloading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Downloading...
                </>
              ) : (
                <>
                  <Download className="w-5 h-5" />
                  Download Video
                </>
              )}
            </span>
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
