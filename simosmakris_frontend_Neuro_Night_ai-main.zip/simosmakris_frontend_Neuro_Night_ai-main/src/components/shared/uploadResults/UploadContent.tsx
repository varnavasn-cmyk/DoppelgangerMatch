import { LightIcon } from "@/assets/svg";
import { useTranslations } from "next-intl";

function UploadContent() {
  const t = useTranslations("upload-page");
  return (
    <div>
      <section className="flex w-full md:mt-12 mt-8 lg:mt-24 py-4 p-8 flex-col justify-center items-start shrink-0 rounded-3xl bg-white/5">
        <div className="flex items-center gap-4 ">
          <LightIcon />
          <h2 className="text-white font-poppins text-xl md:text-2xl font-medium leading-normal">
            {t("section1.title")}
          </h2>
        </div>
        <ol className="text-white font-poppins text-base font-normal leading-normal list-disc ml-4 space-y-4 mt-6 ">
          <li>{t("section1.li1")}</li>
          <li>{t("section1.li2")}</li>
          <li>{t("section1.li3")}</li>
          <li>{t("section1.li4")}</li>
        </ol>
      </section>
      <section className="flex w-full mt-8  md:mt-16 md-8 md:mb-12 lg:mb-32 p-6 flex-col justify-center items-start shrink-0 rounded-[30px] border border-white">
        <h2 className="text-white font-poppins text-xl md:text-2xl font-medium leading-normal">
          {t("section2.title")}
        </h2>
        <ol className="mt-6 flex flex-col gap-6 w-full">
          <li className="flex flex-row gap-4 items-center">
            <h3 className="text-white font-poppins text-2xl font-semibold leading-normal">
              1.
            </h3>
            <div>
              <h5 className="text-white font-poppins text-lg md:text-xl font-semibold leading-normal">
                {t("section2.subTitle1")}
              </h5>
              <p className="text-white font-poppins text-sm md:text-base font-normal leading-normal">
                {t("section2.subDis1")}
              </p>
            </div>
          </li>
          <li className="flex flex-row gap-4 items-center">
            <h3 className="text-white font-poppins text-2xl font-semibold leading-normal">
              2.
            </h3>
            <div>
              <h5 className="text-white font-poppins text-lg md:text-xl font-semibold leading-normal">
                {t("section2.subTitle2")}
              </h5>
              <p className="text-white font-poppins text-sm md:text-base font-normal leading-normal">
                {t("section2.subDis2")}
              </p>
            </div>
          </li>
          <li className="flex flex-row gap-4 items-center">
            <h3 className="text-white font-poppins text-2xl font-semibold leading-normal">
              3.
            </h3>
            <div>
              <h5 className="text-white font-poppins text-lg md:text-xl font-semibold leading-normal">
                {t("section2.subTitle3")}
              </h5>
              <p className="text-white font-poppins text-sm md:text-base font-normal leading-normal">
                {t("section2.subDis3")}
              </p>
            </div>
          </li>
        </ol>
      </section>
    </div>
  );
}

export default UploadContent;
