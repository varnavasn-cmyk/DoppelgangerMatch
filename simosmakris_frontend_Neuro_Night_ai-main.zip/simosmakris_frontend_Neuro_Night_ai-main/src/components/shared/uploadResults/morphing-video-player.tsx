"use client";

import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Play, Pause, Download } from "lucide-react";
import { usePathname } from "next/navigation";

export interface MorphVideoResponse {
  id: string;
  userId: string;
  celebrityId: string;
  videoKey: string;
  videoUrl: string;
  status: "GENERATING" | "COMPLETED" | "FAILED";
  watermark: boolean;
  createdAt: string;
}

interface MorphingVideoPlayerProps {
  video: MorphVideoResponse;
  onDownloadClick?: () => void;
}

export function MorphingVideoPlayer({
  video,
  onDownloadClick,
}: MorphingVideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const videoUrl = video?.videoUrl;
  const currentPath = usePathname();

  // Reset loading state when video changes
  useEffect(() => {
    setIsLoading(true);
    setError(false);
    setIsPlaying(false);
    setProgress(0);
  }, [videoUrl]);

  const handlePlayPause = () => {
    if (!videoRef.current) return;
    setError(false);

    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch((err) => {
          console.error("Play error:", err);
          setError(true);
        });
    }
  };

  const handleVideoLoaded = () => {
    setIsLoading(false);
    setError(false);
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const handleVideoCanPlay = () => {
    setIsLoading(false);
    setError(false);
  };

  const handleVideoError = (
    e: React.SyntheticEvent<HTMLVideoElement, Event>
  ) => {
    console.error("Video error:", e);
    setError(true);
    setIsLoading(false);
  };

  const handleVideoEnd = () => {
    setIsPlaying(false);
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      setProgress(0);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const currentProgress =
        (videoRef.current.currentTime / videoRef.current.duration) * 100;
      setProgress(currentProgress);
    }
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!videoRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percentage = clickX / rect.width;
    videoRef.current.currentTime = percentage * videoRef.current.duration;
  };

  const formatTime = (time: number) => {
    if (isNaN(time)) return "0:00";
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };

  return (
    <div className="flex flex-col items-center gap-8 w-full max-w-4xl mx-auto px-4">
      {/* Header Section */}
      {currentPath === "upload-photo" && (
        <div className="text-center space-y-3">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
            Your Lookalike Morphing Results
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            See how you transform into your celebrity lookalike with stunning
            AI-powered morphing effects
          </p>
        </div>
      )}

      {/* Video Player Section */}
      <div className="relative w-full max-w-2xl">
        {/* Decorative Background Glow */}
        <div className="absolute -inset-4 bg-gradient-to-r from-cyan-500/20 via-blue-500/20 to-purple-500/20 rounded-3xl blur-2xl" />

        <div className="relative bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl overflow-hidden shadow-2xl border border-gray-700/50">
          {/* Video Container */}
          <div className="relative aspect-video bg-black">
            {error ? (
              <div className="w-full h-full flex flex-col items-center justify-center text-red-400 bg-gradient-to-br from-red-900/20 to-gray-900">
                <div className="text-center space-y-4">
                  <svg
                    className="w-16 h-16 mx-auto text-red-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  <p className="text-xl font-semibold">Failed to load video</p>
                  <p className="text-gray-400 text-sm">
                    Please check your connection and try again
                  </p>
                  <Button
                    onClick={() => {
                      setIsLoading(true);
                      setError(false);
                      if (videoRef.current) {
                        videoRef.current.load();
                      }
                    }}
                    className="bg-cyan-500 hover:bg-cyan-600 text-white mt-4"
                  >
                    Retry
                  </Button>
                </div>
              </div>
            ) : (
              <>
                <video
                  ref={videoRef}
                  className="w-full h-full object-contain"
                  playsInline
                  preload="metadata"
                  onLoadedData={handleVideoLoaded}
                  onCanPlay={handleVideoCanPlay}
                  onError={handleVideoError}
                  onEnded={handleVideoEnd}
                  onTimeUpdate={handleTimeUpdate}
                >
                  <source src={videoUrl} type="video/mp4" />
                  <source src={videoUrl} type="video/webm" />
                  Your browser does not support the video tag.
                </video>

                {/* Play/Pause Overlay */}
                {!isPlaying && !isLoading && (
                  <button
                    onClick={handlePlayPause}
                    className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm hover:bg-black/50 transition-all duration-300 group"
                  >
                    <div className="relative">
                      <div className="absolute inset-0 bg-cyan-500 rounded-full blur-xl opacity-50 group-hover:opacity-75 transition-opacity" />
                      <div className="relative w-24 h-24 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center shadow-2xl shadow-cyan-500/50 group-hover:scale-110 transition-transform duration-300">
                        <Play className="w-12 h-12 text-white fill-white ml-2" />
                      </div>
                    </div>
                  </button>
                )}

                {/* Loading Spinner */}
                {isLoading && !error && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm">
                    <div className="relative">
                      <div className="w-24 h-24 rounded-full bg-gradient-to-br from-cyan-400/30 to-blue-500/30 flex items-center justify-center">
                        <div className="animate-spin w-16 h-16 border-4 border-cyan-400 border-t-transparent rounded-full" />
                      </div>
                      <p className="text-white text-sm mt-4 text-center">
                        Loading video...
                      </p>
                    </div>
                  </div>
                )}

                {/* Pause Overlay when playing */}
                {isPlaying && (
                  <button
                    onClick={handlePlayPause}
                    className="absolute inset-0 flex items-center justify-center bg-transparent hover:bg-black/30 transition-all duration-300 opacity-0 hover:opacity-100 group"
                  >
                    <div className="w-20 h-20 rounded-full bg-black/60 backdrop-blur-sm flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform duration-300">
                      <Pause className="w-10 h-10 text-white fill-white" />
                    </div>
                  </button>
                )}
              </>
            )}
          </div>

          {/* Video Controls */}
          {!error && (
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 border-t border-gray-700/50 p-4 space-y-3">
              {/* Progress Bar */}
              <div
                className="relative h-2 bg-gray-700 rounded-full cursor-pointer group"
                onClick={handleProgressClick}
              >
                <div
                  className="absolute h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full transition-all duration-150"
                  style={{ width: `${progress}%` }}
                />
                <div
                  className="absolute h-4 w-4 bg-white rounded-full shadow-lg top-1/2 -translate-y-1/2 transition-all duration-150 opacity-0 group-hover:opacity-100"
                  style={{
                    left: `${progress}%`,
                    transform: "translate(-50%, -50%)",
                  }}
                />
              </div>

              {/* Controls Row */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  {/* Play/Pause Button */}
                  <button
                    onClick={handlePlayPause}
                    className="w-10 h-10 rounded-full bg-cyan-500 hover:bg-cyan-600 flex items-center justify-center transition-all duration-200 hover:scale-110 shadow-lg shadow-cyan-500/30"
                    disabled={isLoading}
                  >
                    {isPlaying ? (
                      <Pause className="w-5 h-5 text-white fill-white" />
                    ) : (
                      <Play className="w-5 h-5 text-white fill-white ml-0.5" />
                    )}
                  </button>

                  {/* Time Display */}
                  <div className="text-sm text-gray-400 font-medium tabular-nums">
                    {formatTime(videoRef.current?.currentTime || 0)} /{" "}
                    {formatTime(duration)}
                  </div>
                </div>

                {/* Download Button */}
                <Button
                  onClick={onDownloadClick}
                  className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white px-6 py-2 rounded-lg shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/40 transition-all duration-200 hover:scale-105"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
