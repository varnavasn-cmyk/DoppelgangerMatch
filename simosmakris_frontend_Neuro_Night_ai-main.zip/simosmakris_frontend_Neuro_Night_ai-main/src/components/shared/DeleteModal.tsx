"use client";

import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";

type DeleteModalProps = {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void | Promise<void>;
};

export default function DeleteModal({
  isOpen,
  onClose,
  onConfirm,
}: DeleteModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="w-full max-w-xl rounded-2xl bg-white p-8 shadow-xl">
        <h2 className="mb-4 text-center text-2xl font-bold text-black">
          Delete !
        </h2>

        <p className="mb-6 text-base text-black">
          Are you sure you want to delete this ?
          <br />
          This action cannot be undone.
        </p>

        <div className="mb-6 rounded-lg border-l-4 border-orange-600 bg-orange-50 p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-6 w-6 flex-shrink-0 text-orange-700" />
            <div>
              <h3 className="mb-1 text-lg font-semibold text-orange-900">
                Warning
              </h3>
              <p className="text-sm text-orange-700">
                By Deleting this, you won&apos;t be able to access the system.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between gap-4">
          <Button
            onClick={onClose}
            className="rounded-lg bg-gray-900 px-6 py-2.5 text-base font-medium text-white hover:bg-gray-800"
          >
            No, Cancel
          </Button>
          <Button
            onClick={async () => {
              await onConfirm();
              onClose();
            }}
            variant="outline"
            className="rounded-lg border-2 border-gray-900 bg-white px-6 py-2.5 text-base font-medium text-black hover:bg-gray-50 hover:text-red-500"
          >
            Yes, Delete
          </Button>
        </div>
      </div>
    </div>
  );
}
