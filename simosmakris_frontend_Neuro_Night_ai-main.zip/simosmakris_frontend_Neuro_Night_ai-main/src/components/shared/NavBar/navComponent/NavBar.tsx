"use client";
import { Navbar } from "../navbar";
import NavLogo from "@/assets/homelogo.svg";
import { Button } from "@/components/ui/button";
import { usePrefixedPath } from "@/lib/localePath";

import { RootState } from "@/redux/store";
import { useRouter } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";
import { useTranslations } from "next-intl";
// import { jwtDecode } from "jwt-decode";
import { setUser } from "@/redux/features/auth/authSlice";
import { useGetMeUserQuery } from "@/redux/features/users/usersApi";
// export interface DecodedToken {
//   id: string;
//   email: string;
//   role: string;
//   exp: number;
//   iat: number;
// }

// export const decodeToken = (token: string | null): DecodedToken | null => {
//   if (!token) return null;
//   try {
//     return jwtDecode<DecodedToken>(token);
//   } catch (err) {
//     console.error("Failed to decode token", err);
//     return null;
//   }
// };

const NavBar = () => {
  const router = useRouter();
  const dispatch = useDispatch();
  const user = useSelector((state: RootState) => state.auth.user);
  const { data } = useGetMeUserQuery({});
  console.log("Logged User info", data);
  const users = data?.data;
  const getPrefixedPath = usePrefixedPath();
  const t = useTranslations("home.navbar");

  const socialToken = localStorage.getItem("accessToken");
  // const decoded = decodeToken(socialToken);
  // console.log("Decoded token:", decoded);

  if (!user) {
    dispatch(
      setUser({
        access_token: socialToken || null,
      })
    );
  }

  // console.log("Decoded token:", decoded);

  let navItems;

  if (user?.role === "USER" || users?.role === "USER") {
    navItems = [
      {
        label: "Home",
        path: getPrefixedPath("/"),
      },
      {
        label: "Upload Photo",
        path: getPrefixedPath("/upload-photo"),
      },
      {
        label: "History",
        path: getPrefixedPath("/history"),
      },
    ];
  } else {
    // For guests or unknown roles
    navItems = [
      { label: t("home"), path: getPrefixedPath("/") },
      { label: t("about"), path: getPrefixedPath("/about-us") },
      { label: t("contact"), path: getPrefixedPath("/blog") },
      { label: t("pricing"), path: getPrefixedPath("/price") },
      { label: t("contactUs"), path: getPrefixedPath("/contact-us") },
    ];
  }

  // Example buttons with custom components
  const buttons = [
    {
      label: t("login"),
      component: (
        <Button
          className="inline-flex items-center px-4 justify-center gap-2.5 py-0.5 rounded[16px] border border-[#01E3EA] bg-transparent text-[#01E3EA] hover:text-black"
          onClick={() => router.push(getPrefixedPath("/login"))}
        >
          {t("login")}
        </Button>
      ),
    },
  ];

  // Example conditional routes
  const conditionalRoutes = {
    [getPrefixedPath("/pricing")]: true, // Show pricing page
    [getPrefixedPath("/admin")]: false, // Hide admin page
  };

  return (
    <div className="mb-16 lg:mb-20">
      <Navbar
        className="max-w-[1200px] mx-auto sm:px-[1.5%]"
        position="fixed"
        shadow="shadow-none"
        backgroundColor="bg-transparent lg:py-4"
        logo={NavLogo.src}
        activeTextColor="!text-[#02CCD8]  font-poppins font-bold"
        textColor="text-white text-lg font-normal font-poppins text-lg "
        hoverTextColor="hover:text-nav-text-light"
        navItems={navItems}
        buttons={buttons}
        hideOnScroll
        conditionalRoutes={conditionalRoutes}
        onNavItemClick={(item) => console.log("Nav item clicked:", item.label)}
        onButtonClick={(index, button) =>
          console.log(`Button ${index} clicked:`, button.label)
        }
      />
    </div>
  );
};

export default NavBar;
