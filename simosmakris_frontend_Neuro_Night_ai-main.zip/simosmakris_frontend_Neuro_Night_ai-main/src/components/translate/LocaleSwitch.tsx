// "use client";

// import { usePathname } from "next/navigation";
// import {
//   DropdownMenu,
//   DropdownMenuContent,
//   DropdownMenuItem,
//   DropdownMenuTrigger,
// } from "@/components/ui/dropdown-menu";
// import { Button } from "@/components/ui/button";
// import { LucideChevronDown } from "lucide-react";
// import { useEffect, useState } from "react";
// //
// const LOCALES = {
//   en: "English",
//   fr: "French",
//   es: "Spanish",
// } as const;

// type Locale = keyof typeof LOCALES;

// export default function LocaleSwitcher() {
//   const pathname = usePathname();
//   const [currentLocale, setCurrentLocale] = useState<Locale>("en");

//   // Detect current locale from URL
//   useEffect(() => {
//     const pathLocale = pathname.split("/")[1] as Locale;
//     if (pathLocale && LOCALES[pathLocale]) {
//       setCurrentLocale(pathLocale);
//     }
//   }, [pathname]);

//   // Initialize Google Translate once with error handling
//   useEffect(() => {
//     if (window.googleTranslateLoaded) return;

//     // Suppress the removeChild error
//     const originalRemoveChild = Node.prototype.removeChild;
//     Node.prototype.removeChild = function <T extends Node>(
//       this: Node,
//       child: T
//     ): T {
//       try {
//         if (this.contains(child)) {
//           // ensure the returned value is typed as T
//           return originalRemoveChild.call(this, child) as T;
//         }
//         return child;
//       } catch (e) {
//         console.warn("Suppressed removeChild error:", e);
//         return child;
//       }
//     };

//     window.googleTranslateElementInit = () => {
//       try {
//         // Ensure google.translate is available before trying to instantiate it
//         if (
//           typeof window === "undefined" ||
//           !window.google ||
//           !window.google.translate ||
//           !window.google.translate.TranslateElement
//         ) {
//           console.error("Google Translate API is not available on window");
//           return;
//         }

//         // Use a s-cast to avoid TS errors while calling the external constructor
//         new window.google.translate.TranslateElement(
//           {
//             pageLanguage: "en",
//             includedLanguages: "en,fr,es",
//             autoDisplay: false,
//           },
//           "google_translate_element"
//         );
//         window.googleTranslateLoaded = true;
//         console.log("✅ Google Translate loaded");
//       } catch (error) {
//         console.error("Failed to initialize Google Translate:", error);
//       }
//     };

//     // Load script
//     const script = document.createElement("script");
//     script.src =
//       "//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
//     script.async = true;
//     script.onerror = () =>
//       console.error("Failed to load Google Translate script");
//     document.body.appendChild(script);

//     // Hide Google Translate banner
//     const style = document.createElement("style");
//     style.innerHTML = `
//       .goog-te-banner-frame {
//         display: none !important;
//       }
//       body {
//         top: 0 !important;
//         position: static !important;
//       }
//       .skiptranslate {
//         display: none !important;
//       }
//       #google_translate_element {
//         display: none !important;
//       }
//       font {
//           background: transparent !important;
//           box-shadow: none !important;
//           border: none !important;
//       }

//     `;
//     document.head.appendChild(style);

//     // Cleanup
//     return () => {
//       // Restore original removeChild
//       Node.prototype.removeChild = originalRemoveChild;
//     };
//   }, []);

//   const switchLocale = (newLocale: Locale) => {
//     if (newLocale === currentLocale) return;

//     console.log("🔄 Switching to:", newLocale);

//     // Build new path
//     const segments = pathname.split("/").filter(Boolean);

//     if (LOCALES[segments[0] as Locale]) {
//       segments[0] = newLocale;
//     } else {
//       segments.unshift(newLocale);
//     }

//     const newPath = "/" + segments.join("/");

//     // Clear any existing Google Translate cookie first
//     document.cookie =
//       "googtrans=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT";

//     // Set new Google Translate cookie
//     const cookieValue = newLocale === "en" ? "/en" : `/${newLocale}`;
//     document.cookie = `googtrans=${cookieValue}; path=/; max-age=31536000`;

//     // Small delay to ensure cookie is set
//     setTimeout(() => {
//       window.location.href = newPath;
//     }, 100);
//   };

//   return (
//     <div className="flex items-center gap-4">
//       <DropdownMenu>
//         <DropdownMenuTrigger asChild>
//           <Button
//             variant="ghost"
//             size="sm"
//             className="uppercase  flex items-center md:text-sm text-[17px] text-bold gap-2"
//             translate="no"
//           >
//             {currentLocale} <LucideChevronDown className="w-4 h-4" />
//           </Button>
//         </DropdownMenuTrigger>
//         <DropdownMenuContent align="center" className="min-w-[120px] z-[9999] ">
//           {Object.entries(LOCALES).map(([key, value]) => (
//             <DropdownMenuItem
//               key={key}
//               onClick={() => switchLocale(key as Locale)}
//               className="capitalize cursor-pointer"
//               disabled={key === currentLocale}
//               translate="no"
//             >
//               {value}
//             </DropdownMenuItem>
//           ))}
//         </DropdownMenuContent>
//       </DropdownMenu>

//       <div id="google_translate_element" style={{ display: "none" }} />
//     </div>
//   );
// }

"use client";

import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { LucideChevronDown } from "lucide-react";

const LOCALES = {
  en: "English",
  fr: "French",
  es: "Spanish",
} as const;

type Locale = keyof typeof LOCALES;

export default function LocaleSwitcher() {
  const pathname = usePathname();
  const [currentLocale, setCurrentLocale] = useState<Locale>("en");

  useEffect(() => {
    // Get locale from path
    const pathLocale = pathname.split("/")[1] as Locale;
    if (pathLocale && LOCALES[pathLocale]) {
      setCurrentLocale(pathLocale);
    }
  }, [pathname]);

  const switchLocale = async (newLocale: Locale) => {
    if (newLocale === currentLocale) return;

    console.log("🔄 Switching locale to:", newLocale);

    try {
      // 1. Update next-intl cookie
      document.cookie = `NEXT_LOCALE=${newLocale}; path=/; max-age=31536000; samesite=lax`;

      // 2. Clear old Google Translate cookie
      document.cookie =
        "googtrans=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; samesite=lax";

      // 3. Set new Google Translate cookie
      const googTransValue = newLocale === "en" ? "" : `/en/${newLocale}`;
      document.cookie = `googtrans=${googTransValue}; path=/; max-age=31536000; samesite=lax`;

      console.log("🍪 Cookies set:", {
        NEXT_LOCALE: newLocale,
        googtrans: googTransValue,
      });

      // 4. Build new path
      const segments = pathname.split("/").filter(Boolean);

      // Remove existing locale if present
      if (LOCALES[segments[0] as Locale]) {
        segments.shift();
      }

      // Add new locale (only if not default 'en' with as-needed prefix)
      const newPath =
        newLocale === "en"
          ? `/${segments.join("/")}`
          : `/${newLocale}/${segments.join("/")}`;

      console.log("🔗 Navigating to:", newPath);

      // 5. Apply translation via Google Translate selector
      const applyGoogleTranslate = () => {
        const select =
          document.querySelector<HTMLSelectElement>(".goog-te-combo");
        if (select) {
          select.value = newLocale;
          select.dispatchEvent(new Event("change"));
          console.log("✅ Google Translate applied:", newLocale);
        } else {
          console.warn("⚠️ Google Translate selector not found yet");
        }
      };

      // 6. Navigate and apply translation
      setTimeout(() => {
        window.location.href = newPath;
        // Try applying after navigation
        setTimeout(applyGoogleTranslate, 500);
      }, 100);
    } catch (error) {
      console.error("❌ Error switching locale:", error);
    }
  };

  return (
    <div className="flex items-center gap-4 notranslate">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className="uppercase flex items-center text-[16px] gap-2"
          >
            {currentLocale} <LucideChevronDown className="w-4 h-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="center" className="min-w-[120px] z-[9999]">
          {Object.entries(LOCALES).map(([key, value]) => (
            <DropdownMenuItem
              key={key}
              onClick={() => switchLocale(key as Locale)}
              disabled={key === currentLocale}
              className="capitalize cursor-pointer notranslate"
            >
              {value}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
      <div id="google_translate_element" style={{ display: "none" }} />
    </div>
  );
}
