// "use client";

// import { useEffect } from "react";

// export default function ClientProviders({
//   children,
// }: {
//   children: React.ReactNode;
// }) {
//   useEffect(() => {
//     // Only initialize once
//     if (window.googleTranslateLoaded) return;

//     // Suppress the removeChild error
//     const originalRemoveChild = Node.prototype.removeChild;
//     Node.prototype.removeChild = function <T extends Node>(
//       this: Node,
//       child: T
//     ): T {
//       try {
//         if (this.contains(child)) {
//           return originalRemoveChild.call(this, child) as T;
//         }
//         return child;
//       } catch (e) {
//         // Silently suppress the error
//         return child;
//       }
//     };

//     // Initialize Google Translate
//     window.googleTranslateElementInit = () => {
//       try {
//         // Guard and narrow types: ensure window.google and its translate API are available
//         if (
//           window.google &&
//           window.google.translate &&
//           typeof window.google.translate.TranslateElement === "function"
//         ) {
//           new window.google.translate.TranslateElement(
//             {
//               pageLanguage: "en",
//               includedLanguages: "en,fr,es",
//               autoDisplay: false,
//             },
//             "google_translate_element"
//           );
//           window.googleTranslateLoaded = true;
//           console.log("✅ Google Translate loaded globally");
//         } else {
//           console.error("google.translate is not available on window");
//         }
//       } catch (error) {
//         console.error("Failed to initialize Google Translate:", error);
//       }
//     };

//     // Load script
//     const script = document.createElement("script");
//     script.src =
//       "//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
//     script.async = true;
//     script.onerror = () =>
//       console.error("Failed to load Google Translate script");
//     document.body.appendChild(script);

//     // Hide Google Translate UI
//     const style = document.createElement("style");
//     style.innerHTML = `
//       .goog-te-banner-frame {
//         display: none !important;
//       }
//       body {
//         top: 0 !important;
//         position: static !important;
//       }
//       .skiptranslate {
//         display: none !important;
//       }
//       #google_translate_element {
//         display: none !important;
//       }
//       .goog-te-combo {
//         display: none !important;
//       }

//       font {
//           background: transparent !important;
//           box-shadow: none !important;
//           border: none !important;
//       }

//     `;
//     document.head.appendChild(style);

//     // Cleanup
//     return () => {
//       Node.prototype.removeChild = originalRemoveChild;
//     };
//   }, []);

//   return (
//     <>
//       <div id="google_translate_element" style={{ display: "none" }} />
//       {children}
//     </>
//   );
// }

"use client";

import { useEffect } from "react";

declare global {
  interface Window {
    google?: {
      translate: {
        TranslateElement: new (
          config: {
            pageLanguage: string;
            includedLanguages: string;
            layout?: number;
            autoDisplay?: boolean;
            multilanguagePage?: boolean;
          },
          elementId: string
        ) => void;
        InlineLayout?: {
          SIMPLE: number;
          HORIZONTAL: number;
          VERTICAL: number;
        };
      };
    };
    googleTranslateElementInit?: () => void;
    googleTranslateLoaded?: boolean;
  }
}

export default function ClientProviders({
  children,
}: {
  children: React.ReactNode;
}) {
  useEffect(() => {
    // Prevent double initialization
    if (window.googleTranslateLoaded) {
      console.log("✅ Google Translate already loaded");
      return;
    }

    // Prevent random Google Translate removeChild errors
    const originalRemoveChild = Node.prototype.removeChild;
    Node.prototype.removeChild = function <T extends Node>(
      this: Node,
      child: T
    ): T {
      try {
        if (this.contains(child)) {
          return originalRemoveChild.call(this, child) as T;
        }
        return child;
      } catch {
        return child;
      }
    };

    // Initialize function
    window.googleTranslateElementInit = () => {
      try {
        const element = document.getElementById("google_translate_element");
        if (!element) {
          console.error("❌ google_translate_element not found in DOM");
          return;
        }

        if (
          window.google?.translate?.TranslateElement &&
          typeof window.google.translate.TranslateElement === "function"
        ) {
          new window.google.translate.TranslateElement(
            {
              pageLanguage: "en",
              includedLanguages: "en,fr,es",
              layout: window.google.translate.InlineLayout?.SIMPLE,
              autoDisplay: false,
              multilanguagePage: true,
            },
            "google_translate_element"
          );
          window.googleTranslateLoaded = true;
          console.log("✅ Google Translate initialized successfully");
        } else {
          console.warn("⚠️ Google Translate API not ready yet");
          // Retry after delay
          setTimeout(() => {
            if (window.googleTranslateElementInit) {
              window.googleTranslateElementInit();
            }
          }, 1000);
        }
      } catch (error) {
        console.error("❌ Google Translate init failed:", error);
      }
    };

    // Remove existing script if any (for hot reload)
    const existingScript = document.querySelector(
      'script[src*="translate.google.com"]'
    );
    if (existingScript) {
      existingScript.remove();
    }

    // Load Google Translate script with error handling
    const script = document.createElement("script");
    script.src =
      "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
    script.async = true;
    script.defer = true;

    script.onload = () => {
      console.log("✅ Google Translate script loaded");
    };

    script.onerror = (error) => {
      console.error("❌ Failed to load Google Translate script:", error);
      console.error("Check if your VPS can access translate.google.com");
      console.error("Try: curl -I https://translate.google.com");
    };

    document.body.appendChild(script);

    // Hide Google UI artifacts with more comprehensive CSS
    const style = document.createElement("style");
    style.innerHTML = `
      /* Hide all Google Translate UI elements */
      .goog-te-banner-frame,
      .goog-te-gadget-icon,
      .goog-te-menu-frame,
      .goog-te-balloon-frame,
      .goog-te-combo,
      .skiptranslate,
      iframe.skiptranslate,
      .goog-te-spinner-pos {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
      }
      
      /* Prevent body shift */
      body { 
        top: 0 !important; 
        position: static !important;
      }
      
      /* Hide Google branding */
      [class^="VIpgJd-ZVi9od"],
      [class*="VIpgJd-ZVi9od"] {
        display: none !important;
        opacity: 0 !important;
      }
      
      /* Ensure translate element is hidden */
      #google_translate_element {
        display: none !important;
      }
      
      /* Hide any Google Translate iframes */
      iframe[id^="goog-gt-"] {
        display: none !important;
        visibility: hidden !important;
      }
    `;
    document.head.appendChild(style);

    return () => {
      Node.prototype.removeChild = originalRemoveChild;
    };
  }, []);

  return (
    <>
      <div id="google_translate_element" style={{ display: "none" }} />
      {children}
    </>
  );
}
