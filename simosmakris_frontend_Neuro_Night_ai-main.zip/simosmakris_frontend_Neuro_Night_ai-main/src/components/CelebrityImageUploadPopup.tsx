'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Upload } from 'lucide-react';
import { toast } from 'sonner';

interface UploadPopupProps {
  open: boolean;
  onClose: () => void;
}

const CelebrityImageUploadPopup: React.FC<UploadPopupProps> = ({ open, onClose }) => {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast.error('File size exceeds 5MB');
      return;
    }

    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      toast.error('Unsupported file type');
      return;
    }

    const formData = new FormData();
    formData.append('files', file);
    formData.append('folder', 'index');

    try {
      setUploading(true);
      setProgress(0);

      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/celebrity/add', true);

      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          let percentComplete = Math.round((event.loaded / event.total) * 10);
          if (percentComplete > 10) percentComplete = 10;
          setProgress(percentComplete);
        }
      };

      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          let current = progress;
          const interval = setInterval(() => {
            current += 2;
            if (current >= 100) {
              current = 100;
              clearInterval(interval);
              setProgress(100);
              setUploading(false);
              toast.success('Upload completed successfully');
              setTimeout(() => {
                onClose();
                setProgress(0);
              }, 800);
            } else {
              setProgress(current);
            }
          }, 30);
        } else {
          setUploading(false);
          toast.error('Upload failed');
        }
      };



      xhr.onerror = () => {
        setUploading(false);
        toast.error('Something went wrong');
      };

      xhr.send(formData);
    } catch (err) {
      console.error(err);
      setUploading(false);
      toast.error('Something went wrong');
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          key="upload-popup"
          className="fixed inset-0 z-[999] flex items-center justify-center bg-black/50 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="relative w-full max-w-lg mx-auto bg-[#00FFFF]/10 rounded-2xl shadow-xl"
          >
            <button
              onClick={onClose}
              disabled={uploading}
              className="absolute top-3 right-3 p-1 rounded-full hover:bg-white/10 disabled:opacity-50"
            >
              <X className="text-white" />
            </button>

            <div className="p-10 flex flex-col items-center justify-center text-center text-white min-h-[300px] w-full">
              {uploading ? (
                <div className="w-full flex flex-col items-center gap-4">
                  <p className="text-lg font-medium">Uploading {progress}%</p>
                  <div className="w-full bg-white/20 rounded-full h-4 overflow-hidden">
                    <motion.div
                      className="bg-[#00FFFFB2] h-4"
                      initial={{ width: 0 }}
                      animate={{ width: `${progress}%` }}
                      transition={{ ease: 'linear', duration: 0.2 }}
                    />
                  </div>
                </div>
              ) : (
                <>
                  <Upload className="w-10 h-10 mb-3 text-white" />
                  <h2 className="text-2xl font-semibold mb-2">Upload Data</h2>
                  <p className="text-sm mb-6">
                    Click to browse or drag and drop your image here
                    <br />
                    Supports JPG, PNG, WebP • Max 5MB
                  </p>
                  <label
                    htmlFor="fileInput"
                    className="cursor-pointer px-5 py-3 bg-[#00FFFFB2] hover:bg-[#00FFFFB2]/90 rounded-lg font-medium text-white"
                  >
                    Choose File
                  </label>
                  <input
                    id="fileInput"
                    type="file"
                    className="hidden"
                    accept=".jpg,.jpeg,.png,.webp"
                    onChange={handleFileChange}
                    disabled={uploading}
                  />
                </>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CelebrityImageUploadPopup;