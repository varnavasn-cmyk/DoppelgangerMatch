import Blog from "../pages/home/Blog";
export default function BlogTitle() {
  return (
    <div className="flex flex-col items-center justify-center gap-5">
      <Blog />
    </div>
  );
}