"use client";
import { useGetBlogByIdQuery } from "@/redux/features/users/usersApi";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { Blog } from "../pages/home/Blog";

const ViewBlog = () => {
  const path =usePathname()
  const id = path.split('/')[2]
  const {data} = useGetBlogByIdQuery(id)
  const blog:Blog = data?.data
  return (
    <div className="flex flex-col justify-start items-start w-[984px] h-[auto]">
      <div className="rounded-[10px] bg-[lightgray_0px_-20.397px/100%_146.154%_no-repeat] shadow-[0_0_30px_rgba(2,204,216,0.3)] w-[984px] h-[499.455px] shrink-0">
        <Image
          src={blog?.image || "/images/blog/blog1.png"}
          width={984}
          height={250}
          alt="blog image"
          className="w-full h-full object-cover rounded-[10px]"
        />
      </div>
      <div className="mt-8">
        <h4 className="text-white font-poppins text-[24px] font-normal leading-[120%]">
          {blog?.title || "The Skybound: A Tale of Transformation"}
        </h4>
    <p>
      {blog?.description }
    </p>
      </div>
    </div>
  );
};

export default ViewBlog;
