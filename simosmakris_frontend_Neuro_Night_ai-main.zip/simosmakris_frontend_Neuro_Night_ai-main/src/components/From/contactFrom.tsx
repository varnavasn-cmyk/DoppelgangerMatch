"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { useTranslations } from "use-intl";

// Zod validation schema
const contactSchema = z.object({
  fullName: z
    .string()
    .min(2, "Full name must be at least 2 characters")
    .max(50, "Full name must be less than 50 characters"),
  email: z.string().email("Please enter a valid email address"),
  subject: z
    .string()
    .min(3, "Subject must be at least 3 characters")
    .max(100, "Subject must be less than 100 characters"),
  message: z
    .string()
    .min(10, "Message must be at least 10 characters")
    .max(1000, "Message must be less than 1000 characters"),
});

type ContactFormData = z.infer<typeof contactSchema>;

interface ApiResponse {
  success: boolean;
  message: string;
}

export default function ContactForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<
    "idle" | "success" | "error"
  >("idle");
  const [submitMessage, setSubmitMessage] = useState("");
  const t = useTranslations("contact-us");

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
  });

  const onSubmit = async (data: ContactFormData) => {
    setIsSubmitting(true);
    setSubmitStatus("idle");

    try {
      // Map message -> description for backend
      const payload = {
        fullName: data.fullName,
        email: data.email,
        subject: data.subject,
        description: data.message,
      };

      const response = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}/contacts/send-email`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        }
      );

      const result: ApiResponse = await response.json();

      if (response.ok) {
        setSubmitStatus("success");
        setSubmitMessage(result.message);
        reset();
      } else {
        setSubmitStatus("error");
        setSubmitMessage(result.message || "Something went wrong");
      }
    } catch {
      setSubmitStatus("error");
      setSubmitMessage("Failed to send message. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 w-full">
      {/* Name and Email Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="relative">
          <Input
            {...register("fullName")}
            type="text"
            placeholder={t("name")}
            className={`w-full  bg-transparent border-2 rounded-lg px-5 py-6  text-white placeholder-gray-400 transition-all duration-300 outline-none focus:border-teal-400 focus:shadow-lg focus:shadow-teal-400/20 focus:-translate-y-0.5 ${
              errors.fullName
                ? "border-red-400 focus:border-red-400 focus:shadow-red-400/20"
                : "border-teal-400/40"
            }`}
          />
          {errors.fullName && (
            <span className="absolute -bottom-5 left-0 text-red-400 text-xs">
              {errors.fullName.message}
            </span>
          )}
        </div>

        <div className="relative">
          <Input
            {...register("email")}
            type="email"
            placeholder={t("email")}
            className={`w-full  bg-transparent border-2 rounded-lg px-5 py-6  text-white placeholder-gray-400 transition-all duration-300 outline-none focus:border-teal-400 focus:shadow-lg focus:shadow-teal-400/20 focus:-translate-y-0.5 ${
              errors.email
                ? "border-red-400 focus:border-red-400 focus:shadow-red-400/20"
                : "border-teal-400/40"
            }`}
          />
          {errors.email && (
            <span className="absolute -bottom-5 left-0 text-red-400 text-xs">
              {errors.email.message}
            </span>
          )}
        </div>
      </div>

      {/* Subject */}
      <div className="relative">
        <Input
          {...register("subject")}
          type="text"
          placeholder={t("subject")}
          className={`w-full  bg-transparent border-2 rounded-lg px-5 py-6  text-white placeholder-gray-400 transition-all duration-300 outline-none focus:border-teal-400 focus:shadow-lg focus:shadow-teal-400/20 focus:-translate-y-0.5 ${
            errors.subject
              ? "border-red-400 focus:border-red-400 focus:shadow-red-400/20"
              : "border-teal-400/40"
          }`}
        />
        {errors.subject && (
          <span className="absolute -bottom-5 left-0 text-red-400 text-xs">
            {errors.subject.message}
          </span>
        )}
      </div>

      {/* Message */}
      <div className="relative">
        <textarea
          {...register("message")}
          placeholder={t("message")}
          rows={5}
          className={`w-full bg-transparent  border-2 rounded-lg px-5 py-4 text-white placeholder-gray-400 transition-all duration-300 outline-none resize-y focus:border-teal-400 focus:shadow-lg focus:shadow-teal-400/20 focus:-translate-y-0.5 ${
            errors.message
              ? "border-red-400 focus:border-red-400 focus:shadow-red-400/20"
              : "border-teal-400/40"
          }`}
        />
        {errors.message && (
          <span className="absolute -bottom-5 left-0 text-red-400 text-xs">
            {errors.message.message}
          </span>
        )}
      </div>

      {/* Status Message */}
      {submitStatus !== "idle" && (
        <div
          className={`p-3 rounded-lg text-sm text-center animate-fade-in-scale ${
            submitStatus === "success"
              ? "bg-green-500/20 border border-green-400 text-green-400"
              : "bg-red-500/20 border border-red-400 text-red-400"
          }`}
        >
          {submitMessage}
        </div>
      )}

      {/* Submit Button */}
      <Button
        type="submit"
        disabled={isSubmitting}
        className="w-[20%] bg-gradient-to-r from-teal-400 to-cyan-400 text-slate-900 font-semibold py-6 px-6 rounded-lg transition-all duration-300 outline-none hover:shadow-lg hover:shadow-teal-400/30 hover:-translate-y-0.5 hover:scale-[1.02] active:translate-y-0 active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed disabled:hover:translate-y-0 disabled:hover:scale-100"
      >
        {isSubmitting ? (
          <div className="flex items-center justify-center gap-3">
            <div className="w-4 h-4 border-2 border-slate-900/30 border-t-slate-900 rounded-full animate-spin"></div>
            Sending...
          </div>
        ) : (
          t("send")
        )}
      </Button>
    </form>
  );
}
