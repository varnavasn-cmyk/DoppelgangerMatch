"use client";

import * as React from "react";
import { format } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface DatePickerDemoProps {
  date?: Date;
  onDateChange?: (date: Date) => void;
}

export function DatePickerDemo({ date, onDateChange }: DatePickerDemoProps) {
  const [internalDate, setInternalDate] = React.useState<Date | undefined>(
    date
  );

  const handleSelect = (selectedDate: Date) => {
    setInternalDate(selectedDate);
    onDateChange?.(selectedDate); // call parent function
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          data-empty={!internalDate}
          className={cn(
            "w-[200px] justify-start bg-transparent border-primary border-[1px] rounded-lg text-left font-normal",
            !internalDate && "text-muted-foreground"
          )}
        >
          <CalendarIcon className="mr-2 h-4 w-4 text-[#02CCD8]" />
          {internalDate ? (
            format(internalDate, "PPP")
          ) : (
            <span>Pick a date</span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0">
        <Calendar
          mode="single"
          required={true}
          selected={internalDate}
          onSelect={handleSelect}
          initialFocus
        />
      </PopoverContent>
    </Popover>
  );
}
