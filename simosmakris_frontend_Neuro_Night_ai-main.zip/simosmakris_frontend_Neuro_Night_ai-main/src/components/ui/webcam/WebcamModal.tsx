// /* eslint-disable @typescript-eslint/no-explicit-any */
// // components/SimpleWebcamModal.tsx
// "use client";
// import { useEffect, useState } from "react";
// import {
//   X,
//   Camera,
//   RotateCcw,
//   Check,
//   RefreshCw,
//   AlertCircle,
//   ExternalLink,
// } from "lucide-react";
// import Webcam from "react-webcam";
// import { useSimpleWebcam } from "../../../hooks/useWebcam";
// import { Button } from "../button";

// interface SimpleWebcamModalProps {
//   isOpen: boolean;
//   onClose: () => void;
//   onImageCapture: (imageData: string) => void;
// }

// const SimpleWebcamModal: React.FC<SimpleWebcamModalProps> = ({
//   isOpen,
//   onClose,
//   onImageCapture,
// }) => {
//   const {
//     webcamRef,
//     capturedImage,
//     isReady,
//     error,
//     devices,
//     captureImage,
//     retakeImage,
//     switchCamera,
//     handleUserMedia,
//     handleUserMediaError,
//     videoConstraints,
//   } = useSimpleWebcam();

//   const [browserInfo, setBrowserInfo] = useState<{
//     isSupported: boolean;
//     isHttps: boolean;
//     browserName: string;
//     suggestions: string[];
//   }>({
//     isSupported: false,
//     isHttps: false,
//     browserName: "Unknown",
//     suggestions: [],
//   });

//   // Check browser compatibility
//   useEffect(() => {
//     const checkBrowserSupport = () => {
//       const isHttps =
//         window.location.protocol === "https:" ||
//         window.location.hostname === "localhost";
//       const userAgent = navigator.userAgent;

//       // Detect browser
//       let browserName = "Unknown Browser";
//       if (userAgent.includes("Chrome")) browserName = "Chrome";
//       else if (userAgent.includes("Firefox")) browserName = "Firefox";
//       else if (userAgent.includes("Safari") && !userAgent.includes("Chrome"))
//         browserName = "Safari";
//       else if (userAgent.includes("Edge")) browserName = "Edge";
//       else if (userAgent.includes("Opera")) browserName = "Opera";

//       // Check getUserMedia support
//       const hasGetUserMedia = !!(
//         navigator.mediaDevices?.getUserMedia ||
//         (navigator as any).getUserMedia ||
//         (navigator as any).webkitGetUserMedia ||
//         (navigator as any).mozGetUserMedia ||
//         (navigator as any).msGetUserMedia
//       );

//       const suggestions: string[] = [];

//       if (!isHttps) {
//         suggestions.push("🔒 Use HTTPS - Camera requires secure connection");
//         suggestions.push(
//           "📍 Access via https:// or use localhost for development"
//         );
//       }

//       if (!hasGetUserMedia) {
//         suggestions.push("🌐 Update your browser to the latest version");
//         suggestions.push("💻 Try Chrome, Firefox, or Edge (latest versions)");
//         suggestions.push("📱 On mobile, use the native browser or Chrome");
//       }

//       if (
//         userAgent.includes("Instagram") ||
//         userAgent.includes("Facebook") ||
//         userAgent.includes("Twitter")
//       ) {
//         suggestions.push("📱 Open in your main browser (not in-app browser)");
//         suggestions.push("🔗 Copy link and paste in Chrome/Safari");
//       }

//       console.log("Browser check:", {
//         browserName,
//         isHttps,
//         hasGetUserMedia,
//         userAgent: userAgent.substring(0, 100),
//       });

//       setBrowserInfo({
//         isSupported: hasGetUserMedia && isHttps,
//         isHttps,
//         browserName,
//         suggestions,
//       });
//     };

//     if (isOpen) {
//       checkBrowserSupport();
//     }
//   }, [isOpen]);

//   // Reset when modal closes
//   useEffect(() => {
//     if (!isOpen) {
//       retakeImage();
//     }
//   }, [isOpen, retakeImage]);

//   const handleClose = () => {
//     retakeImage();
//     onClose();
//   };

//   const handleCapture = () => {
//     console.log("🎯 Capture button clicked");
//     captureImage();
//   };

//   const handleConfirm = () => {
//     if (capturedImage) {
//       console.log("✅ Confirming captured image", capturedImage);
//       onImageCapture(capturedImage);
//       handleClose();
//     }
//   };

//   const handleRetake = () => {
//     console.log("🔄 Retaking photo");
//     retakeImage();
//   };

//   if (!isOpen) return null;

//   console.log(
//     "🚀 Modal render - Browser supported:",
//     browserInfo.isSupported,
//     "HTTPS:",
//     browserInfo.isHttps
//   );

//   return (
//     <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
//       <div className="relative w-full max-w-4xl bg-gray-900 rounded-lg overflow-hidden">
//         {/* Header */}
//         <div className="flex items-center justify-between p-4 border-b border-gray-700">
//           <div className="flex items-center gap-3">
//             <Camera className="w-5 h-5 text-[#02CCD8]" />
//             <h2 className="text-white text-xl font-semibold">
//               {capturedImage ? "Review Photo" : "Take Photo"}
//             </h2>
//             <span className="text-xs bg-gray-700 px-2 py-1 rounded text-gray-300">
//               {browserInfo.browserName}
//             </span>
//           </div>
//           <div className="flex items-center gap-2">
//             {/* Switch camera button */}
//             {devices.length > 1 &&
//               !capturedImage &&
//               browserInfo.isSupported && (
//                 <Button
//                   onClick={switchCamera}
//                   variant="ghost"
//                   size="sm"
//                   className="text-white hover:bg-gray-700"
//                   title={`Switch Camera (${devices.length} available)`}
//                 >
//                   <RefreshCw className="w-4 h-4" />
//                 </Button>
//               )}

//             {/* Close button */}
//             <Button
//               onClick={handleClose}
//               variant="ghost"
//               size="sm"
//               className="text-white hover:bg-gray-700"
//             >
//               <X className="w-5 h-5" />
//             </Button>
//           </div>
//         </div>

//         {/* Main Content Area */}
//         <div className="relative bg-black" style={{ minHeight: "500px" }}>
//           {/* Show captured image */}
//           {capturedImage ? (
//             <div className="flex items-center justify-center h-full p-4">
//               {/* eslint-disable-next-line @next/next/no-img-element */}
//               <img
//                 src={capturedImage}
//                 alt="Captured from webcam"
//                 className="max-w-full max-h-[70vh] object-contain rounded-lg"
//               />
//             </div>
//           ) : !browserInfo.isSupported ? (
//             /* Show browser compatibility error */
//             <div className="flex items-center justify-center h-full p-8">
//               <div className="text-center max-w-lg">
//                 <AlertCircle className="w-20 h-20 text-red-400 mx-auto mb-6" />
//                 <h3 className="text-red-400 text-xl font-bold mb-4">
//                   Camera Not Supported
//                 </h3>
//                 <p className="text-gray-300 mb-6 text-base">
//                   Your current browser or connection doesn&rsquo;t support
//                   camera access.
//                 </p>

//                 {/* Current status */}
//                 <div className="bg-gray-800 rounded-lg p-4 mb-6 text-left">
//                   <h4 className="text-white font-semibold mb-3">
//                     Current Status:
//                   </h4>
//                   <div className="space-y-2 text-sm">
//                     <div className="flex items-center justify-between">
//                       <span className="text-gray-300">Browser:</span>
//                       <span className="text-white">
//                         {browserInfo.browserName}
//                       </span>
//                     </div>
//                     <div className="flex items-center justify-between">
//                       <span className="text-gray-300">HTTPS:</span>
//                       <span
//                         className={
//                           browserInfo.isHttps
//                             ? "text-green-400"
//                             : "text-red-400"
//                         }
//                       >
//                         {browserInfo.isHttps ? "✅ Yes" : "❌ No"}
//                       </span>
//                     </div>
//                     <div className="flex items-center justify-between">
//                       <span className="text-gray-300">Camera API:</span>
//                       <span
//                         className={
//                           browserInfo.isSupported
//                             ? "text-green-400"
//                             : "text-red-400"
//                         }
//                       >
//                         {browserInfo.isSupported
//                           ? "✅ Supported"
//                           : "❌ Not Available"}
//                       </span>
//                     </div>
//                   </div>
//                 </div>

//                 {/* Solutions */}
//                 {browserInfo.suggestions.length > 0 && (
//                   <div className="bg-blue-900/30 rounded-lg p-4 mb-6 text-left">
//                     <h4 className="text-blue-300 font-semibold mb-3 flex items-center gap-2">
//                       <ExternalLink className="w-4 h-4" />
//                       How to Fix:
//                     </h4>
//                     <ul className="space-y-2 text-sm text-blue-100">
//                       {browserInfo.suggestions.map((suggestion, index) => (
//                         <li key={index} className="flex items-start gap-2">
//                           <span className="text-blue-300 mt-0.5">•</span>
//                           {suggestion}
//                         </li>
//                       ))}
//                     </ul>
//                   </div>
//                 )}

//                 {/* Quick fixes */}
//                 <div className="space-y-3">
//                   {!browserInfo.isHttps && (
//                     <Button
//                       onClick={() => {
//                         const httpsUrl = window.location.href.replace(
//                           "http://",
//                           "https://"
//                         );
//                         window.location.href = httpsUrl;
//                       }}
//                       className="bg-blue-600 hover:bg-blue-700 w-full"
//                     >
//                       🔒 Switch to HTTPS
//                     </Button>
//                   )}

//                   <div className="text-xs text-gray-400 space-y-1">
//                     <p>
//                       <strong>Recommended browsers:</strong>
//                     </p>
//                     <p>• Chrome 53+ • Firefox 36+ • Safari 11+ • Edge 79+</p>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           ) : error ? (
//             /* Show camera error */
//             <div className="flex items-center justify-center h-full p-8">
//               <div className="text-center max-w-md">
//                 <AlertCircle className="w-16 h-16 text-orange-400 mx-auto mb-4" />
//                 <h3 className="text-orange-400 text-lg font-semibold mb-3">
//                   Camera Permission Error
//                 </h3>
//                 <p className="text-gray-300 mb-6 text-sm leading-relaxed">
//                   {error}
//                 </p>

//                 <div className="space-y-2 text-xs text-gray-400 mb-4">
//                   <p>💡 Quick fixes:</p>
//                   <p>
//                     • Click &quot;Allow&rdquo; when browser asks for camera
//                     access
//                   </p>
//                   <p>• Check camera icon in address bar</p>
//                   <p>• Close other apps using camera</p>
//                   <p>• Refresh page and try again</p>
//                 </div>

//                 <Button
//                   onClick={() => window.location.reload()}
//                   className="bg-orange-600 hover:bg-orange-700"
//                 >
//                   🔄 Refresh Page
//                 </Button>
//               </div>
//             </div>
//           ) : (
//             /* Show webcam */
//             <div className="relative w-full h-full flex items-center justify-center">
//               <div className="w-full max-w-4xl">
//                 <Webcam
//                   ref={webcamRef}
//                   audio={false}
//                   height={500}
//                   width={800}
//                   screenshotFormat="image/jpeg"
//                   screenshotQuality={0.9}
//                   videoConstraints={videoConstraints}
//                   onUserMedia={handleUserMedia}
//                   onUserMediaError={handleUserMediaError}
//                   mirrored={true}
//                   className="w-full h-auto rounded-lg"
//                   style={{
//                     maxHeight: "500px",
//                     objectFit: "cover",
//                   }}
//                 />
//               </div>

//               {/* Camera status overlay */}
//               {!isReady && !error && (
//                 <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
//                   <div className="text-center text-white">
//                     <div className="w-12 h-12 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
//                     <p className="text-lg font-semibold">Starting Camera...</p>
//                     <p className="text-sm text-gray-300 mt-2">
//                       Please allow camera access when prompted
//                     </p>
//                   </div>
//                 </div>
//               )}

//               {/* Success indicator */}
//               {isReady && (
//                 <div className="absolute top-4 left-4 bg-green-600 text-white px-3 py-1 rounded-full text-sm flex items-center gap-2">
//                   <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
//                   Camera Ready
//                 </div>
//               )}

//               {/* Camera info */}
//               {devices.length > 0 && (
//                 <div className="absolute top-4 right-4 bg-black/60 text-white px-3 py-1 rounded text-sm">
//                   {devices.length} camera{devices.length > 1 ? "s" : ""}{" "}
//                   available
//                 </div>
//               )}

//               {/* Face guide */}
//               {isReady && (
//                 <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
//                   <div className="w-60 h-60 border-2 border-white/20 rounded-full"></div>
//                 </div>
//               )}
//             </div>
//           )}
//         </div>

//         {/* Controls */}
//         <div className="p-6 flex justify-center gap-4">
//           {capturedImage ? (
//             /* Photo review controls */
//             <>
//               <Button
//                 onClick={handleRetake}
//                 variant="outline"
//                 className="flex items-center gap-2 border-gray-600 text-white hover:bg-gray-700"
//               >
//                 <RotateCcw className="w-4 h-4" />
//                 Retake
//               </Button>
//               <Button
//                 onClick={handleConfirm}
//                 className="flex items-center gap-2 bg-[#02CCD8] hover:bg-[#01B8C4]"
//               >
//                 <Check className="w-4 h-4" />
//                 Use This Photo
//               </Button>
//             </>
//           ) : browserInfo.isSupported ? (
//             /* Capture controls */
//             <div className="flex flex-col items-center gap-4">
//               {/* Big capture button */}
//               <Button
//                 onClick={handleCapture}
//                 disabled={!isReady || !!error}
//                 className={`w-20 h-20 rounded-full flex items-center justify-center transition-all duration-200 ${
//                   isReady && !error
//                     ? "bg-[#02CCD8] hover:bg-[#01B8C4] hover:scale-105 shadow-xl"
//                     : "bg-gray-600 cursor-not-allowed opacity-50"
//                 }`}
//               >
//                 <div className="w-16 h-16 rounded-full border-4 border-white flex items-center justify-center">
//                   <div className="w-10 h-10 bg-white rounded-full"></div>
//                 </div>
//               </Button>

//               {/* Status text */}
//               <p className="text-gray-400 text-sm text-center">
//                 {error
//                   ? "Fix camera error above"
//                   : !isReady
//                   ? "Waiting for camera..."
//                   : "Click to capture photo"}
//               </p>
//             </div>
//           ) : (
//             /* Browser not supported */
//             <div className="text-center">
//               <p className="text-gray-400 text-sm mb-4">
//                 Camera not available in this browser
//               </p>
//               <Button
//                 onClick={() =>
//                   window.open("https://www.google.com/chrome/", "_blank")
//                 }
//                 variant="outline"
//                 className="border-gray-600 text-white hover:bg-gray-700"
//               >
//                 <ExternalLink className="w-4 h-4 mr-2" />
//                 Download Chrome
//               </Button>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SimpleWebcamModal;






/* eslint-disable @typescript-eslint/no-explicit-any */
// components/SimpleWebcamModal.tsx
"use client";
import { useEffect, useState } from "react";
import {
  X,
  Camera,
  RotateCcw,
  Check,
  RefreshCw,
  AlertCircle,
  ExternalLink,
} from "lucide-react";
import Webcam from "react-webcam";
import { useSimpleWebcam } from "../../../hooks/useWebcam";
import { Button } from "../button";

interface SimpleWebcamModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImageCapture: (file: File) => void;
}

/**
 * Converts a base64 string to a File object
 * @param base64String - The base64 data URL (e.g., "data:image/jpeg;base64,...")
 * @param fileName - The desired file name
 * @returns File object containing the binary image data
 */
const base64ToFile = (base64String: string, fileName: string): File => {
  // Split the base64 string into parts
  const arr = base64String.split(",");
  
  // Extract MIME type from data URL
  const mime = arr[0].match(/:(.*?);/)?.[1] || "image/jpeg";
  
  // Decode base64 to binary string
  const bstr = atob(arr[1]);
  
  // Convert binary string to Uint8Array
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  
  // Create and return File object
  return new File([u8arr], fileName, { type: mime });
};

const SimpleWebcamModal: React.FC<SimpleWebcamModalProps> = ({
  isOpen,
  onClose,
  onImageCapture,
}) => {
  const {
    webcamRef,
    capturedImage,
    isReady,
    error,
    devices,
    captureImage,
    retakeImage,
    switchCamera,
    handleUserMedia,
    handleUserMediaError,
    videoConstraints,
  } = useSimpleWebcam();

  const [browserInfo, setBrowserInfo] = useState<{
    isSupported: boolean;
    isHttps: boolean;
    browserName: string;
    suggestions: string[];
  }>({
    isSupported: false,
    isHttps: false,
    browserName: "Unknown",
    suggestions: [],
  });

  // Check browser compatibility on mount
  useEffect(() => {
    const checkBrowserSupport = () => {
      const isHttps =
        window.location.protocol === "https:" ||
        window.location.hostname === "localhost";
      const userAgent = navigator.userAgent;

      // Detect browser name
      let browserName = "Unknown Browser";
      if (userAgent.includes("Chrome")) browserName = "Chrome";
      else if (userAgent.includes("Firefox")) browserName = "Firefox";
      else if (userAgent.includes("Safari") && !userAgent.includes("Chrome"))
        browserName = "Safari";
      else if (userAgent.includes("Edge")) browserName = "Edge";
      else if (userAgent.includes("Opera")) browserName = "Opera";

      // Check if getUserMedia API is supported
      const hasGetUserMedia = !!(
        navigator.mediaDevices?.getUserMedia ||
        (navigator as any).getUserMedia ||
        (navigator as any).webkitGetUserMedia ||
        (navigator as any).mozGetUserMedia ||
        (navigator as any).msGetUserMedia
      );

      const suggestions: string[] = [];

      // Add suggestions based on issues detected
      if (!isHttps) {
        suggestions.push("🔒 Use HTTPS - Camera requires secure connection");
        suggestions.push(
          "📍 Access via https:// or use localhost for development"
        );
      }

      if (!hasGetUserMedia) {
        suggestions.push("🌐 Update your browser to the latest version");
        suggestions.push("💻 Try Chrome, Firefox, or Edge (latest versions)");
        suggestions.push("📱 On mobile, use the native browser or Chrome");
      }

      // Detect in-app browsers
      if (
        userAgent.includes("Instagram") ||
        userAgent.includes("Facebook") ||
        userAgent.includes("Twitter")
      ) {
        suggestions.push("📱 Open in your main browser (not in-app browser)");
        suggestions.push("🔗 Copy link and paste in Chrome/Safari");
      }

      console.log("Browser check:", {
        browserName,
        isHttps,
        hasGetUserMedia,
        userAgent: userAgent.substring(0, 100),
      });

      setBrowserInfo({
        isSupported: hasGetUserMedia && isHttps,
        isHttps,
        browserName,
        suggestions,
      });
    };

    if (isOpen) {
      checkBrowserSupport();
    }
  }, [isOpen]);

  // Reset captured image when modal closes
  useEffect(() => {
    if (!isOpen) {
      retakeImage();
    }
  }, [isOpen, retakeImage]);

  const handleClose = () => {
    retakeImage();
    onClose();
  };

  const handleCapture = () => {
    console.log("🎯 Capture button clicked");
    captureImage();
  };

  const handleConfirm = () => {
    if (capturedImage) {
      try {
        console.log("✅ Confirming captured image");
        
        // Generate unique filename with timestamp
        const timestamp = Date.now();
        const fileName = `webcam-capture-${timestamp}.jpg`;
        
        // Convert base64 string to binary File object
        const file = base64ToFile(capturedImage, fileName);
        
        console.log("📸 File created successfully:", {
          name: file.name,
          size: `${(file.size / 1024).toFixed(2)} KB`,
          type: file.type,
          lastModified: new Date(file.lastModified).toISOString(),
        });
        
        // Pass the File object to parent component
        onImageCapture(file);
        
        // Close modal after successful capture
        
        handleClose();
      } catch (error) {
        console.error("❌ Error converting image to file:", error);
        alert("Failed to process the captured image. Please try again.");
      }
    }
  };

  const handleRetake = () => {
    console.log("🔄 Retaking photo");
    retakeImage();
  };

  // Don't render if modal is closed
  if (!isOpen) return null;

  console.log(
    "🚀 Modal render - Browser supported:",
    browserInfo.isSupported,
    "HTTPS:",
    browserInfo.isHttps
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
      <div className="relative w-full max-w-4xl bg-gray-900 rounded-lg overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <Camera className="w-5 h-5 text-[#02CCD8]" />
            <h2 className="text-white text-xl font-semibold">
              {capturedImage ? "Review Photo" : "Take Photo"}
            </h2>
            <span className="text-xs bg-gray-700 px-2 py-1 rounded text-gray-300">
              {browserInfo.browserName}
            </span>
          </div>
          <div className="flex items-center gap-2">
            {/* Switch camera button - only show if multiple cameras available */}
            {devices.length > 1 &&
              !capturedImage &&
              browserInfo.isSupported && (
                <Button
                  onClick={switchCamera}
                  variant="ghost"
                  size="sm"
                  className="text-white hover:bg-gray-700"
                  title={`Switch Camera (${devices.length} available)`}
                >
                  <RefreshCw className="w-4 h-4" />
                </Button>
              )}

            {/* Close button */}
            <Button
              onClick={handleClose}
              variant="ghost"
              size="sm"
              className="text-white hover:bg-gray-700"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="relative bg-black" style={{ minHeight: "500px" }}>
          {capturedImage ? (
            /* ===== CAPTURED IMAGE PREVIEW ===== */
            <div className="flex items-center justify-center h-full p-4">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={capturedImage}
                alt="Captured from webcam"
                className="max-w-full max-h-[70vh] object-contain rounded-lg"
              />
            </div>
          ) : !browserInfo.isSupported ? (
            /* ===== BROWSER NOT SUPPORTED ERROR ===== */
            <div className="flex items-center justify-center h-full p-8">
              <div className="text-center max-w-lg">
                <AlertCircle className="w-20 h-20 text-red-400 mx-auto mb-6" />
                <h3 className="text-red-400 text-xl font-bold mb-4">
                  Camera Not Supported
                </h3>
                <p className="text-gray-300 mb-6 text-base">
                  Your current browser or connection doesn&rsquo;t support
                  camera access.
                </p>

                {/* Current status display */}
                <div className="bg-gray-800 rounded-lg p-4 mb-6 text-left">
                  <h4 className="text-white font-semibold mb-3">
                    Current Status:
                  </h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Browser:</span>
                      <span className="text-white">
                        {browserInfo.browserName}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">HTTPS:</span>
                      <span
                        className={
                          browserInfo.isHttps
                            ? "text-green-400"
                            : "text-red-400"
                        }
                      >
                        {browserInfo.isHttps ? "✅ Yes" : "❌ No"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Camera API:</span>
                      <span
                        className={
                          browserInfo.isSupported
                            ? "text-green-400"
                            : "text-red-400"
                        }
                      >
                        {browserInfo.isSupported
                          ? "✅ Supported"
                          : "❌ Not Available"}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Solutions and suggestions */}
                {browserInfo.suggestions.length > 0 && (
                  <div className="bg-blue-900/30 rounded-lg p-4 mb-6 text-left">
                    <h4 className="text-blue-300 font-semibold mb-3 flex items-center gap-2">
                      <ExternalLink className="w-4 h-4" />
                      How to Fix:
                    </h4>
                    <ul className="space-y-2 text-sm text-blue-100">
                      {browserInfo.suggestions.map((suggestion, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="text-blue-300 mt-0.5">•</span>
                          {suggestion}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Quick fixes */}
                <div className="space-y-3">
                  {!browserInfo.isHttps && (
                    <Button
                      onClick={() => {
                        const httpsUrl = window.location.href.replace(
                          "http://",
                          "https://"
                        );
                        window.location.href = httpsUrl;
                      }}
                      className="bg-blue-600 hover:bg-blue-700 w-full"
                    >
                      🔒 Switch to HTTPS
                    </Button>
                  )}

                  <div className="text-xs text-gray-400 space-y-1">
                    <p>
                      <strong>Recommended browsers:</strong>
                    </p>
                    <p>• Chrome 53+ • Firefox 36+ • Safari 11+ • Edge 79+</p>
                  </div>
                </div>
              </div>
            </div>
          ) : error ? (
            /* ===== CAMERA PERMISSION ERROR ===== */
            <div className="flex items-center justify-center h-full p-8">
              <div className="text-center max-w-md">
                <AlertCircle className="w-16 h-16 text-orange-400 mx-auto mb-4" />
                <h3 className="text-orange-400 text-lg font-semibold mb-3">
                  Camera Permission Error
                </h3>
                <p className="text-gray-300 mb-6 text-sm leading-relaxed">
                  {error}
                </p>

                <div className="space-y-2 text-xs text-gray-400 mb-4">
                  <p>💡 Quick fixes:</p>
                  <p>
                    • Click &quot;Allow&rdquo; when browser asks for camera
                    access
                  </p>
                  <p>• Check camera icon in address bar</p>
                  <p>• Close other apps using camera</p>
                  <p>• Refresh page and try again</p>
                </div>

                <Button
                  onClick={() => window.location.reload()}
                  className="bg-orange-600 hover:bg-orange-700"
                >
                  🔄 Refresh Page
                </Button>
              </div>
            </div>
          ) : (
            /* ===== WEBCAM LIVE VIEW ===== */
            <div className="relative w-full h-full flex items-center justify-center">
              <div className="w-full max-w-4xl">
                <Webcam
                  ref={webcamRef}
                  audio={false}
                  height={500}
                  width={800}
                  screenshotFormat="image/jpeg"
                  screenshotQuality={0.9}
                  videoConstraints={videoConstraints}
                  onUserMedia={handleUserMedia}
                  onUserMediaError={handleUserMediaError}
                  mirrored={true}
                  className="w-full h-auto rounded-lg"
                  style={{
                    maxHeight: "500px",
                    objectFit: "cover",
                  }}
                />
              </div>

              {/* Camera loading overlay */}
              {!isReady && !error && (
                <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
                  <div className="text-center text-white">
                    <div className="w-12 h-12 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                    <p className="text-lg font-semibold">Starting Camera...</p>
                    <p className="text-sm text-gray-300 mt-2">
                      Please allow camera access when prompted
                    </p>
                  </div>
                </div>
              )}

              {/* Camera ready indicator */}
              {isReady && (
                <div className="absolute top-4 left-4 bg-green-600 text-white px-3 py-1 rounded-full text-sm flex items-center gap-2">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  Camera Ready
                </div>
              )}

              {/* Available cameras count */}
              {devices.length > 0 && (
                <div className="absolute top-4 right-4 bg-black/60 text-white px-3 py-1 rounded text-sm">
                  {devices.length} camera{devices.length > 1 ? "s" : ""}{" "}
                  available
                </div>
              )}

              {/* Face guide circle */}
              {isReady && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-60 h-60 border-2 border-white/20 rounded-full"></div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Controls Footer */}
        <div className="p-6 flex justify-center gap-4">
          {capturedImage ? (
            /* ===== PHOTO REVIEW CONTROLS ===== */
            <>
              <Button
                onClick={handleRetake}
                variant="outline"
                className="flex items-center gap-2 border-gray-600 text-white hover:bg-gray-700"
              >
                <RotateCcw className="w-4 h-4" />
                Retake
              </Button>
              <Button
                onClick={handleConfirm}
                className="flex items-center gap-2 bg-[#02CCD8] hover:bg-[#01B8C4]"
              >
                <Check className="w-4 h-4" />
                Use This Photo
              </Button>
            </>
          ) : browserInfo.isSupported ? (
            /* ===== CAPTURE CONTROLS ===== */
            <div className="flex flex-col items-center gap-4">
              {/* Big circular capture button */}
              <Button
                onClick={handleCapture}
                disabled={!isReady || !!error}
                className={`w-20 h-20 rounded-full flex items-center justify-center transition-all duration-200 ${
                  isReady && !error
                    ? "bg-[#02CCD8] hover:bg-[#01B8C4] hover:scale-105 shadow-xl"
                    : "bg-gray-600 cursor-not-allowed opacity-50"
                }`}
              >
                <div className="w-16 h-16 rounded-full border-4 border-white flex items-center justify-center">
                  <div className="w-10 h-10 bg-white rounded-full"></div>
                </div>
              </Button>

              {/* Status text */}
              <p className="text-gray-400 text-sm text-center">
                {error
                  ? "Fix camera error above"
                  : !isReady
                  ? "Waiting for camera..."
                  : "Click to capture photo"}
              </p>
            </div>
          ) : (
            /* ===== BROWSER NOT SUPPORTED CONTROLS ===== */
            <div className="text-center">
              <p className="text-gray-400 text-sm mb-4">
                Camera not available in this browser
              </p>
              <Button
                onClick={() =>
                  window.open("https://www.google.com/chrome/", "_blank")
                }
                variant="outline"
                className="border-gray-600 text-white hover:bg-gray-700"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Download Chrome
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SimpleWebcamModal;
