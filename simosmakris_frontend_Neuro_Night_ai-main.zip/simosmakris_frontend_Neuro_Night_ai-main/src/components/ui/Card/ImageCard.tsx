"use client";
import Image from "next/image";
import { useState } from "react";
import ShareModal from "../modal/ShareModal";
import { useAppSelector } from "@/redux/hooks";
import { RootState } from "@/redux/store";

export interface CardData {
  id: string;
  name: string;
  similarity: number;
  originalImageUrl?: string;
  watermark?: boolean;
  celebrityImageUrl?: string;
}

interface ImageCardProps {
  imageData: CardData;
}

const ImageCard: React.FC<ImageCardProps> = ({ imageData }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const imageUrl = imageData?.originalImageUrl || imageData?.celebrityImageUrl;
  const user = useAppSelector(
    (state: RootState) => state.auth.user || state.auth.access_token
  );

  return (
    <>
      <div className="flex flex-col items-center gap-4 p-4 rounded-xl shadow-md hover:shadow-lg transition-shadow">
        <Image
          src={imageUrl || "/placeholder-image.png"}
          alt={imageData?.name || "Preview image"}
          width={196}
          height={234}
          className="w-[196px] h-[234px] object-cover object-center rounded-lg"
        />

        <p className="text-white font-poppins text-xl font-normal leading-normal">
          Similarity: {Math.floor(imageData.similarity)}%
        </p>
        {user && (
          <button
            onClick={() => setIsModalOpen(true)}
            aria-label={`Download ${imageData?.name}`}
            className="text-white font-poppins text-[16px] font-normal leading-normal tracking-[-0.176px] flex h-[40px] px-[16px] justify-center items-center gap-[10px] rounded-[16px] bg-[rgba(0,255,255,0.6)] hover:bg-[rgba(0,255,255,0.8)] transition-colors"
          >
            Download
          </button>
        )}
      </div>

      <ShareModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        imageData={imageData}
      />
    </>
  );
};

export default ImageCard;
