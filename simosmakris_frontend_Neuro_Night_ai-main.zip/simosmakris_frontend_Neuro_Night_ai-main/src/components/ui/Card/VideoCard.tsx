"use client";
import { VideoData } from "@/components/pages/History/VideoContent";
import { useRef, useState, useEffect } from "react";
import VideoShareModal from "../modal/VideoShareModal";

interface VideoCardProps {
  videoData: VideoData;
}

const VideoCard: React.FC<VideoCardProps> = ({ videoData }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isVideoLoaded, setIsVideoLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Reset states when videoData changes
  useEffect(() => {
    setIsVideoLoaded(false);
    setHasError(false);
    setIsPlaying(false);
  }, [videoData.src]);

  const handlePlayVideo = async () => {
    if (!videoRef.current) return;

    try {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        // If video hasn't loaded yet, wait for it to load
        if (!isVideoLoaded) {
          videoRef.current.load();
          await new Promise((resolve) => {
            const onLoaded = () => {
              videoRef.current?.removeEventListener("loadeddata", onLoaded);
              resolve(true);
            };
            videoRef.current?.addEventListener("loadeddata", onLoaded);
          });
        }

        // Play the video
        await videoRef.current.play();
        setIsPlaying(true);
      }
    } catch (error) {
      console.error("Video play failed:", error);
      setIsPlaying(false);
      setHasError(true);
    }
  };

  const handleVideoPlay = () => {
    setIsPlaying(true);
  };

  const handleVideoPause = () => {
    setIsPlaying(false);
  };

  const handleVideoEnded = () => {
    setIsPlaying(false);
  };

  const handleVideoLoaded = () => {
    setIsVideoLoaded(true);
    setHasError(false);
    console.log("Video data loaded successfully");
  };

  const handleVideoError = (
    e: React.SyntheticEvent<HTMLVideoElement, Event>
  ) => {
    console.error("Video error:", e);
    setIsPlaying(false);
    setHasError(true);
    setIsVideoLoaded(false);
  };

  const handleVideoCanPlay = () => {
    console.log("Video can play");
    setIsVideoLoaded(true);
  };

  return (
    <>
      <div className="relative bg-gray-800 rounded-lg overflow-hidden shadow-lg max-w-sm mx-auto">
        {/* Video container */}
        <div className="relative aspect-video bg-gray-900">
          <video
            ref={videoRef}
            className="w-full h-full object-contain bg-gray-900"
            onEnded={handleVideoEnded}
            onPause={handleVideoPause}
            onPlay={handleVideoPlay}
            onError={handleVideoError}
            onLoadedData={handleVideoLoaded}
            onCanPlay={handleVideoCanPlay}
            preload="metadata"
            playsInline
            controls={false}
            crossOrigin="anonymous"
            muted // Important for autoplay in many browsers
          >
            <source src={videoData.src} type="video/mp4" />
            <source src={videoData.src} type="video/webm" />
            Your browser does not support the video tag.
          </video>

          {/* Error state */}
          {hasError && (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
              <div className="text-center text-white p-4">
                <div className="text-4xl mb-2">⚠️</div>
                <p className="text-sm">Failed to load video</p>
                <button
                  onClick={() => {
                    setHasError(false);
                    videoRef.current?.load();
                  }}
                  className="mt-2 text-cyan-400 hover:text-cyan-300 text-xs"
                >
                  Retry
                </button>
              </div>
            </div>
          )}

          {/* Loading state */}
          {!isVideoLoaded && !hasError && (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
              <div className="text-center text-white">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400 mx-auto mb-2"></div>
                <p className="text-xs">Loading video...</p>
              </div>
            </div>
          )}

          {/* Play button overlay - Only show when video is loaded and not playing */}
          {isVideoLoaded && !hasError && (
            <button
              onClick={handlePlayVideo}
              className={`absolute inset-0 flex items-center justify-center transition-all duration-300 ${
                isPlaying
                  ? "bg-black bg-opacity-0 hover:bg-opacity-20 opacity-0 hover:opacity-100"
                  : "bg-black bg-opacity-30 hover:bg-opacity-40"
              }`}
              aria-label={isPlaying ? "Pause video" : "Play video"}
            >
              <div
                className={`w-16 h-16 rounded-full bg-cyan-400 hover:bg-cyan-500 flex items-center justify-center transform hover:scale-110 transition-all duration-200 ${
                  isPlaying ? "opacity-0" : "opacity-100"
                }`}
              >
                {isPlaying ? (
                  <div className="flex gap-1">
                    <div className="w-2 h-6 bg-white rounded-sm"></div>
                    <div className="w-2 h-6 bg-white rounded-sm"></div>
                  </div>
                ) : (
                  <div className="w-0 h-0 border-l-[12px] border-l-white border-t-[8px] border-t-transparent border-b-[8px] border-b-transparent ml-1"></div>
                )}
              </div>
            </button>
          )}

          {/* Duration badge */}
          {videoData.duration && isVideoLoaded && !hasError && (
            <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
              {videoData.duration}
            </div>
          )}
        </div>

        {/* Download Morphing button */}
        <div className="p-4">
          <button
            onClick={() => setIsModalOpen(true)}
            className="w-full bg-cyan-400 hover:bg-cyan-500 text-white font-medium py-3 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center gap-2"
          >
            <span>📥</span>
            Download Morphing
          </button>
        </div>
      </div>

      <VideoShareModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        videoData={videoData}
      />
    </>
  );
};

export default VideoCard;
