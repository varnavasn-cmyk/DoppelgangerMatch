
interface StoryCardData {
  id: string | number;
  title: string;
  description: string;
  icon: React.ReactNode;
}

interface StoryCardProps {
  card: StoryCardData;
}

const StoryCard: React.FC<StoryCardProps> = ({ card }) => {
  const { title, description, icon } = card;

  return (
    <div className="lg:w-[382px] w-full py-4 shrink-0 rounded-[7px] px-4 border border-[rgba(1,218,226,0.3)] bg-[rgba(1,218,226,0.05)] [box-shadow:0_109px_80px_0_rgba(11,102,73,0.03),0_70.648px_46.852px_0_rgba(11,102,73,0.02),0_41.985px_25.481px_0_rgba(11,102,73,0.02),0_21.8px_13px_0_rgba(11,102,73,0.01),0_8.881px_6.519px_0_rgba(11,102,73,0.01),0_2.019px_3.148px_0_rgba(11,102,73,0.01)] hover:bg-[#02CCD8] transition-colors duration-300 group">
      <div className="flex flex-row justify-between items-center py-4">
        <h4 className="text-[#01DEE6] group-hover:text-black font-poppins text-[24px] font-bold leading-none transition-colors duration-300">
          {title}
        </h4>
        <div className="text-[#01DEE6] group-hover:text-white transition-colors duration-300">
          {icon}
        </div>
      </div>
      <p className="text-white group-hover:text-white font-poppins transition-colors duration-300">
        {description}
      </p>
    </div>
  );
};

export type { StoryCardData };
export default StoryCard;
