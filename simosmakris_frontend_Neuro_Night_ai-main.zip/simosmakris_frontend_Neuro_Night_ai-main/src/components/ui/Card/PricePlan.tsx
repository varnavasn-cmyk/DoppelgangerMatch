"use client";
import { Plan } from "@/components/shared/PlanPricing/PricingPlan";
import { usePrefixedPath } from "@/lib/localePath";
import { useGetMeUserQuery } from "@/redux/features/users/usersApi";
import { useAppSelector } from "@/redux/hooks";
import { RootState } from "@/redux/store";
import { useRouter } from "next/navigation";
import { FaCircleCheck } from "react-icons/fa6";
import Swal from "sweetalert2";

interface PricePlanProps {
  plan: Plan;
}

const PricePlan: React.FC<PricePlanProps> = ({ plan }) => {
  const router = useRouter();
  const user = useAppSelector(
    (state: RootState) => state?.auth?.user || state?.auth?.access_token
  );
  const { data: userData } = useGetMeUserQuery({});
  const getPrefixedPath = usePrefixedPath();
  const {
    planName: title,
    amount: price,
    features,
    description: disclaimer,
    planType,
    id,
  } = plan;

  const enableMorphing = userData?.data?.enableMorphing;

  return (
    <div
      onClick={() => {
        if (!user) {
          Swal.fire({
            icon: "info",
            title: "Login Required",
            text: "Please log in to purchase or view plans.",
            showConfirmButton: false,
            showCancelButton: true,
            cancelButtonText: "Login Page",
            allowOutsideClick: false,
            customClass: {
              cancelButton:
                "bg-[#6461FC] text-white px-4 py-2 rounded-md hover:bg-[#4E4BF1] focus:ring-2 focus:ring-indigo-300",
              popup: "rounded-2xl shadow-2xl p-6",
              title: "text-lg font-semibold text-gray-800",
              htmlContainer: "text-gray-600",
            },
            buttonsStyling: false,
          }).then((result) => {
            if (result.dismiss === Swal.DismissReason.cancel) {
              router.push(getPrefixedPath("/login"));
            }
          });
          return;
        }
        if (planType === "MORPHING" && enableMorphing === false) {
          Swal.fire({
            icon: "info",
            title: "Purchase Plan",
            text: "Purchase Celebrity or Lookalike Plan to continue",
            showConfirmButton: false,
            theme: "auto",
            allowOutsideClick: false,
            timer: 300,
          }).then((result) => {
            if (result.dismiss === Swal.DismissReason.cancel) {
              router.push(getPrefixedPath("/plan"));
            }
          });
          return;
        } else {
          router.push(getPrefixedPath(`/payment/${id}`));
        }
      }}
      className="flex flex-col justify-between w-[351px] h-[500px] px-[25px] py-[30px] rounded-[20px] border border-[#02CCD8] bg-[rgba(2,204,216,0.2)] hover:bg-[#02CCD8] transition-colors duration-300 group"
    >
      <div>
        <div className="flex flex-col justify-center items-center">
          <h3 className="text-white group-hover:text-black font-poppins text-[18px] font-semibold leading-none mb-5 transition-colors duration-300">
            {title}
          </h3>
          <h4 className="text-white group-hover:text-white font-poppins text-[72px] font-semibold leading-[90px] tracking-[-1.44px] flex items-start transition-colors duration-300">
            <span className="text-[30px] font-bold leading-[38px] mr-1 self-start">
              $
            </span>
            {price}
          </h4>
        </div>

        {features.map((feature: string, index: number) => (
          <div
            key={index}
            className="text-white group-hover:text-black font-poppins text-[16px] font-normal leading-none mt-4 flex items-center transition-colors duration-300"
          >
            <FaCircleCheck className="text-[#02CCD8] group-hover:text-white transition-colors duration-300" />
            <span className="ml-2">{feature}</span>
          </div>
        ))}
      </div>

      {disclaimer && (
        <p className="text-white group-hover:text-black text-center mt-4 font-poppins text-[16px] font-normal leading-none transition-colors duration-300">
          {disclaimer}
        </p>
      )}
    </div>
  );
};
export default PricePlan;
