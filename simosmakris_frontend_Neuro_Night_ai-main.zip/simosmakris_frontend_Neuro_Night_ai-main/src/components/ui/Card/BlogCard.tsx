"use client";
import { Blog } from "@/components/pages/home/Blog";
import Image from "next/image";
interface BlogCardProps {
  blog: Blog;
  onReadMore: () => void;
}
const BlogCard: React.FC<BlogCardProps> = ({ blog, onReadMore }) => {
  const { title, image } = blog;
  const buttonText = "Read More";
  return (
    <div className="flex flex-col">
      <Image
        src={image}
        width={270}
        height={260}
        alt={title}
        className="w-[270px] h-[260px] shrink-0 rounded-[10px] object-cover mb-4"
      />
      <h2 className="w-[270px] text-white font-poppins text-[24px] font-normal leading-[28.8px] mb-4">
        {title}
      </h2>
      <button
        onClick={onReadMore}
        className="text-[#02CCD8] font-poppins text-[16px] font-bold leading-none hover:text-[#01B8C4] transition-colors duration-200 self-start"
      >
        {buttonText}
      </button>
    </div>
  );
};
export default BlogCard;
