/* eslint-disable @typescript-eslint/no-unused-vars */
"use client";

import React, { useState, useRef } from "react";

// Types
interface VideoData {
  src: string;
  title: string;
  duration?: string;
  id: string;
}

interface VideoShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoData: VideoData;
}

// Video Share Modal Component
const VideoShareModal: React.FC<VideoShareModalProps> = ({
  isOpen,
  onClose,
  videoData,
}) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [isModalVideoPlaying, setIsModalVideoPlaying] = useState(false);
  const modalVideoRef = useRef<HTMLVideoElement>(null);

  const handleModalVideoPlay = async () => {
    if (modalVideoRef.current) {
      try {
        if (isModalVideoPlaying) {
          modalVideoRef.current.pause();
          setIsModalVideoPlaying(false);
        } else {
          // Ensure video is loaded
          if (modalVideoRef.current.readyState >= 2) {
            await modalVideoRef.current.play();
            setIsModalVideoPlaying(true);
          } else {
            // Wait for video to load
            modalVideoRef.current.addEventListener(
              "loadeddata",
              async () => {
                try {
                  await modalVideoRef.current!.play();
                  setIsModalVideoPlaying(true);
                } catch (error) {
                  console.error("Modal video play failed:", error);
                  setIsModalVideoPlaying(false);
                }
              },
              { once: true }
            );

            // Load the video
            modalVideoRef.current.load();
          }
        }
      } catch (error) {
        console.error("Modal video play failed:", error);
        setIsModalVideoPlaying(false);

        // Try to reload the video
        if (modalVideoRef.current) {
          modalVideoRef.current.load();
        }
      }
    }
  };

  // Video download function
  // const handleVideoDownload = async () => {
  //   try {
  //     setIsDownloading(true);

  //     // Fetch the video
  //     const response = await fetch(videoData.src);
  //     const blob = await response.blob();

  //     // Create download link
  //     const url = window.URL.createObjectURL(blob);
  //     const link = document.createElement("a");
  //     link.href = url;
  //     link.download = `${videoData.title
  //       .toLowerCase()
  //       .replace(/\s+/g, "-")}-morphing.mp4`;

  //     // Trigger download
  //     document.body.appendChild(link);
  //     link.click();
  //     document.body.removeChild(link);

  //     // Clean up
  //     window.URL.revokeObjectURL(url);
  //   } catch (error) {
  //     console.error("Video download failed:", error);
  //     alert("Video download failed. Please try again.");
  //   } finally {
  //     setIsDownloading(false);
  //   }
  // };

  const handleVideoDownload = async () => {
    if (typeof window === "undefined") return; // SSR safety
    if (!videoData?.src) {
      alert("No video URL found.");
      return;
    }

    try {
      setIsDownloading(true);

      // Fetch the video as blob
      const response = await fetch(videoData.src);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const blob = await response.blob();

      // Check for Safari (special handling)
      const isSafari =
        /Safari/.test(navigator.userAgent) &&
        !/Chrome/.test(navigator.userAgent);

      if (isSafari) {
        // Safari cannot download blob directly
        const objectUrl = URL.createObjectURL(blob);
        window.open(objectUrl, "_blank", "noopener,noreferrer");
        setTimeout(() => URL.revokeObjectURL(objectUrl), 15000);
        return;
      }

      // Normal download for other browsers
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      const safeTitle = (videoData.title || "video")
        .toLowerCase()
        .replace(/\s+/g, "-")
        .replace(/[^a-z0-9-_.]/g, "");
      link.href = url;
      link.download = `${safeTitle}-morphing.mp4`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Video download failed:", error);
      alert("Video download failed. Please try again.");
    } finally {
      setIsDownloading(false);
    }
  };

  // Share functions
  const shareToFacebook = () => {
    const url = encodeURIComponent(window.location.href);
    const text = encodeURIComponent(
      `Check out this amazing morphing video: ${videoData.title}!`
    );
    window.open(
      `https://www.facebook.com/sharer/sharer.php?u=${url}&quote=${text}`,
      "_blank"
    );
  };

  const shareToInstagram = () => {
    navigator.clipboard.writeText(
      `Check out this amazing morphing video: ${videoData.title}! ${window.location.href}`
    );
    alert("Link copied to clipboard! You can now paste it on Instagram.");
  };

  const shareToYouTube = () => {
    const url = encodeURIComponent(window.location.href);
    const text = encodeURIComponent(`${videoData.title} - Morphing Video`);
    window.open(
      `https://www.youtube.com/upload?title=${text}&description=Check out this morphing video!`,
      "_blank"
    );
  };

  const shareToSnapchat = () => {
    const url = encodeURIComponent(window.location.href);
    window.open(`https://www.snapchat.com/scan?attachmentUrl=${url}`, "_blank");
  };

  const shareToTikTok = () => {
    const url = encodeURIComponent(window.location.href);
    const text = encodeURIComponent(`${videoData.title} morphing!`);
    window.open(
      `https://www.tiktok.com/share?url=${url}&title=${text}`,
      "_blank"
    );
  };

  const shareGeneric = async () => {
    const shareData = {
      title: `${videoData.title} - Morphing Video`,
      text: `Check out this amazing morphing video: ${videoData.title}!`,
      url: window.location.href,
    };

    try {
      if (navigator.share && navigator.canShare(shareData)) {
        await navigator.share(shareData);
      } else {
        // Fallback: copy to clipboard
        await navigator.clipboard.writeText(
          `${shareData.text} ${shareData.url}`
        );
        alert("Link copied to clipboard!");
      }
    } catch (error) {
      console.error("Sharing failed:", error);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-6 w-full max-w-md mx-auto relative">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-2xl"
          aria-label="Close modal"
        >
          ×
        </button>

        {/* Video preview */}
        <div className="flex flex-col items-center mb-6">
          <div className="w-48 h-32 rounded-lg overflow-hidden mb-3 relative bg-gray-800">
            <video
              ref={modalVideoRef}
              className="w-full h-full object-cover"
              onEnded={() => setIsModalVideoPlaying(false)}
              onPause={() => setIsModalVideoPlaying(false)}
              onPlay={() => setIsModalVideoPlaying(true)}
              onError={(e) => {
                console.error("Modal video error:", e);
                setIsModalVideoPlaying(false);
              }}
              preload="metadata"
              playsInline
              controls={false}
              crossOrigin="anonymous"
            >
              <source src={videoData.src} type="video/mp4" />
              Your browser does not support the video tag.
            </video>

            {/* Play button overlay */}
            <button
              onClick={handleModalVideoPlay}
              className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30 hover:bg-opacity-40 transition-all duration-300"
              aria-label={isModalVideoPlaying ? "Pause video" : "Play video"}
            >
              <div className="w-12 h-12 rounded-full bg-cyan-400 hover:bg-cyan-500 flex items-center justify-center transform hover:scale-110 transition-transform">
                {isModalVideoPlaying ? (
                  <div className="flex gap-1">
                    <div className="w-1.5 h-4 bg-white"></div>
                    <div className="w-1.5 h-4 bg-white"></div>
                  </div>
                ) : (
                  <div className="w-0 h-0 border-l-[8px] border-l-white border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent ml-0.5"></div>
                )}
              </div>
            </button>
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-1">
            {videoData.title}
          </h3>
          {videoData.duration && (
            <p className="text-sm text-gray-600">
              Duration: {videoData.duration}
            </p>
          )}
        </div>

        {/* Share title */}
        <h2 className="text-xl font-semibold text-center text-gray-800 mb-6">
          Share
        </h2>

        {/* Social media buttons */}
        <div className="grid grid-cols-5 gap-4 mb-6">
          <button
            onClick={shareToFacebook}
            className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors"
            title="Share to Facebook"
          >
            <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mb-1">
              <span className="text-white font-bold text-sm">f</span>
            </div>
            <span className="text-xs text-gray-600">Facebook</span>
          </button>

          <button
            onClick={shareToInstagram}
            className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors"
            title="Share to Instagram"
          >
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center mb-1">
              <span className="text-white font-bold text-sm">📷</span>
            </div>
            <span className="text-xs text-gray-600">Instagram</span>
          </button>

          <button
            onClick={shareToYouTube}
            className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors"
            title="Share to YouTube"
          >
            <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mb-1">
              <span className="text-white font-bold text-sm">▶</span>
            </div>
            <span className="text-xs text-gray-600">YouTube</span>
          </button>

          <button
            onClick={shareToSnapchat}
            className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors"
            title="Share to Snapchat"
          >
            <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center mb-1">
              <span className="text-white font-bold text-sm">👻</span>
            </div>
            <span className="text-xs text-gray-600">Snapchat</span>
          </button>

          <button
            onClick={shareToTikTok}
            className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors"
            title="Share to TikTok"
          >
            <div className="w-12 h-12 bg-black rounded-full flex items-center justify-center mb-1">
              <span className="text-white font-bold text-sm">🎵</span>
            </div>
            <span className="text-xs text-gray-600">TikTok</span>
          </button>
        </div>

        {/* OR divider */}
        <div className="flex items-center mb-6">
          <div className="flex-1 h-px bg-gray-300"></div>
          <span className="px-3 text-gray-500 text-sm">OR</span>
          <div className="flex-1 h-px bg-gray-300"></div>
        </div>

        {/* Download button */}
        <button
          onClick={handleVideoDownload}
          disabled={isDownloading}
          className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-cyan-400 hover:bg-cyan-500 disabled:bg-cyan-300 text-white rounded-2xl font-medium transition-colors"
        >
          {isDownloading ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Downloading...
            </>
          ) : (
            <>
              <span>📥</span>
              Download Video
            </>
          )}
        </button>

        {/* Generic share button */}
        <button
          onClick={shareGeneric}
          className="w-full mt-3 py-2 text-gray-600 hover:text-gray-800 transition-colors"
        >
          More sharing options
        </button>
      </div>
    </div>
  );
};

export default VideoShareModal;
