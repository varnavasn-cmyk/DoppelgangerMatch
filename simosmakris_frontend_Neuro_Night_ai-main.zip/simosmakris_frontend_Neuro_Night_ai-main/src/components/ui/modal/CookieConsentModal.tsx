/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

declare global {
  interface Window {
    gtag?: (...args: any[]) => void;
  }
}

const GA_MEASUREMENT_ID = "G-XXXXXXX"; // <-- Replace with your GA4 ID

export function CookieConsentModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMounted, setIsMounted] = useState(false);

  // Initialize GA script
  const loadGAScript = () => {
    if (!window.gtag ) {
      const script = document.createElement("script");
      script.async = true;
      script.src = `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`;
      document.head.appendChild(script);

      const inlineScript = document.createElement("script");
      inlineScript.innerHTML = `
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        // Default consent = denied
        gtag('consent', 'default', {
          'analytics_storage': 'denied'
        });
        gtag('config', '${GA_MEASUREMENT_ID}', { send_page_view: false });
      `;
      document.head.appendChild(inlineScript);
    }
  };

  // Enable analytics after consent
  const enableAnalytics = () => {
    if (window.gtag) {
      window.gtag("consent", "update", { analytics_storage: "granted" });
      // Send initial pageview
      window.gtag("event", "page_view", {
        page_path: window.location.pathname,
      });
    }
  };

  useEffect(() => {
    setIsMounted(true);
    loadGAScript();

    // Generate anonymous ID for optional tracking
    if (!localStorage.getItem("anonUserId")) {
      localStorage.setItem("anonUserId", crypto.randomUUID());
    }

    // Check previous consent
    const cookieConsent = localStorage.getItem("cookieConsent");
    if (!cookieConsent) {
      setIsOpen(true);
    } else if (cookieConsent === "accepted") {
      enableAnalytics();
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem("cookieConsent", "accepted");
    setIsOpen(false);
    enableAnalytics();
  };

  const handleDecline = () => {
    localStorage.setItem("cookieConsent", "declined");
    setIsOpen(false);
    console.log("Cookies declined ❌");
  };

  if (!isMounted) return null;
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-4">
      {/* Modal Container */}
      <div className="w-full max-w-md rounded-lg bg-card shadow-lg">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border p-6">
          <h2 className="text-lg font-semibold text-foreground">
            Cookie Policy
          </h2>
          <button
            onClick={handleDecline}
            className="text-muted-foreground hover:text-foreground transition-colors"
            aria-label="Close modal"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          <p className="text-sm text-muted-foreground mb-4">
            We use cookies to enhance your browsing experience, serve
            personalized ads or content, and analyze our traffic. By clicking
            Accept All, you consent to our use of cookies.
          </p>
          <p className="text-xs text-muted-foreground">
            <a href="#" className="text-primary hover:underline">
              Learn more about our cookie policy
            </a>
          </p>
        </div>

        {/* Actions */}
        <div className="flex gap-3 border-t border-border p-6">
          <Button
            variant="outline"
            onClick={handleDecline}
            className="flex-1 bg-transparent"
          >
            Decline
          </Button>
          <Button onClick={handleAccept} className="flex-1">
            Accept All
          </Button>
        </div>
      </div>
    </div>
  );
}
