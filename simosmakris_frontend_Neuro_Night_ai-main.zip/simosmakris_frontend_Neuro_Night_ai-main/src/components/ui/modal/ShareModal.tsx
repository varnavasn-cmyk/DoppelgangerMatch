/* eslint-disable @typescript-eslint/no-unused-vars */
"use client";

import { useAppSelector } from "@/redux/hooks";
import { RootState } from "@/redux/store";
import { BsTwitterX } from "react-icons/bs";
import Image from "next/image";
import React, { useState } from "react";
import { FaFacebook, FaLink } from "react-icons/fa";
import {
  FacebookShareButton,
  TwitterShareButton,
  FacebookShareCount,
} from "react-share";
import { toast } from "sonner";
import { IoMdCloudDownload } from "react-icons/io";

interface ImageData {
  id: string;
  name: string;
  similarity: number;
  originalImageUrl?: string;
  celebrityImageUrl?: string;
  watermark?: boolean;
}

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageData: ImageData;
}

const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  imageData,
}) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const token = useAppSelector((state: RootState) => state.auth.access_token);

  // SSR-safe share URL
  const shareUrl = "https://doppelgangermatch.com/upload-photo";
  const shareTitle = `${imageData.name} - ${imageData.similarity}% Match`;
  const shareDescription = `Check out this ${imageData.similarity}% similarity match for ${imageData.name}! 🎯`;
  const hashtags = [
    "SimilarityMatch",
    "ImageMatch",
    imageData.name.replace(/\s+/g, ""),
  ];

  const imageUrl =
    imageData?.originalImageUrl || imageData?.celebrityImageUrl || "";
  const imageId = imageData?.id;
  const shareUrlAll = `${shareUrl}/${encodeURIComponent(imageId)}`;

  // -------------------------
  // Copy to Clipboard
  // -------------------------
  const copyToClipboard = async (text: string): Promise<boolean> => {
    if (typeof window === "undefined") return false;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
        return true;
      }
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.left = "-9999px";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      return true;
    } catch {
      return false;
    }
  };

  const copyImageUrl = async () => {
    const copied = await copyToClipboard(`${shareUrlAll}`);
    if (copied) toast.success("URL copied to clipboard!");
    else toast.error("❌ Failed to copy.");
  };

  // -------------------------
  // Download Image
  // -------------------------

  const handleDownload = async () => {
    if (typeof window === "undefined") return;

    try {
      if (!imageData?.id) {
        console.error("No image ID provided");
        return;
      }

      // Start download process
      setIsDownloading(true);
      setDownloadError(null);
      if (imageData?.originalImageUrl) {
        const res = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/uploads/download/match/${imageData.id}`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        if (!res.ok) {
          throw new Error(`Download failed: ${res.status} ${res.statusText}`);
        }

        // Convert to Blob
        const blob = await res.blob();

        // Ensure it's an image
        if (!blob.type.startsWith("image/")) {
          throw new Error("Downloaded file is not an image");
        }

        // Generate a safe filename
        const fileExtension = blob.type.split("/")[1] || "jpg";
        const safeName = (imageData.name || "image")
          .trim()
          .toLowerCase()
          .replace(/\s+/g, "-")
          .replace(/[^a-z0-9-_.]/g, "")
          .substring(0, 100);

        const similarityPart =
          typeof imageData.similarity !== "undefined"
            ? `-similarity-${imageData.similarity}`
            : "";

        const filename = `${safeName}${similarityPart}.${fileExtension}`;

        // Trigger the browser download
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = filename;
        a.style.display = "none";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);

        // Clean up memory
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      } else {
        const res = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/upload-celebrities/download/match/${imageData.id}`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        if (!res.ok) {
          throw new Error(`Download failed: ${res.status} ${res.statusText}`);
        }

        // Convert to Blob
        const blob = await res.blob();

        // Ensure it's an image
        if (!blob.type.startsWith("image/")) {
          throw new Error("Downloaded file is not an image");
        }

        // Generate a safe filename
        const fileExtension = blob.type.split("/")[1] || "jpg";
        const safeName = (imageData.name || "image")
          .trim()
          .toLowerCase()
          .replace(/\s+/g, "-")
          .replace(/[^a-z0-9-_.]/g, "")
          .substring(0, 100);

        const similarityPart =
          typeof imageData.similarity !== "undefined"
            ? `-similarity-${imageData.similarity}`
            : "";

        const filename = `${safeName}${similarityPart}.${fileExtension}`;

        // Trigger the browser download
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = filename;
        a.style.display = "none";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);

        // Clean up memory
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      }
    } catch (error) {
      console.error("Download failed:", error);
      setDownloadError(
        error instanceof Error ? error.message : "Failed to download image."
      );
    } finally {
      setIsDownloading(false);
    }
  };

  // -------------------------
  // Social share handlers (Instagram, TikTok, Snapchat)
  // -------------------------
  const shareToInstagram = () => {
    if (typeof window === "undefined") return;
    window.open("https://www.instagram.com/", "_blank", "noopener,noreferrer");
    alert(
      "Instagram: Upload the downloaded image manually and add your caption."
    );
  };

  const shareToTikTok = () => {
    if (typeof window === "undefined") return;
    window.open(
      "https://www.tiktok.com/upload",
      "_blank",
      "noopener,noreferrer"
    );
  };

  const shareToSnapchat = () => {
    if (typeof window === "undefined") return;
    const url = `https://www.snapchat.com/share?link=${encodeURIComponent(
      shareUrlAll
    )}`;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  // -------------------------
  // Backdrop click handler
  // -------------------------
  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) onClose();
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4"
      onClick={handleBackdropClick}
    >
      <div className="bg-white rounded-2xl p-6 w-full max-w-md mx-auto relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-2xl z-10"
          aria-label="Close modal"
        >
          ×
        </button>

        <div className="flex flex-col items-center mb-6">
          <div className="w-24 h-24 rounded-lg overflow-hidden mb-3 relative">
            <Image
              src={imageUrl}
              alt={imageData.name}
              width={96}
              height={96}
              className="w-full h-full object-cover"
            />
          </div>
          <p className="text-sm text-gray-600">
            Similarity: {Math.floor(imageData.similarity)}%
          </p>
        </div>

        <h2 className="text-xl font-semibold text-center  text-gray-800 mb-6">
          Share
        </h2>

        <div className="grid grid-cols-5 gap-3 mb-4">
          <div className="flex flex-col items-center">
            <FacebookShareButton
              url={shareUrlAll}
              hashtag={`#${hashtags[0]} #${shareUrlAll}`}
              className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <button className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <div className="mb-2">
                  <FaFacebook size={36} className="text-blue-600 mb-2" />
                </div>
                <span className="text-xs font-semibold text-gray-600">
                  Facebook
                </span>
              </button>
            </FacebookShareButton>
            <FacebookShareCount url={shareUrlAll}>
              {(shareCount) => (
                <span className="text-[10px] text-gray-500 mt-1">
                  {shareCount > 0 ? `${shareCount} shares` : ""}
                </span>
              )}
            </FacebookShareCount>
          </div>

          <button
            onClick={shareToInstagram}
            className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors"
            title="Share to Instagram"
            type="button"
          >
            <Image
              src="/Instagram.png"
              alt="Instagram"
              width={24}
              height={24}
              className="object-center w-10 h-10 rounded-full mb-2"
            />

            <span className="text-xs font-semibold text-gray-600 mt-1">
              Instagram
            </span>
          </button>

          <div className="flex flex-col items-center">
            <TwitterShareButton
              url={shareUrlAll}
              title={shareDescription}
              hashtags={hashtags}
              className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <button className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <div className="w-10 h-10 bg-black rounded-full mb-2 flex items-center justify-center">
                  <BsTwitterX size={20} className="text-white " />
                </div>
                <span className="text-xs font-semibold text-gray-600 my-1">
                  X
                </span>
              </button>
            </TwitterShareButton>
          </div>

          <button
            onClick={shareToTikTok}
            className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors"
            title="Share to TikTok"
            type="button"
          >
            <Image
              src="/tiktok.png"
              alt="TikTok"
              width={24}
              height={24}
              className="object-center w-10 h-10 rounded-full mb-3"
            />
            <span className="text-xs font-semibold text-gray-600">TikTok</span>
          </button>

          <button
            onClick={shareToSnapchat}
            className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg transition-colors"
            title="Share to Snapchat"
            type="button"
          >
            <Image
              src="/snapchat.png"
              alt="Snapchat"
              width={24}
              height={24}
              className="object-center w-10 h-10 rounded-full mb-2"
            />
            <span className="text-xs font-semibold text-gray-600 mt-1">
              Snapchat
            </span>
          </button>
        </div>

        <div className="flex items-center mb-6">
          <div className="flex-1 h-px bg-gray-300"></div>
          <span className="px-3 font-medium text-gray-500 text-sm">OR</span>
          <div className="flex-1 h-px bg-gray-300"></div>
        </div>

        {downloadError && (
          <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg text-sm text-yellow-800">
            {downloadError}
          </div>
        )}

        <button
          onClick={handleDownload}
          disabled={isDownloading}
          className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-cyan-400 hover:bg-cyan-500 disabled:bg-cyan-300 text-white rounded-2xl font-medium transition-colors disabled:cursor-not-allowed mb-3"
        >
          {isDownloading ? (
            <div className="w-4 h-4 border-2 border-white font-semibold border-t-transparent rounded-full animate-spin"></div>
          ) : (
            <>
              <IoMdCloudDownload size={24} />
              Download Image
            </>
          )}
        </button>

        <button
          onClick={copyImageUrl}
          className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-2xl font-medium transition-colors mb-3"
        >
          <FaLink size={20} />
          Copy Image URL & Page Link
        </button>
      </div>
    </div>
  );
};

export default ShareModal;
