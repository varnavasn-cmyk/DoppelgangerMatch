//! Auth Paths
export const loginPath = () => `/login`;
export const signupPath = () => `/signup`;
export const forgotPasswordPath = () => `/forgot-password`;
export const newPasswordPath = () => `/new-password`;

export const unauthorizedPath = () => `/unauthorized`;

//! Dashboard Paths
const DASHBOARD_PREFIX = "/dashboard";

export const superAdminDashboardPath = () => `${DASHBOARD_PREFIX}/super-admin`;

export const adminDashboardPath = () => `${DASHBOARD_PREFIX}/admin`;
export const adminDashboardDatabasePath = () =>
  `${DASHBOARD_PREFIX}/admin/database`;
export const adminDashboardCreateBlogPath = () =>
  `${DASHBOARD_PREFIX}/admin/create-blog`;
export const adminDashboardAllBlogsPath = () =>
  `${DASHBOARD_PREFIX}/admin/all-blogs`;
export const adminDashboardAllSubscribersPath = () =>
  `${DASHBOARD_PREFIX}/admin/all-subscribers`;
export const adminDashboardPlanUpdatePath = () =>
  `${DASHBOARD_PREFIX}/admin/plan-update`;

export const userDashboardPrefix = () => `${DASHBOARD_PREFIX}/user`;
