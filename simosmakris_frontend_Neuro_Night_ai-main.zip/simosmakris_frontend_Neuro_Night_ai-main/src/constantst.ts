export const LOCALE = ["en", "fr", "es"];
