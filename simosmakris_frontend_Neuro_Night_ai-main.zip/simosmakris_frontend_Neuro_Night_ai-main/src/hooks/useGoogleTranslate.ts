// "use client";

// import { useEffect } from "react";
// import { usePathname } from "next/navigation";
// import { useLocale } from "next-intl";

// const LOCALES = {
//   en: "EN",
//   fr: "FR",
//   es: "ES",
// } as const;

// type Locale = keyof typeof LOCALES;

// declare global {
//   interface Window {
//     google?: {
//       translate: {
//         TranslateElement: new (
//           config: {
//             pageLanguage: string;
//             includedLanguages: string;
//             layout?: number;
//             autoDisplay?: boolean;
//             multilanguagePage?: boolean;
//           },
//           elementId: string
//         ) => void;
//         InlineLayout?: {
//           SIMPLE: number;
//           HORIZONTAL: number;
//           VERTICAL: number;
//         };
//       };
//     };
//     googleTranslateElementInit?: () => void;
//     googleTranslateLoaded?: boolean;
//   }
// }

// export function useGoogleTranslate() {
//   // return;
//   const pathname = usePathname();
//   const locale = useLocale();

//   // ---- 1️⃣ Load Google Translate script once ----
//   useEffect(() => {
//     if (window.googleTranslateLoaded) return;

//     window.googleTranslateElementInit = () => {
//       try {
//         new window.google!.translate.TranslateElement(
//           {
//             pageLanguage: "en",
//             includedLanguages: "en,fr,es,bn",
//             layout: window.google?.translate?.InlineLayout?.SIMPLE,
//             autoDisplay: false,
//             multilanguagePage: true,
//           },
//           "google_translate_element"
//         );
//         window.googleTranslateLoaded = true;
//         console.log("✅ Google Translate initialized");
//       } catch (err) {
//         console.error("Google Translate init error:", err);
//       }
//     };

//     const script = document.createElement("script");
//     script.src =
//       "//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
//     script.async = true;
//     document.body.appendChild(script);

//     const style = document.createElement("style");
//     style.innerHTML = `
//       .goog-te-banner-frame,
//       .goog-te-gadget-icon,
//       .goog-te-menu-frame,
//       .goog-te-balloon-frame,
//       .goog-te-combo,
//       .skiptranslate,
//       iframe.skiptranslate {
//         display: none !important;
//         visibility: hidden !important;
//       }
//       body { top: 0 !important; }
//       [class^="VIpgJd-ZVi9od"] {
//         display: none !important;
//         opacity: 0 !important;
//         visibility: hidden !important;
//       }
//     `;
//     document.head.appendChild(style);

//     return () => {
//       // script.remove();
//       // style.remove();
//     };
//   }, []);

//   // ---- 2️⃣ Re-apply translation immediately when locale changes ----
//   // useEffect(() => {
//   //   const validLocales = Object.keys(LOCALES) as Locale[];
//   //   const detectedLocale = validLocales.includes(locale as Locale)
//   //     ? (locale as Locale)
//   //     : "en";

//   //   // Update googtrans cookie
//   //   const cookieValue = detectedLocale === "en" ? "" : `/${detectedLocale}`;
//   //   document.cookie = `googtrans=${cookieValue}; path=/; secure; samesite=strict; max-age=31536000`;

//   //   // Apply translation instantly (no reload)
//   //   const applyTranslation = () => {
//   //     const select =
//   //       document.querySelector<HTMLSelectElement>(".goog-te-combo");
//   //     if (select) {
//   //       select.value = detectedLocale;
//   //       // Dispatch change event to trigger translation instantly
//   //       select.dispatchEvent(new Event("change"));
//   //       console.log("🌍 Applied translation instantly:", detectedLocale);
//   //     } else {
//   //       console.warn("⚠️ Google Translate selector not ready yet.");
//   //     }
//   //   };

//   //   // Wait for Google to load, then apply
//   //   const timeout = setTimeout(() => {
//   //     if (window.googleTranslateLoaded) {
//   //       applyTranslation();
//   //     } else {
//   //       // Wait a bit longer if not yet loaded
//   //       const retry = setInterval(() => {
//   //         if (window.googleTranslateLoaded) {
//   //           applyTranslation();
//   //           clearInterval(retry);
//   //         }
//   //       }, 4000);
//   //     }
//   //   }, 1000);

//   //   return () => clearTimeout(timeout);
//   // }, [locale, pathname]);

//   useEffect(() => {
//     const validLocales = Object.keys(LOCALES) as Locale[];
//     const detectedLocale = validLocales.includes(locale as Locale)
//       ? (locale as Locale)
//       : "en";

//     // ---- Update Google Translate cookie ----
//     const cookieValue = detectedLocale === "en" ? "" : `/${detectedLocale}`;
//     document.cookie = `googtrans=${cookieValue}; path=/; secure; samesite=strict; max-age=31536000`;

//     // ---- Reliable translation re-apply logic ----
//     let attempts = 0;
//     const maxAttempts = 30; // more retries for slower VPS

//     const tryApplyTranslation = () => {
//       const select =
//         document.querySelector<HTMLSelectElement>(".goog-te-combo");

//       if (select) {
//         select.value = detectedLocale;
//         select.dispatchEvent(new Event("change"));
//         console.log("🌍 Translation applied instantly:", detectedLocale);
//         return; // success → stop retrying
//       }

//       // Retry logic if not ready
//       if (attempts < maxAttempts) {
//         attempts++;
//         setTimeout(tryApplyTranslation, 500); // retry every 500ms
//       } else {
//         console.warn("⚠️ Google Translate selector not found after retries.");
//       }
//     };

//     // --- Ensure Google Translate script is ready ---
//     const waitForGoogle = setInterval(() => {
//       if (window.google && (window as any).google.translate) {
//         clearInterval(waitForGoogle);
//         tryApplyTranslation();
//       }
//     }, 1000);

//     // Cleanup
//     return () => clearInterval(waitForGoogle);
//   }, [locale]);
// }

"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import { useLocale } from "next-intl";

const LOCALES = {
  en: "EN",
  fr: "FR",
  es: "ES",
} as const;

type Locale = keyof typeof LOCALES;

export function useGoogleTranslate() {
  const pathname = usePathname();
  const locale = useLocale();

  useEffect(() => {
    const validLocales = Object.keys(LOCALES) as Locale[];
    const detectedLocale = validLocales.includes(locale as Locale)
      ? (locale as Locale)
      : "en";

    console.log("🌍 useGoogleTranslate - Detected locale:", detectedLocale);

    // Update Google Translate cookie with correct format
    const cookieValue = detectedLocale === "en" ? "" : `/en/${detectedLocale}`;
    document.cookie = `googtrans=${cookieValue}; path=/; max-age=31536000; samesite=lax`;

    console.log("🍪 Set googtrans cookie:", cookieValue);

    // Function to apply translation
    const applyTranslation = () => {
      const select =
        document.querySelector<HTMLSelectElement>(".goog-te-combo");

      if (select) {
        // Check if value needs to be changed
        if (select.value !== detectedLocale) {
          select.value = detectedLocale;
          select.dispatchEvent(new Event("change"));
          console.log("✅ Applied Google Translate:", detectedLocale);
        } else {
          console.log("ℹ️ Translation already applied:", detectedLocale);
        }
        return true;
      }
      return false;
    };

    // Retry mechanism with exponential backoff
    let attempts = 0;
    const maxAttempts = 20;
    const baseDelay = 300;

    const tryApplyTranslation = () => {
      if (applyTranslation()) {
        return; // Success
      }

      if (attempts < maxAttempts) {
        attempts++;
        const delay = baseDelay * Math.min(attempts, 5); // Cap at 5x base delay
        console.log(`⏳ Retry ${attempts}/${maxAttempts} in ${delay}ms...`);
        setTimeout(tryApplyTranslation, delay);
      } else {
        console.warn(
          "⚠️ Google Translate selector not found after max attempts"
        );
        console.warn("Check if Google Translate script loaded successfully");
      }
    };

    // Wait for Google Translate to be ready
    const waitForGoogle = () => {
      if (window.google?.translate?.TranslateElement) {
        console.log("✅ Google Translate API ready");
        // Wait a bit more for DOM to be ready
        setTimeout(tryApplyTranslation, 500);
      } else {
        console.log("⏳ Waiting for Google Translate API...");
        setTimeout(waitForGoogle, 500);
      }
    };

    // Start the process
    setTimeout(waitForGoogle, 300);
  }, [locale, pathname]);
}
