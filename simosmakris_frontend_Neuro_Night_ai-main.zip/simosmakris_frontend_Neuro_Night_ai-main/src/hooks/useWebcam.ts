/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
// hooks/useSimpleWebcam.ts
import { useRef, useState, useCallback } from "react";
import { WebcamProps } from "react-webcam";

interface UseSimpleWebcamReturn {
  webcamRef: React.RefObject<any>;
  capturedImage: string | null;
  isReady: boolean;
  error: string | null;
  devices: MediaDeviceInfo[];
  currentDeviceId: string;
  captureImage: () => void;
  retakeImage: () => void;
  switchCamera: () => void;
  handleUserMedia: () => void;
  handleUserMediaError: (error: any) => void;
  videoConstraints: any;
}

export const useSimpleWebcam = (): UseSimpleWebcamReturn => {
  const webcamRef = useRef<any>(null);

  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [currentDeviceId, setCurrentDeviceId] = useState<string>("");

  console.log(capturedImage ? "📷 Image captured" : "🎥 Webcam ready");

  // Simple capture function
  const captureImage = useCallback(() => {
    if (webcamRef.current) {
      try {
        const imageSrc = webcamRef.current.getScreenshot();
        if (imageSrc) {
          setCapturedImage(imageSrc);
          console.log("📸 Image captured successfully");
        } else {
          setError("Failed to capture image - webcam not ready");
        }
      } catch (err) {
        console.error("Capture error:", err);
        setError("Failed to capture image");
      }
    } else {
      setError("Webcam reference not available");
    }
  }, []);

  // Retake function
  const retakeImage = useCallback(() => {
    setCapturedImage(null);
    setError(null);
    setIsReady(false);
  }, []);

  // Handle successful camera access
  const handleUserMedia = useCallback(() => {
    console.log("✅ Camera started successfully");
    setIsReady(true);
    setError(null);

    // Get available devices after camera starts
    if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
      navigator.mediaDevices
        .enumerateDevices()
        .then((devices) => {
          const videoDevices = devices.filter(
            (device) => device.kind === "videoinput"
          );
          setDevices(videoDevices);
          console.log("📹 Available cameras:", videoDevices.length);
        })
        .catch((err) => console.log("Device enumeration error:", err));
    }
  }, []);

  // Handle camera errors
  const handleUserMediaError = useCallback((error: any) => {
    console.error("❌ Camera error:", error);
    setIsReady(false);

    let errorMessage = "Camera access failed";

    if (error?.name === "NotAllowedError") {
      errorMessage =
        'Camera permission denied. Please click "Allow" when prompted.';
    } else if (error?.name === "NotFoundError") {
      errorMessage = "No camera found on this device.";
    } else if (error?.name === "NotReadableError") {
      errorMessage =
        "Camera is being used by another app. Please close other camera apps.";
    } else if (error?.message) {
      errorMessage = error.message;
    }

    setError(errorMessage);
  }, []);

  // Switch camera function
  const switchCamera = useCallback(() => {
    if (devices.length > 1) {
      const currentIndex = devices.findIndex(
        (device) => device.deviceId === currentDeviceId
      );
      const nextIndex = (currentIndex + 1) % devices.length;
      setCurrentDeviceId(devices[nextIndex].deviceId);
      console.log("🔄 Switching to camera:", devices[nextIndex].label);
    }
  }, [devices, currentDeviceId]);

  // Video constraints - keep it simple
  const videoConstraints = {
    width: 1280,
    height: 720,
    facingMode: currentDeviceId ? undefined : "user",
    deviceId: currentDeviceId || undefined,
  };

  return {
    webcamRef,
    capturedImage,
    isReady,
    error,
    devices,
    currentDeviceId,
    captureImage,
    retakeImage,
    switchCamera,
    handleUserMedia,
    handleUserMediaError,
    videoConstraints,
  };
};
