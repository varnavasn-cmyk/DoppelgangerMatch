import * as paths from "./paths";

export const SUPER_ADMIN_ROLE = "SUPER_ADMIN";
export const ADMIN_ROLE = "ADMIN";
export const USER_ROLE = "USER";

export const adminPaths = {
  // super_admin: paths.superAdminDashboardPath(),
  admin: paths.adminDashboardPath(),
  // user: paths.userDashboardPrefix(),
};