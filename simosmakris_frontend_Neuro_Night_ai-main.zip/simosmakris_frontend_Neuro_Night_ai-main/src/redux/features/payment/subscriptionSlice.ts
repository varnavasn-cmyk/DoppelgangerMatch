
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { RootState } from "../../store";

// ------------------
// 🔹 Types
// ------------------
export type TSubscription = {
  id: string;
  userId: string;
  planId: string;
  purchaseDate: string;
  amount: number;
  status?: string; // optional field if backend sends it
};

export type TSubscriptionState = {
  clientSecret: string | null;
  paymentIntentId: string | null;
  subscription: TSubscription | null;
};

// ------------------
// 🔹 Initial State
// ------------------
const initialState: TSubscriptionState = {
  clientSecret: null,
  paymentIntentId: null,
  subscription: null,
};

// ------------------
// 🔹 Slice
// ------------------
const subscriptionSlice = createSlice({
  name: "subscription",
  initialState,
  reducers: {
    // ✅ Set subscription data after successful subscription creation
    setSubscriptionData: (
      state,
      action: PayloadAction<{
        clientSecret: string;
        paymentIntentId: string;
        subscription: TSubscription;
      }>
    ) => {
      const { clientSecret, paymentIntentId, subscription } = action.payload;
      state.clientSecret = clientSecret;
      state.paymentIntentId = paymentIntentId;
      state.subscription = subscription;
    },

    // ✅ Clear subscription state (e.g., after logout or payment success)
    clearSubscriptionData: (state) => {
      state.clientSecret = null;
      state.paymentIntentId = null;
      state.subscription = null;
    },
  },
});

// ------------------
// 🔹 Exports
// ------------------
export const { setSubscriptionData, clearSubscriptionData } =
  subscriptionSlice.actions;

export default subscriptionSlice.reducer;

// ------------------
// 🔹 Selectors
// ------------------
export const selectClientSecret = (state: RootState) =>
  (state.subscription as TSubscriptionState).clientSecret;

export const selectPaymentIntentId = (state: RootState) =>
  (state.subscription as TSubscriptionState).paymentIntentId;

export const selectSubscription = (state: RootState) =>
  (state.subscription as TSubscriptionState).subscription;
