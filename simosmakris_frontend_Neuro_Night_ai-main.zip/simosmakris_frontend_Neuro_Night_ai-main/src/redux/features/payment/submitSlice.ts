import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { RootState } from "../../store";

export interface SubmitPayload {
  id: string;
  user_image_key: string;
  celebrity_image_key: string;
  bucket: string;
}

export interface SubmitState {
  data: SubmitPayload | null;
  hasBeenTriggered: boolean;
}

const initialState: SubmitState = {
  data: null,
  hasBeenTriggered: false,
};

const submitSlice = createSlice({
  name: "submit",
  initialState,
  reducers: {
    triggerSubmit: (state, action: PayloadAction<SubmitPayload>) => {
      // ✅ Only work if NEVER triggered before
      if (!state.hasBeenTriggered) {
        state.data = action.payload;
        state.hasBeenTriggered = true; // 🔒 Lock it permanently
        console.log("✅ triggerSubmit: SUCCESS (first call)");
      } else {
        console.log("⛔ triggerSubmit: BLOCKED (already triggered once)");
      }
    },
    resetSubmit: (state) => {
      // ✅ Clear data but keep the trigger lock
      state.data = null;
      state.hasBeenTriggered = false;
      // hasBeenTriggered stays true forever
    },
  },
});

export const { triggerSubmit, resetSubmit } = submitSlice.actions;
export const selectSubmitData = (state: RootState) => state.submit.data;
export const selectHasBeenTriggered = (state: RootState) =>
  state.submit.hasBeenTriggered;
export default submitSlice.reducer;
