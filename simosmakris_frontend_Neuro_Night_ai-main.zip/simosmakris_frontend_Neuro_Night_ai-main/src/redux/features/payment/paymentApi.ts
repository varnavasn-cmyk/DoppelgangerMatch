
import { baseApi } from "../../api/baseApi";

const exampleApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    createPayPalPayment: builder.mutation({
      query: (data) => {
        return {
          url: "/subscriptions/paypal/create-subscription",
          method: "POST",
          body: data,
        };
      },
      invalidatesTags: ["payment"],
    }),
    executePayPalPayment: builder.mutation({
      query: (data) => {
        return {
          url: "/subscriptions/paypal/capture-payment",
          method: "POST",
          body: data,
        };
      },
      invalidatesTags: ["payment"],
    }),
    createStripePayment: builder.mutation({
      query: (data) => {
        return {
          url: "/subscriptions/create-subscription",
          method: "POST",
          body: data,
        };
      },
      invalidatesTags: ["payment",],
    }),
    executeStripePayment: builder.mutation({
      query: (data) => {
        return {
          url: "/subscriptions/stripe/capture-payment",
          method: "POST",
          body: data,
        };
      },
      invalidatesTags: ["payment"],
    }),
    createRazorpayPayment: builder.mutation({
      query: (data) => {
        return {
          url: "/subscriptions/razorpay/create-subscription",
          method: "POST",
          body: data,
        };
      },
      invalidatesTags: ["payment"],
    }),
  }),
});

export const {
  useCreatePayPalPaymentMutation,
  useExecutePayPalPaymentMutation,
  useCreateStripePaymentMutation,
} = exampleApi;
