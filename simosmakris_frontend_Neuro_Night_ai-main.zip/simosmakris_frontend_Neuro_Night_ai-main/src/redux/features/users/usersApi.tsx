import { baseApi } from "../../api/baseApi";

const usersApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    // get plans
    getPlans: builder.query({
      query: () => ({
        url: "/plans",
        method: "GET",
      }),
      providesTags: ["user"],
    }),
    //getAll Blogs
    getAllBlogs: builder.query({
      query: () => ({
        url: "/blogs",
        method: "GET",
      }),
      providesTags: ["user"],
    }),
    //get single blog by id
    getBlogById: builder.query({
      query: (id) => ({
        url: `/blogs/${id}`,
        method: "GET",
      }),
      providesTags: ["user"],
    }),

    // get me user
    getMeUser: builder.query({
      query: () => ({
        url: "/auth/me",
        method: "GET",
      }),
      providesTags: ["user", "payment"],
    }),
    // update user profile
    updateUserProfile: builder.mutation({
      query: (data) => ({
        url: "/users/update-profile",
        method: "PATCH",
        body: data,
      }),
      invalidatesTags: ["user"],
    }),
    // free upload look alike image
    freeUploadLookAlikeImage: builder.mutation({
      query: (formData: FormData) => ({
        url: "/uploads/normal-upload",
        method: "POST",
        body: formData,
      }),
    }),

    // upload look alike image
    uploadLookAlikeImage: builder.mutation({
      query: (formData: FormData) => ({
        url: "/uploads",
        method: "POST",
        body: formData,
      }),
      invalidatesTags: ["user"],
    }),

    // upload look a celebrities image
    uploadLookACelebritiesImage: builder.mutation({
      query: (formData: FormData) => ({
        url: "/upload-celebrities/celebrity-match",
        method: "POST",
        body: formData,
      }),
      invalidatesTags: ["user"],
    }),

    // upload make Morphing Video image
    uploadMakeMorphingVideo: builder.mutation({
      query: (data) => ({
        url: `/morph-video/create-morph-video/${data?.id}`,
        method: "POST",
        body: data?.formData,
      }),
      invalidatesTags: ["user"],
    }),

    // get user history
    getUserHistoryLookLike: builder.query({
      query: (data) => ({
        url: "/uploads/my-uploads",
        method: "GET",
        params: data,
      }),
      providesTags: ["user"],
    }),

    getUserHistoryLookACelebrities: builder.query({
      query: (data) => ({
        url: "/upload-celebrities/my-uploads",
        method: "GET",
        params: data,
      }),
      providesTags: ["user"],
    }),

    getUserHistoryMorphvideo: builder.query({
      query: (data) => ({
        url: "/morph-video/my-morph-video",
        method: "GET",
        params: data,
      }),
      providesTags: ["user"],
    }),

    getUserHistoryCount: builder.query({
      query: () => ({
        url: "/users/user-history/me",
        method: "GET",
      }),
      providesTags: ["user", "payment"],
    }),

    getSingleShare: builder.query({
      query: (id) => ({
        url: `/uploads/get-single-image/${id}`,
        method: "GET",
      }),
      providesTags: ["user"],
    }),

    getShareVideoById: builder.query({
      query: (id) => ({
        url: `/morph-video/${id}`,
        method: "GET",
      }),
      providesTags: ["user"],
    }),

    getDownloadNormalImage: builder.query({
      query: (id) => ({
        url: `/upload-celebrities/download/match/${id}`,
        method: "GET",
      }),
      providesTags: ["user"],
    }),

    getDowloadCelebrityImage: builder.query({
      query: (id) => ({
        url: `/upload-celebrities/download-image/${id}`,
        method: "GET",
      }),
      providesTags: ["user"],
    }),
  }),
});

export const {
  useGetPlansQuery,
  useGetAllBlogsQuery,
  useGetBlogByIdQuery,
  useGetUserHistoryLookLikeQuery,
  useGetMeUserQuery,
  useUploadLookAlikeImageMutation,
  useFreeUploadLookAlikeImageMutation,
  useUpdateUserProfileMutation,
  useGetUserHistoryLookACelebritiesQuery,
  useUploadLookACelebritiesImageMutation,
  useUploadMakeMorphingVideoMutation,
  useGetSingleShareQuery,
  useGetShareVideoByIdQuery,
  useGetUserHistoryCountQuery,
  useGetUserHistoryMorphvideoQuery,
  useGetDownloadNormalImageQuery,
} = usersApi;
