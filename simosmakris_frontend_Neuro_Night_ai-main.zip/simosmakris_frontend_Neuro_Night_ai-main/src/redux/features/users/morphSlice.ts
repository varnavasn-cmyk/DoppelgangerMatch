import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { RootState } from "../../store";

// ------------------
// 🔹 Types
// ------------------
export type TMorphCredentials = {
  id: string | null; // ✅ Added ID field
  celebrity_image_key: string | null;
  normal_name: string | null;
  user_image_key: string | null;
  bucket: string | null;
};

export type TMorphState = {
  morphCredentials: TMorphCredentials | null;
};

// ------------------
// 🔹 Initial State
// ------------------
const initialState: TMorphState = {
  morphCredentials: null,
};

// ------------------
// 🔹 Slice
// ------------------
const morphSlice = createSlice({
  name: "morph",
  initialState,
  reducers: {
    // ✅ Set morph credentials
    setMorphCredentials: (state, action: PayloadAction<TMorphCredentials>) => {
      state.morphCredentials = action.payload;
    },

    // ✅ Clear morph credentials
    clearMorphCredentials: (state) => {
      state.morphCredentials = null;
    },
  },
});

// ------------------
// 🔹 Exports
// ------------------
export const { setMorphCredentials, clearMorphCredentials } =
  morphSlice.actions;

export default morphSlice.reducer;

// ------------------
// 🔹 Selectors
// ------------------
export const selectMorphCredentials = (state: RootState) =>
  (state.morph as TMorphState).morphCredentials;
