/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */

import { configureStore } from "@reduxjs/toolkit";
import createWebStorage from "redux-persist/lib/storage/createWebStorage";
import {
  persistReducer,
  persistStore,
  FLUSH,
  PAUSE,
  PERSIST,
  PURGE,
  REGISTER,
  REHYDRATE,
} from "redux-persist";
import authReducer from "./features/auth/authSlice";
import morphReducer from "./features/users/morphSlice";
import submitReducer from "./features/payment/submitSlice";
import subscriptionReducer from "./features/payment/subscriptionSlice";
import { baseApi } from "./api/baseApi";

// ✅ Fix SSR localStorage (for Next.js)
const createNoopStorage = () => {
  return {
    getItem(_key: string): Promise<null> {
      return Promise.resolve(null);
    },
    setItem(_key: string, value: any): Promise<any> {
      return Promise.resolve(value);
    },
    removeItem(_key: string): Promise<void> {
      return Promise.resolve();
    },
  };
};

const storage =
  typeof window !== "undefined"
    ? createWebStorage("local")
    : createNoopStorage();

// ✅ Persist config for auth
const persistAuthConfig = {
  key: "auth",
  storage,
};

// ✅ Persist config for morph
const persistMorphConfig = {
  key: "morph",
  storage,
};

// ✅ Wrap reducers
const persistedAuthReducer = persistReducer(persistAuthConfig, authReducer);
const persistedMorphReducer = persistReducer(persistMorphConfig, morphReducer);

export const makeStore = () => {
  return configureStore({
    reducer: {
      [baseApi.reducerPath]: baseApi.reducer,
      auth: persistedAuthReducer,
      morph: persistedMorphReducer, // ✅ now persisted
      subscription: subscriptionReducer,
      submit: submitReducer,
    },
    middleware: (getDefaultMiddlewares) =>
      getDefaultMiddlewares({
        serializableCheck: {
          ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
        },
      }).concat(baseApi.middleware),
  });
};

export const store = makeStore();
export const persistor = persistStore(store);

// ✅ Types
export type AppStore = ReturnType<typeof makeStore>;
export type RootState = ReturnType<AppStore["getState"]>;
export type AppDispatch = AppStore["dispatch"];
