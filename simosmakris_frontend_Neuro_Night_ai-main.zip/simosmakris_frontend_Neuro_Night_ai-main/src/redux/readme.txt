npm install react-redux redux-persist @reduxjs/toolkit sweetalert2


wrap main layout with 
<ReduxStoreProvider>
</ReduxStoreProvider>