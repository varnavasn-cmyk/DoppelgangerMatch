import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import MyContextProvider from "@/lib/MyContextProvider";
import SessionProviderForNextAuth from "@/nextAuth/SessionProviderForNextAuth";
import ReduxStoreProvider from "@/redux/ReduxStoreProvider";
import { NextIntlClientProvider } from "next-intl";
import { Toaster } from "sonner";
import { AuthProvider } from "@/components/AuthProvider";
import { getServerAuth } from "@/lib/auth";
import GoogleTranslateProvider from "@/components/translate/GlobalTranslateProvider";
import { getLocale } from "next-intl/server";
// import { CookieConsentModal } from "@/components/ui/modal/CookieConsentModal";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "DoppelgangerMatch",
  description:
    "Match your doppelganger with celebrities and find the perfect lookalike.",
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const data = await getServerAuth();
  const locale = await getLocale();
  return (
    <html lang={locale}>
      <NextIntlClientProvider>
        <body
          // suppressHydrationWarning={true}
          className={`inter.className ${geistSans.variable} ${geistMono.variable} antialiased`}
          suppressHydrationWarning
        >
          <MyContextProvider>
            <SessionProviderForNextAuth>
              <ReduxStoreProvider>
                <AuthProvider
                  initialUser={data?.data || null}
                  token={data?.accessToken}
                >
                  <GoogleTranslateProvider>
                    <Toaster />
                    {children}
                     {/* <CookieConsentModal /> */}
                  </GoogleTranslateProvider>
                </AuthProvider>
              </ReduxStoreProvider>
            </SessionProviderForNextAuth>
          </MyContextProvider>
        </body>
      </NextIntlClientProvider>
    </html>
  );
}
