import Link from "next/link";
import { AlertTriangle } from "lucide-react";
import { usePrefixedPath } from "@/lib/localePath";

export default function AuthErrorPage() {
  const getPrefixedPath = usePrefixedPath();
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 max-w-md w-full text-center p-10">
        {/* Warning Icon */}
        <div className="flex justify-center mb-5">
          <div className="bg-yellow-100 p-3 rounded-full">
            <AlertTriangle className="w-8 h-8 text-yellow-500" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-2xl font-semibold text-red-600 mb-3">
          Auth Error
        </h1>

        {/* Message */}
        <p className="text-gray-600 leading-relaxed mb-8">
          We encountered an issue while processing your request. <br />
          Please try again or contact the application owner if the problem
          persists.
        </p>

        {/* Button */}
        <Link
          href={getPrefixedPath("/auth/login")}
          className="inline-block bg-black text-white px-6 py-3 rounded-lg font-medium hover:bg-gray-800 transition-all duration-200"
        >
          Return to login
        </Link>

        {/* Divider */}
        <div className="border-t border-gray-200 my-8"></div>

        {/* Error Code */}
        <p className="text-sm text-gray-400">
          Error Code: <span className="font-mono">unable_to_login</span>
        </p>
      </div>
    </div>
  );
}
