import React from "react";
import { CheckCircle } from "lucide-react";

const SignUpSuccessPage = () => {

  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <div className="shadow-xl rounded-2xl p-10 max-w-md w-full text-center border border-gray-100">
        {/* Success Icon */}
        <div className="flex justify-center mb-5">
          <div className="bg-green-100 p-4 rounded-full">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
        </div>

        {/* Heading */}
        <h1 className="text-3xl font-bold text-white mb-3">
          Sign Up Successful 🎉
        </h1>

        {/* Message */}
        <p className="text-white mb-2 text-lg">
          Thank you so much for being our family member.
        </p>
        <p className="text-white">
          Please check your email and verify your identity.
        </p>

      </div>
    </div>
  );
};

export default SignUpSuccessPage;
