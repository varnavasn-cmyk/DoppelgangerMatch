import { redirect } from "next/navigation";
import SweetAlertToast from "./_component/sweetAlertToast";

export default async function AuthSuccessPage(props: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ token?: string }>;
}) {
  const { locale } = await props.params;
  const { token } = await props.searchParams;

  if (!token) {
    redirect(`/${ locale }/error`);
  }

  return <SweetAlertToast token={token} />;
}