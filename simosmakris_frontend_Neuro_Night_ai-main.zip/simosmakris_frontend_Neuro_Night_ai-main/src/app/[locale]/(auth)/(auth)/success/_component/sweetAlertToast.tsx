'use client';

import { useEffect } from 'react';
import Swal from 'sweetalert2';
import { useRouter } from 'next/navigation';
import 'animate.css';

const SweetAlertToast = ({ token }: { token: string }) => {
  const router = useRouter();

  useEffect(() => {
    if (token) {
      localStorage.setItem("accessToken", token);
    }

    console.log("Token saved successfully!");
  }, [token]);

  useEffect(() => {
    Swal.fire({
      title: 'Success!',
      text: 'Your action completed successfully.',
      icon: 'success',
      confirmButtonText: 'Go to Home',
      showClass: {
        popup: `
          animate__animated
          animate__fadeInUp
          animate__faster
        `,
      },
      hideClass: {
        popup: `
          animate__animated
          animate__fadeOutDown
          animate__faster
        `,
      },
    }).then((result) => {
      if (result.isConfirmed) {
        router.push('/');
      }
    });
  }, [router]);

  return null;
};

export default SweetAlertToast;