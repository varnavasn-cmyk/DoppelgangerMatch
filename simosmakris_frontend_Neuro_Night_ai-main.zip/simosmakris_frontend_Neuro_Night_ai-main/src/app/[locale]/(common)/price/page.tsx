import PlanPage from "@/components/pages/plan/PlanPage";

const page = () => {
  return <PlanPage />;
};

export default page;
