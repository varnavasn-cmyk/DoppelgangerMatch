import Faqs from "@/components/shared/FAQ/faqs";

const page = () => {
  return (
    <div className="xl:w-[1200px]  xl:px-0 lg:px-20 md:px-10 sm:px-5 px-4 md:py-14 py-8 lg:py-20 mx-auto">
      <div className="flex flex-col items-center justify-center gap-2">
        <h3 className="text-primary text-center font-poppins md:text-[60px]  text-4xl lg:text-[80px] font-bold leading-normal">
          Frequently Asked Questions
        </h3>
        <h6 className="text-white font-poppins text-lg font-light leading-xl">
          Effective Date: Sep 15th, 2025
        </h6>
      </div>
      <div className="pt-32 pb-12 w-[792px] mx-auto">
        <Faqs />
      </div>
    </div>
  );
};

export default page;
