/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
"use client";
import PaymentForm from "@/components/pages/payment/PaymentForm";
import { StripeWrapper } from "@/components/pages/payment/StripeWrapper";
import {
  useCreatePayPalPaymentMutation,
  useCreateStripePaymentMutation,
} from "@/redux/features/payment/paymentApi";
import { setSubscriptionData } from "@/redux/features/payment/subscriptionSlice";

import { useAppDispatch, useAppSelector } from "@/redux/hooks";
import { RootState } from "@/redux/store";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { Suspense } from "react";

function Page() {
  const path = usePathname();
  const id = path.split("/")[2];
  const dispatch = useAppDispatch();
  const [createPayPalPayment, { isLoading, error }] =
    useCreatePayPalPaymentMutation();
  const [createStripePayment] = useCreateStripePaymentMutation();

  const handlePaypalClick = async () => {
    try {
      const response = await createPayPalPayment({ planId: id }).unwrap();

      if (response?.data?.approveLink) {
        window.location.href = response?.data?.approveLink;
      } else {
        console.error("No approval URL found in PayPal response");
      }
    } catch (err) {
      console.error("PayPal payment creation failed:", err);
    }
  };

  const handleStripeClick = async () => {
    try {
      // 🔹 Call your Stripe payment creation API
      const response = await createStripePayment({ planId: id }).unwrap();

      // 🔹 Some APIs return `data`, others return the raw payload
      const payload = response?.data;

      // 🔹 Extract relevant fields
      const { clientSecret, paymentIntentId, subscription } = payload;

      // ✅ Store data in Redux
      dispatch(
        setSubscriptionData({
          clientSecret,
          paymentIntentId,
          subscription,
        })
      );
    } catch (error: any) {
      console.error("Stripe payment creation failed:", error);

      const errorMessage =
        error?.data?.message ||
        error?.message ||
        "Something went wrong. Please try again.";
    } finally {
    }
  };

  const subData = useAppSelector((state: RootState) => state.subscription);
  return (
    <div className=" xl:w-[1200px] xl:px-0 lg:px-20 md:px-6 sm:px-3 px-1 md:py-12 py-8 lg:py-20 mx-auto">
      <div>
        <h2 className="text-lg text-center sm:text-start font-semibold ">
          Choose Payment Method
        </h2>
      </div>
      <div className="flex gap-3 flex-row justify-center sm:justify-start mt-4">
        <div
          onClick={handlePaypalClick}
          className="rounded-[5.185px] hover:opacity-90 hover:scale-110 [background:linear-gradient(115deg,#0096D8_0.05%,#003087_100.05%)] w-[90.73px] flex items-center justify-center h-[62.215px] shrink-0"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="29"
            height="33"
            viewBox="0 0 29 33"
            fill="none"
          >
            <path
              d="M8.69191 31.4098L9.24802 27.8778L8.00939 27.8491H2.09473L6.20515 1.78592C6.2177 1.70723 6.25932 1.63387 6.31992 1.58178C6.38052 1.52969 6.45826 1.50098 6.53906 1.50098H16.5121C19.8231 1.50098 22.1079 2.18995 23.3009 3.54982C23.8601 4.18778 24.2163 4.85441 24.3886 5.58805C24.5692 6.35785 24.5726 7.27754 24.396 8.39926L24.3831 8.48113V9.19986L24.9426 9.51673C25.4136 9.76657 25.7876 10.0526 26.0747 10.3801C26.5534 10.9255 26.8629 11.6187 26.9935 12.4406C27.1285 13.2859 27.0838 14.2917 26.8629 15.4304C26.6076 16.7404 26.195 17.8812 25.638 18.8147C25.1253 19.6749 24.4725 20.3882 23.6975 20.9412C22.9575 21.4664 22.0782 21.8652 21.0841 22.1205C20.1206 22.3711 19.0224 22.4979 17.8178 22.4979H17.0416C16.4867 22.4979 15.9474 22.6977 15.5245 23.0561C15.1002 23.4219 14.8193 23.9214 14.7333 24.468L14.6748 24.786L13.6924 31.011L13.6477 31.2396C13.636 31.3122 13.6158 31.3483 13.5862 31.3728C13.5595 31.3948 13.5213 31.4098 13.4839 31.4098H8.69191Z"
              fill="#253B80"
            />
            <path
              d="M25.4698 8.56494C25.4401 8.75525 25.4061 8.94982 25.3679 9.1497C24.0524 15.9023 19.553 18.2351 13.806 18.2351H10.8801C10.1774 18.2351 9.58513 18.7454 9.47556 19.4386L7.97738 28.9398L7.55317 31.6329C7.48186 32.088 7.83292 32.4984 8.29201 32.4984H13.4819C14.0965 32.4984 14.6183 32.0519 14.715 31.4459L14.7662 31.1821L15.7434 24.9812L15.8062 24.6412C15.9016 24.033 16.4247 23.5865 17.0393 23.5865H17.8155C22.8435 23.5865 26.7797 21.5451 27.9302 15.6376C28.4107 13.1698 28.1619 11.1093 26.8902 9.66006C26.5055 9.22307 26.028 8.86051 25.4698 8.56494Z"
              fill="#ADC9E3"
            />
            <path
              d="M24.0921 8.01455C23.8913 7.95606 23.6838 7.9029 23.4711 7.85506C23.2575 7.8083 23.0383 7.76682 22.8131 7.73068C22.024 7.60308 21.1597 7.54248 20.2336 7.54248H12.4167C12.2242 7.54248 12.0415 7.58606 11.8778 7.66475C11.5172 7.83804 11.2494 8.17937 11.1845 8.5972L9.52138 19.1296L9.47363 19.4369C9.5832 18.7437 10.1754 18.2333 10.8782 18.2333H13.8041C19.5511 18.2333 24.0508 15.8995 25.3659 9.14796C25.4051 8.94807 25.4382 8.75351 25.4679 8.5632C25.1352 8.38669 24.7746 8.23571 24.3865 8.10704C24.291 8.07515 24.1922 8.04433 24.0921 8.01455Z"
              fill="#E6EFF6"
            />
            <path
              d="M11.1886 8.59797C11.2535 8.1801 11.5216 7.83881 11.8819 7.66656C12.0468 7.58787 12.2286 7.54429 12.4208 7.54429H20.238C21.1641 7.54429 22.0284 7.60489 22.8172 7.73249C23.0427 7.76863 23.2619 7.8101 23.4755 7.85687C23.6882 7.90474 23.8954 7.9579 24.0965 8.01636C24.1963 8.04614 24.2951 8.07696 24.3919 8.10781C24.7799 8.23645 25.1405 8.3885 25.4732 8.56394C25.8646 6.06852 25.4701 4.36947 24.121 2.83095C22.6335 1.13723 19.9487 0.412109 16.5135 0.412109H6.54014C5.83834 0.412109 5.23999 0.922438 5.13134 1.61674L0.977456 27.9478C0.895431 28.4687 1.29729 28.9388 1.8225 28.9388H7.97986L9.52579 19.1304L11.1886 8.59797Z"
              fill="white"
            />
          </svg>
        </div>
        <div
          onClick={handleStripeClick}
          className="group relative rounded-[5.185px] hover:scale-110 bg-[#6461FC] w-[90.73px] h-[62.215px] flex items-center justify-center shrink-0 overflow-hidden cursor-pointer transition-all duration-300"
        >
          {/* Stripe logo */}
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="67"
            height="29"
            viewBox="0 0 67 29"
            fill="none"
            className="transition-opacity duration-300 group-hover:opacity-0"
          >
            <path
              d="M45.6299 6.52441C48.8432 6.52441 51.8732 9.41849 51.8916 14.7305C51.8915 20.5368 48.8981 23.1748 45.6113 23.1748C43.9956 23.1747 43.0223 22.4967 42.3613 22.0205L42.3428 27.2041L37.7529 28.1748V6.81738H41.792L42.0312 7.95312C42.6739 7.36698 43.8304 6.52444 45.6299 6.52441ZM6.46387 6.52344C7.9878 6.52344 9.49365 6.76185 11.0176 7.36621V11.6709C9.6221 10.92 7.85929 10.499 6.46387 10.499C5.49103 10.4991 4.90353 10.7733 4.90332 11.4873C4.90332 13.5388 11.8996 12.5688 11.918 18.0273C11.9177 21.3058 9.29177 23.1924 5.47266 23.1924C3.89359 23.1924 2.16756 22.8811 0.459961 22.1484V17.7891C2.00233 18.6316 3.94869 19.2539 5.47266 19.2539C6.50091 19.2539 7.23535 18.9793 7.23535 18.1367C7.23515 15.9571 0.257812 16.7625 0.257812 11.707C0.258048 8.46526 2.73671 6.52354 6.46387 6.52344ZM17.2979 6.83496H20.7861V10.7373H17.2979V17.2393C17.2979 19.9496 20.1977 19.1084 20.7861 18.8701V22.5879C20.1802 22.9176 19.0788 23.1924 17.5732 23.1924C14.8557 23.1924 12.8175 21.1962 12.8174 18.4854L12.8359 3.81348L17.3164 2.86035L17.2979 6.83496ZM59.7324 6.52441C64.0841 6.5245 66.3613 10.2241 66.3613 14.9131C66.3613 15.3527 66.3242 16.3058 66.3242 16.5439H57.3447C57.5469 18.705 59.1263 19.3281 60.9072 19.3281C62.7251 19.3281 64.1576 18.9431 65.4062 18.3203V21.9834C64.1577 22.6794 62.5052 23.1738 60.3203 23.1738C55.8401 23.1738 52.7179 20.3902 52.7178 14.877C52.7178 10.2244 55.3623 6.52441 59.7324 6.52441ZM26.4971 8.19043C27.5804 6.21218 29.7288 6.61516 30.3164 6.83496V11.0479C29.7472 10.8464 27.9105 10.5896 26.8271 12V22.8623H22.2373V6.83496H26.2031L26.4971 8.19043ZM36.0449 22.8623H31.4355V6.83496H36.0449V22.8623ZM44.5283 10.5908C43.4817 10.5908 42.8202 10.9571 42.3428 11.4883L42.3613 18.2842C42.802 18.7604 43.445 19.1455 44.5283 19.1455C46.2175 19.1453 47.3555 17.3127 47.3555 14.8584C47.3553 12.4592 46.199 10.5911 44.5283 10.5908ZM59.7139 10.2432C58.5571 10.2432 57.29 11.104 57.29 13.1738H62.0273C62.0273 11.1041 60.8339 10.2432 59.7139 10.2432ZM36.0459 4.4541L31.4365 5.44336V1.70605L36.0459 0.735352V4.4541Z"
              fill="white"
            />
          </svg>

          {/* Hover icons */}
          <div className="absolute inset-0 flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <Image
              src="/icons/visa.svg"
              width={24}
              height={24}
              alt="Visa"
              className="w-6 h-6 object-contain"
            />
            <Image
              src="/icons/mastercard.svg"
              width={24}
              height={24}
              alt="MasterCard"
              className="w-6 h-6 object-contain"
            />
            <Image
              src="/icons/apple-pay.svg"
              width={24}
              height={24}
              alt="Apple Pay"
              className="w-6 h-6 object-contain"
            />
            <Image
              src="/icons/google-pay.svg"
              width={24}
              height={24}
              alt="Google Pay"
              className="w-6 h-6 object-contain"
            />
            <Image
              src="/icons/credit-card.svg"
              width={24}
              height={24}
              alt="Card"
              className="w-6 h-6 object-contain"
            />
          </div>
        </div>
      </div>
      {subData.clientSecret == null ? (
        ""
      ) : (
        <Suspense fallback={<div>Loading...</div>}>
          <StripeWrapper>
            <PaymentForm />
          </StripeWrapper>
        </Suspense>
      )}
    </div>
  );
}

export default Page;
