/* eslint-disable react-hooks/exhaustive-deps */

"use client";

import React, { useEffect } from "react";
import { DotLottieReact } from "@lottiefiles/dotlottie-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useDispatch, useSelector } from "react-redux";
import { triggerSubmit } from "@/redux/features/payment/submitSlice";
import { useRouter } from "next/navigation";
import { selectMorphCredentials } from "@/redux/features/users/morphSlice";
import { usePrefixedPath } from "@/lib/localePath";
// import { useGetMeUserQuery } from "@/redux/features/users/usersApi";

export default function PaymentSuccessPage() {
  const dispatch = useDispatch();
  const getPrefixedPath = usePrefixedPath();
  // const { data, isLoading } = useGetMeUserQuery({});
  // const users = data?.data;

  const router = useRouter();
  const morphData = useSelector(selectMorphCredentials);

  useEffect(() => {
    // (async () => {
    //   const = await new Promise((resolve) => setTimeout(resolve, 3000));

    // })();
    if (
      // users?.hasMorphing === true &&
      morphData?.id &&
      morphData?.user_image_key &&
      morphData?.celebrity_image_key
    ) {
      const morphPayload = {
        id: morphData.id,
        user_image_key: morphData.user_image_key,
        celebrity_image_key: morphData.celebrity_image_key,
        bucket: morphData.bucket ?? "",
      };

      dispatch(triggerSubmit(morphPayload));
      setTimeout(() => {
        router.push(getPrefixedPath("/upload-photo"));
      }, 1000);
    }
  }, []);

  return (
    <div className="lg:min-h-screen h-auto  flex  justify-center bg-transparent px-4">
      <div className="flex items-center sm:mb-0 mb-20 flex-col gap-4">
        {/* Success Icon with decorative dots */}
        <div className="relative inline-block  md:w-64 h-48 w-48 md:h-64">
          <DotLottieReact
            src="https://lottie.host/6b24a12e-4c05-4d50-b7d4-7829536f8675/VFlmKbZuic.lottie"
            loop
            autoplay
          />
        </div>

        {/* Success Message */}
        <h1 className="lg:text-3xl text-xl md:text-nowrap text-center font-bold text-cyan-500 mb-6 text-balance">
          Your payment has been received
        </h1>

        <p className="text-white text-center mb-8 leading-relaxed text-balance">
          Thank you for your payment. Your plan has been upgraded to premium!
          <br />
          Please check your email for a payment confirmation & invoice.
        </p>

        {/* CTA Button */}
        <Button
          // onClick={handleMorphing}
          onClick={() => router.push(getPrefixedPath("/upload-photo"))}
          asChild
          size="lg"
          // disabled={isLoading}
          className="bg-cyan-500 hover:bg-cyan-600 text-white px-8 py-6 text-base rounded-full"
        >
          <Link href={getPrefixedPath("/upload-photo")}>
            Go to your Upload Photo
          </Link>
        </Button>
      </div>
    </div>
  );
}
