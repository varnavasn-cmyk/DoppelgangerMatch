/* eslint-disable @typescript-eslint/no-unused-vars */
"use client";

import { useExecutePayPalPaymentMutation } from "@/redux/features/payment/paymentApi";
import { useSearchParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { CheckCircle2, Loader2, XCircle } from "lucide-react";
import { Card } from "@/components/ui/card";
import { useDispatch, useSelector } from "react-redux";
import { selectMorphCredentials } from "@/redux/features/users/morphSlice";
import { Button } from "@/components/ui/button";
import { triggerSubmit } from "@/redux/features/payment/submitSlice";
import { usePrefixedPath } from "@/lib/localePath";
import { useGetMeUserQuery } from "@/redux/features/users/usersApi";

const Page = () => {
  const searchParams = useSearchParams();
  const [confirmPayPalPayment, { isLoading, data, error }] =
    useExecutePayPalPaymentMutation();
  // const { data: userData } = useGetMeUserQuery({});
  // const users = userData?.data;
  const [countdown, setCountdown] = useState(3);
  const dispatch = useDispatch();
  const router = useRouter();
  const morphData = useSelector(selectMorphCredentials);
  const getPrefixedPath = usePrefixedPath();

  const token = searchParams.get("token");
  const payerId = searchParams.get("PayerID");

  // ✅ Confirm payment
  useEffect(() => {
    if (token && payerId) {
      const payload = { orderId: token };
      confirmPayPalPayment(payload)
        .unwrap()
        .then((res) => console.log("✅ Payment confirmed:", res))
        .catch((err) => console.error("❌ Payment confirmation failed:", err));
    }
  }, [token, payerId, confirmPayPalPayment]);

  const handleMorphing = () => {
    if (
      // users?.hasMorphing === true &&
      morphData?.id &&
      morphData?.user_image_key &&
      morphData?.celebrity_image_key
    ) {
      const morphPayload = {
        id: morphData.id,
        user_image_key: morphData.user_image_key,
        celebrity_image_key: morphData.celebrity_image_key,
        bucket: morphData.bucket ?? "",
      };
      dispatch(triggerSubmit(morphPayload));
      router.push(getPrefixedPath("/upload-photo"));
    } else {
      router.push(getPrefixedPath("/upload-photo"));
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-8 shadow-2xl">
        <div className="flex flex-col items-center text-center space-y-6">
          {/* Status Icon */}
          <div className="relative">
            {isLoading && (
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
                <Loader2 className="w-10 h-10 text-primary animate-spin" />
              </div>
            )}
            {data?.success && (
              <div className="w-20 h-20 rounded-full bg-green-500/10 flex items-center justify-center animate-scale-in">
                <CheckCircle2 className="w-10 h-10 text-green-500" />
              </div>
            )}
            {error && (
              <div className="w-20 h-20 rounded-full bg-destructive/10 flex items-center justify-center animate-shake">
                <XCircle className="w-10 h-10 text-destructive" />
              </div>
            )}
          </div>

          {/* Message */}
          <div className="space-y-2">
            <h1 className="text-3xl font-bold text-foreground">
              {isLoading && "Processing Payment"}
              {data?.success && "Payment Successful!"}
              {error && "Payment Failed"}
            </h1>
            <p className="text-muted-foreground text-balance">
              {isLoading && "Please wait while we confirm your payment..."}
              {data?.success && data.message}
              {error && "There was an error processing your payment."}
            </p>
          </div>

          {/* Payment Details */}
          {data?.success && data.data?.subscription && (
            <div className="w-full bg-muted/50 rounded-lg p-4 space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Amount</span>
                <span className="font-semibold text-foreground">
                  ${data.data.subscription.amount}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Status</span>
                <span className="font-semibold text-green-500">
                  {data.data.subscription.paymentStatus}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Transaction ID</span>
                <span className="font-mono text-xs text-foreground">
                  {data.data.subscription.stripePaymentId}
                </span>
              </div>
            </div>
          )}

          {/* Manual Action */}
          <Button
            onClick={handleMorphing}
            size="lg"
            className="bg-cyan-500 hover:bg-cyan-600 text-white px-8 py-6 text-base rounded-full"
          >
            Go to your Upload Photo
          </Button>

          {/* Countdown */}
          {data?.success && countdown > 0 && (
            <div className="text-sm text-muted-foreground animate-pulse">
              Redirecting to upload photo in {countdown} second
              {countdown !== 1 ? "s" : ""}...
            </div>
          )}

          {error && (
            <div className="w-full bg-destructive/10 rounded-lg p-4 text-sm text-destructive">
              Please try again or contact support if the issue persists.
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};

export default Page;
