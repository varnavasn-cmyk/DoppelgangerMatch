import Footer from "@/components/shared/Footer/Footer";
import NavBar from "@/components/shared/NavBar/navComponent/NavBar";
import { ReactNode } from "react";

const layout = ({ children }: { children: ReactNode }) => {
  return (
    <div>
      <div className="h-full min-h-[calc(100vh-0px)] relative">
        <div className=" absolute md:w-[602px] md:h-[602px] h-[300px] w-[280px] shrink-0 rounded-[602px] bg-[rgba(2,204,216,0.5)] blur-[250px] -top-70 left-1/2 transform -translate-x-1/2 -z-10"></div>
        <NavBar />
        {children}
        <Footer />
      </div>
    </div>
  );
};

export default layout;
