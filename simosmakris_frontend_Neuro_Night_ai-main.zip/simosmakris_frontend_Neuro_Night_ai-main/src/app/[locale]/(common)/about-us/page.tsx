import AboutUs from "@/components/pages/about-us/AboutUs";

const page = () => {
  return <AboutUs />;
};

export default page;
