import { useTranslations } from "next-intl";

function TermsConditionsContent() {
  const t = useTranslations("Terms&Conditions");
  return (
    <div className="flex flex-col items-center justify-center gap-5 mb-24">
      <h3 className="text-primary text-center font-poppins md:text-[60px]  text-4xl lg:text-[80px] font-bold leading-normal">
        {t("title")}
      </h3>
      <p className="text-white text-center font-poppins text-lg font-light leading-5">
        {t("lastUpdated")}
      </p>
    </div>
  );
}

export default TermsConditionsContent;
