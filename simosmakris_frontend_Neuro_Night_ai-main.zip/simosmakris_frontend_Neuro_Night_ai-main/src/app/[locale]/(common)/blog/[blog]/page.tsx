import ViewBlog from "@/components/Blog/ViewBlog";
const page = () => {
  return (
    <section className="xl:w-[1200px]  xl:px-0 lg:px-20 md:px-10 sm:px-5 px-4 md:py-14 py-8 lg:py-20 mx-auto ">
      <div className="flex flex-col justify-center items-center">
        <h3 className="text-primary text-center font-poppins md:text-[60px]  text-4xl lg:text-[80px] font-bold leading-normal">
          Blog
        </h3>
        <h6 className="text-[#8896AB] text-center font-poppins text-xl lg:w-[1005px] font-medium leading-[30px]">
          Welcome to the Doppelganger Match AI Blog — your hub for everything
          about AI lookalikes, morphing, and the magic of facial recognition.
          Discover stories, tips, and insights from our growing community.
        </h6>
      </div>
      <div className="flex justify-center items-center mt-8">
        <ViewBlog />
      </div>
    </section>
  );
};

export default page;
