import ContactUsPage from "@/components/pages/contactUs/ContactUsPage";
const page = () => {
  return <ContactUsPage />;
};

export default page;
