import HomeComponent from "@/components/pages/home/HomeComponent";

const HomePage = async () => {
  return (
    <>
      <HomeComponent />
    </>
  );
};

export default HomePage;
