import CookiesPolicyTitle from "@/components/pages/cookies-policy/CookiesPolicy";
import CookiesPolicyDetels from "@/components/pages/cookies-policy/CookiesPolicyDetels";

const page = () => {
  return (
    <section className="xl:w-[1200px]  xl:px-0 lg:px-20 md:px-10 sm:px-5 px-4 md:py-14 py-8 lg:py-20 mx-auto">
      <CookiesPolicyTitle />
      <CookiesPolicyDetels />
    </section>
  );
};

export default page;
