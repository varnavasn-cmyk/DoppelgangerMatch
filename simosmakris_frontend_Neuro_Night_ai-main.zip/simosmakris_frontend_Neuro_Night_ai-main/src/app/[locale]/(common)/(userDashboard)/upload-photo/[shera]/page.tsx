"use client";
import {
  useGetShareVideoByIdQuery,
  useGetSingleShareQuery,
} from "@/redux/features/users/usersApi";
import Skeleton from "antd/es/skeleton";
import Image from "next/image";
import { usePathname } from "next/navigation";

const Page = () => {
  const path = usePathname();
  const id = path.split("/").pop();
  const { data, isLoading } = useGetSingleShareQuery(id);
  const { data: videoData, isLoading: videoLoading } =
    useGetShareVideoByIdQuery(id);

  const videoUrl = videoData?.data?.videoUrl;
  const imageUrl = data?.data?.originalImageUrl;

  // Check if either query is still loading
  const loading = isLoading || videoLoading;

  return (
    <div className="flex justify-center items-center py-10">
      {loading ? (
        <Skeleton active className="w-full" />
      ) : (
        <>
          {videoUrl ? (
            <video
              src={videoUrl}
              controls
              className="rounded-lg h-[70vh] w-[60vw] object-cover shadow-lg"
            >
              Your browser does not support the video tag.
            </video>
          ) : imageUrl ? (
            <Image
              src={imageUrl}
              alt="Description of image"
              width={900}
              height={500}
              className="rounded-lg h-[70vh] w-[60vw] object-cover shadow-lg"
            />
          ) : (
            <p className="text-gray-500">No media found</p>
          )}
        </>
      )}
    </div>
  );
};

export default Page;
