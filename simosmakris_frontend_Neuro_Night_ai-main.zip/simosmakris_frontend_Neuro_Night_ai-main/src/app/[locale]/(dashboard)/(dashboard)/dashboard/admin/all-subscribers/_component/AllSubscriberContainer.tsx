import Pagination from "@/components/shared/table/components/Pagination";
import {
  Table,
  TableBody,
  TableBodyItem,
  TableHeader,
  TableHeaderItem,
  TableRow,
} from "@/components/shared/table/components/Table";
import fetchTableData from "@/components/shared/table/lib/fetchTableData";
import sortTableData from "@/components/shared/table/lib/sortTableData";
import { SortDirection } from "@/components/shared/table/types/table.type";
import {
  DEFAULT_ITEMS_PER_PAGE,
  DEFAULT_PAGE,
} from "@/components/shared/table/utils/constant";
import { Button } from "@/components/ui/button";
import { env } from "@/env";
import { getAccessToken } from "@/lib/auth";
import SubscriberDeleteButton from "./SubscriberDeleteButton";
import Link from "next/link";

// -------------------- API Types --------------------
type Subscriber = {
  id: string;
  email: string;
  accepted: boolean;
  createdAt: string;
};

type SubscribersApiResponse = {
  success: boolean;
  message: string;
  data: Subscriber[];
};

// -------------------- Table Types --------------------
type SubscriberTableRow = {
  id: string;
  email: string;
  createdAt: string;
};

type TableHeaderType = {
  key: keyof SubscriberTableRow;
  label: string;
};

type SearchParams = {
  page?: string;
  limit?: string;
  sort?: string;
  q?: string;
};

// -------------------- Helpers --------------------
function parseSearchParams(params: SearchParams): {
  page: number;
  limit: number;
  sortField: string;
  sortDirection: SortDirection;
  q?: string;
} {
  const page = Number(params.page) || DEFAULT_PAGE;
  const limit = Number(params.limit) || DEFAULT_ITEMS_PER_PAGE;
  const [sortField = "", sortDirection = ""] = (params.sort || "").split(":");

  return {
    page,
    limit,
    sortField,
    sortDirection: sortDirection as SortDirection,
    q: params?.q,
  };
}

function normalizeSubscriberData(rows: Subscriber[]): SubscriberTableRow[] {
  return rows.map((row) => ({
    id: row.id,
    email: row.email,
    createdAt: new Date(row.createdAt).toLocaleString(),
  }));
}

// -------------------- Component --------------------
export default async function AllSubscriberContainerPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const resolvedSearchParams = searchParams;
  const token = await getAccessToken();

  const { page, limit, sortField, sortDirection, q } =
    parseSearchParams(resolvedSearchParams);

  const queryString = new URLSearchParams({
    page: page.toString(),
    limit: limit.toString(),
    ...(q && { q }),
  }).toString();

  const response = await fetchTableData<SubscribersApiResponse>(
    `${ env.API_BASE_URL }/subscriber?${ queryString }`,
    { headers: { Authorization: token || "" } }
  );

  // Handle array response
  const apiResponse = Array.isArray(response) ? response[0] : response;

  if (!apiResponse?.data?.length) {
    return (
      <div className="text-center py-10 text-gray-500 text-lg">
        No Subscribers Found
      </div>
    );
  }

  const tableDataRaw: Subscriber[] = apiResponse.data;
  const normalizedData: SubscriberTableRow[] =
    normalizeSubscriberData(tableDataRaw);

  // Table Headers
  const tableHeader: readonly TableHeaderType[] = [
    { key: "email", label: "Email" },
    { key: "createdAt", label: "Created At" },
  ] as const;

  // Apply Sorting
  const sorted: SubscriberTableRow[] = sortTableData(
    normalizedData,
    sortField as keyof SubscriberTableRow,
    sortDirection
  );

  return (
    <div className="space-y-6">

      <div className="flex items-center justify-end">
        <Button
          size="lg"
          asChild
          className="text-lg font-semibold bg-[#00FFFF99] hover:bg-[#00FFFF99]/60"
        >
          <Link href="/dashboard/admin/send-email">Send Email</Link>
        </Button>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            {tableHeader.map(({ key }) => (
              <TableHeaderItem
                key={key}
                prop={key}
                currentSort={sortField}
                sortDirection={sortDirection}
              />
            ))}
            <th>Action</th>
          </TableRow>
        </TableHeader>

        <TableBody>
          {sorted.length > 0 ? (
            sorted.map((item: SubscriberTableRow) => (
              <TableRow key={item.id}>
                {tableHeader.map(({ key }) => (
                  <TableBodyItem key={key}>{item[key] ?? "N/A"}</TableBodyItem>
                ))}
                <td>
                  <Button size="lg" asChild variant="ghost">
                    <SubscriberDeleteButton id={item.id} />
                  </Button>
                </td>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableBodyItem colSpan={tableHeader.length + 1}>
                <div className="text-center py-6 text-gray-500">
                  No Data Found
                </div>
              </TableBodyItem>
            </TableRow>
          )}
        </TableBody>
      </Table>

      <Pagination
        totalPages={1}
        currentPage={page}
        pageSize={limit}
      />
    </div>
  );
}
