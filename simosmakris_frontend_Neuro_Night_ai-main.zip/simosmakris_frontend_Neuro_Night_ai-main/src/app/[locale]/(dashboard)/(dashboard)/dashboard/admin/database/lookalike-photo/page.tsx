/* eslint-disable @typescript-eslint/no-explicit-any */
import { env } from "@/env";
import LookaLikePhotoContent from "./_component/LookaLikePhotoContent";

async function getAllNormalImages() {
  const res = await fetch(`${env.API_BASE_URL}/normal-database`, {
    method: "GET",
    cache: "no-store",
  });

  if (!res.ok) throw new Error("Failed to fetch images");

  const data = await res.json();
  const images = data?.data?.data || [];

  const sortedImages = images.sort(
    (a: any, b: any) => new Date(b.lastModified).getTime() - new Date(a.lastModified).getTime()
  );

  return sortedImages;

}

export default async function LookaLikePhotoPage() {
  const images = await getAllNormalImages();
  return <LookaLikePhotoContent images={images} />;
}
