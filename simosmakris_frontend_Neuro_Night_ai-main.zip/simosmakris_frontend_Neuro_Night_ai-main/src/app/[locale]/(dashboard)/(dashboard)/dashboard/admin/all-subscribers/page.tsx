import React from "react";
import AllSubscriberContainerPage from "./_component/AllSubscriberContainer";



type AllSubscribersPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

const AllSubscribersPage = async ({ searchParams }: AllSubscribersPageProps) => {
  const resolvedParams = await searchParams;

  return (
    <div className="p-4">
      <AllSubscriberContainerPage searchParams={resolvedParams} />
    </div>
  );
};

export default AllSubscribersPage;
