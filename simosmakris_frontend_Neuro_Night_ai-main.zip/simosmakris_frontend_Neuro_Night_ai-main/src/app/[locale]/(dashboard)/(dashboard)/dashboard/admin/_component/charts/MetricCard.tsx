import type React from "react"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import Link from "next/link"
import { usePrefixedPath } from "@/lib/localePath"

interface MetricCardProps {
  title: string
  value: string | number
  icon: React.ReactNode
  url: string
  className?: string
}

export function MetricCard({ title, value, icon, url, className }: MetricCardProps) {
  const getPrefixedPath = usePrefixedPath();
  return (
    <Card className={cn("p-6 bg-white/10 border-white/10 [box-shadow:10px_0_20px_0_rgba(2,204,216,0.05)]", className)}>
      <Link href={getPrefixedPath(url)}>
        <div className="flex flex-col items-center gap-4">
          <div className="flex flex-row justify-around items-center xl:gap-5 lg:gap-3 md:gap-2 gap-1">
            <div className="p-3 rounded-full bg-amber-600/20">
              <div className="text-amber-600 size-4 lg:size-6 xl:size-8">{icon}</div>
            </div>
            <p className="xl:text-xl lg:text-lg text-base text-foreground mb-1">{title}</p>
          </div>
          <p className="text-3xl font-bold text-foreground">{value}</p>
        </div>
      </Link>
    </Card>
  )
}
