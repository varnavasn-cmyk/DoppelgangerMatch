"use client";

import ProfileButton from "@/components/ProfileButton";
import DashboardHeaderTitle from "./DashboardHeaderTitle";
import { usePathname } from "next/navigation";
import { formatUrlSegment } from "@/utils/url";

// mapping for dashboard paths
const pathTitles: Record<string, string> = {
  "dashboard/admin": "Overview",
  "dashboard/admin/database/lookalike-photo": "Lookalike Database",
  "dashboard/admin/database": "Database Management",
  "dashboard/admin/database/celebrity-lookalike": "Celebrity Lookalike Database",
  "dashboard/admin/user-lookalike": "User Lookalike Database",
  "dashboard/admin/all-blogs/edit/:id": "Edit Blog",
};

function isIdSegment(segment: string) {
  return /^[0-9a-fA-F]{24}$/.test(segment);
}

// ✅ Helper: match dynamic route patterns (e.g., /edit/:id)
function matchDynamicPath(pathname: string) {
  const parts = pathname.split("/").filter(Boolean);

  for (const key in pathTitles) {
    const keyParts = key.split("/").filter(Boolean);

    if (keyParts.length !== parts.length) continue;

    const isMatch = keyParts.every((kp, i) => {
      if (kp.startsWith(":")) return true; // dynamic param allowed
      return kp === parts[i];
    });

    if (isMatch) return pathTitles[key];
  }

  return null;
}

export default function DashboardHeader() {
  const pathname = usePathname();
  const parts = pathname.split("/").filter(Boolean);

  const fullPath = parts.join("/");
  const lastSegment = parts[parts.length - 1];

  let title: string;

  //! First check static path match
  if (pathTitles[fullPath]) {
    title = pathTitles[fullPath];
  }
  //! Then check dynamic pattern match (like /edit/:id)
  else {
    const dynamicTitle = matchDynamicPath(fullPath);
    if (dynamicTitle) {
      title = dynamicTitle;
    }
    else if (isIdSegment(lastSegment)) {
      title = "Edit";
    }
    else {
      title = formatUrlSegment(lastSegment);
    }
  }

  return (
    <div className="px-[var(--_sidebar-spacing)] flex items-center h-[var(--_sidebar-header-height)] common_dashboard_bg_color border-b [box-shadow:10px_0_20px_0_rgba(2,204,216,0.05)]">
      <div className="flex justify-between items-center gap-2 flex-1">
        <DashboardHeaderTitle>{title}</DashboardHeaderTitle>
        <ProfileButton />
      </div>
    </div>
  );
}
