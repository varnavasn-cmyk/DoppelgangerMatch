import React from 'react';
import PlanUpdateContentPage from './_components/PlanUpdateContent';

const PlanUpdatePage = () => {
  return (
    <div>
      <PlanUpdateContentPage />
    </div>
  );
};

export default PlanUpdatePage;