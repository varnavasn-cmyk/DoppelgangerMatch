/* eslint-disable @typescript-eslint/no-explicit-any */
"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Cell,
  Tooltip as ReTooltip,
} from "recharts"
import { useMemo, useState } from "react"

interface RevenueData {
  day: string
  value: number
  highlighted?: boolean
}

interface RevenueBarChartProps {
  weeklyData: RevenueData[]
  monthlyData: RevenueData[]
  yearlyData: RevenueData[]
  period: string
  onPeriodChange: (period: string) => void
  periods: { value: string; label: string }[]
}

const CustomTooltip = ({ active, payload, coordinate }: any) => {
  if (active && payload && payload.length) {
    const chartWidth = 960;
    const safeX = Math.max(20, Math.min(coordinate.x, chartWidth - 40));

    return (
      <div
        style={{
          position: "absolute",
          left: safeX,
          bottom: "100%",
          transform: "translateX(-50%)",
          pointerEvents: "none",
        }}
      >

        <div className="bg-[#02CCD8] text-black text-sm font-bold shadow-lg w-12 h-8 rounded-lg flex items-center justify-center">
          ${payload[0].value}
        </div>
        <div className="absolute bottom-[-5px] left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[5px] border-r-[5px] border-t-[5px] border-t-[#02CCD8] border-l-transparent border-r-transparent" />

      </div>
    );
  }
  return null;
};


export function RevenueBarChart({
  weeklyData,
  monthlyData,
  yearlyData,
  period,
  onPeriodChange,
  periods,
}: RevenueBarChartProps) {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null)

  const chartData = useMemo(() => {
    if (period === "weekly") return weeklyData
    if (period === "monthly") return monthlyData
    if (period === "yearly") return yearlyData
    return weeklyData
  }, [period, weeklyData, monthlyData, yearlyData])

  return (
    //bg-white/10 border-white/10 [box-shadow:10px_0_20px_0_rgba(2,204,216,0.05)]
    <Card className="bg-white/10 border-white/10 [box-shadow:10px_0_20px_0_rgba(2,204,216,0.05)]">
      <CardHeader className="flex flex-wrap flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="text-xl font-semibold text-foreground">
          Total Revenue
        </CardTitle>
        <Select value={period} onValueChange={onPeriodChange}>
          <SelectTrigger className="w-32 bg-background border-border">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {periods.map((p) => (
              <SelectItem key={p.value} value={p.value}>
                {p.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 30, right: 30, left: 20, bottom: 5 }}
            >
              <XAxis
                dataKey="day"
                axisLine={false}
                tickLine={false}
                tick={{ fill: "#ffffff", fontSize: 12, fontWeight: "bold" }}
              />
              <YAxis hide />

              {/* Fixed tooltip at top of bar */}
              <ReTooltip
                cursor={{ fill: "rgba(2,204,216,0.1)" }}
                position={{ y: -8 }}
                content={<CustomTooltip />}
                isAnimationActive={false}
              />


              <Bar
                dataKey="value"
                radius={[5, 5, 0, 0]}
                maxBarSize={60}
                onMouseEnter={(_, index) => setHoverIndex(index)}
                onMouseLeave={() => setHoverIndex(null)}
              >
                {chartData.map((entry, index) => (
                  <Cell
                    key={`cell-${ index }`}
                    fill={hoverIndex === index ? "#02CCD8" : "#676C78"}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
