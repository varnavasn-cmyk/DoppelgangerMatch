/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ApertureIcon, CalendarIcon, CameraIcon, UserIcon } from "./charts/DashboardIcon";
import { MetricCard } from "./charts/MetricCard";
import { RevenueBarChart } from "./charts/RevenueBarChart";
import { TrafficPieChart } from "./charts/TrafficPieChart";
import { toast } from "sonner";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/components/AuthProvider";
import { env } from "@/env";

const weeklyData = [
  { day: "Sun", value: 0, highlighted: false },
  { day: "Mon", value: 0, highlighted: false },
  { day: "Tue", value: 0, highlighted: false },
  { day: "Wed", value: 0, highlighted: true },
  { day: "Thu", value: 0, highlighted: false },
  { day: "Fri", value: 0, highlighted: false },
  { day: "Sat", value: 0, highlighted: false },
];

const monthlyData = [
  { day: "Jan", value: 0, highlighted: false },
  { day: "Feb", value: 0, highlighted: false },
  { day: "Mar", value: 0, highlighted: false },
  { day: "Apr", value: 0, highlighted: true },
  { day: "May", value: 0, highlighted: false },
  { day: "Jun", value: 0, highlighted: false },
  { day: "Jul", value: 0, highlighted: false },
  { day: "Aug", value: 0, highlighted: false },
  { day: "Sep", value: 0, highlighted: false },
  { day: "Oct", value: 0, highlighted: false },
  { day: "Nov", value: 0, highlighted: false },
  { day: "Dec", value: 0, highlighted: false },
];

const yearlyData = [
  { day: "2016", value: 0, highlighted: false },
  { day: "2017", value: 0, highlighted: false },
  { day: "2018", value: 0, highlighted: false },
  { day: "2019", value: 0, highlighted: true },
  { day: "2020", value: 0, highlighted: false },
  { day: "2021", value: 0, highlighted: false },
  { day: "2022", value: 0, highlighted: false },
  { day: "2023", value: 0, highlighted: false },
  { day: "2024", value: 0, highlighted: true },
  { day: "2025", value: 0, highlighted: false },
];

const periods = [
  { value: "weekly", label: "Weekly" },
  { value: "monthly", label: "Monthly" },
  { value: "yearly", label: "Yearly" },
];

export default function DashboardCardPage() {
  const [selectedPeriod, setSelectedPeriod] = useState("weekly");
  const [metrics, setMetrics] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [trafficData, setTrafficData] = useState<any[]>([]); // ✅ Pie chart data state

  const { token } = useAuth();

  const [revenueData, setRevenueData] = useState({
    weekly: weeklyData,
    monthly: monthlyData,
    yearly: yearlyData,
  });

  // ✅ Fetch main dashboard stats
  useEffect(() => {
    async function fetchDashboardStats() {
      try {
        setLoading(true);
        const res = await fetch(`/api/dashboard-stats`);
        console.log("Stat Result: ", res)
        if (!res.ok) throw new Error("Failed to fetch dashboard stats");

        const result = await res.json();
        const stats = result?.data?.data || result?.data || result;

        console.log("Dashboard stats:", stats);

        setMetrics([
          { title: "Total User", value: String(stats.totaFlUsers ?? "0"), icon: <UserIcon />, url: "/dashboard/admin/all-user" },
          { title: "All Morphing", value: String(stats.totalMorphVideos ?? "0"), icon: <CalendarIcon />, url: "/dashboard/admin" },
          { title: "Total Celebrities", value: String(stats.totalCelebrity ?? "0"), icon: <CameraIcon />, url: "/dashboard/admin/database/celebrity-lookalike" },
          { title: "User Lookalike", value: String(stats.totalNormal ?? "0"), icon: <ApertureIcon />, url: "/dashboard/admin/database/lookalike-photo" },
        ]);
      } catch (error: any) {
        toast.error(error.message || "Failed to load dashboard data");
      } finally {
        setLoading(false);
      }
    }

    fetchDashboardStats();
  }, []);

  // ✅ Fetch revenue chart data
  useEffect(() => {
    async function fetchRevenueData() {
      try {
        const res = await fetch(
          `${ env.NEXT_PUBLIC_API_URL }/subscriptions/analytics/revenue?period=${ selectedPeriod }`,
          {
            headers: {
              Authorization: `Bearer ${ token }`,
              "Content-Type": "application/json",
            },
          }
        );

        if (!res.ok) throw new Error("Failed to fetch revenue data");

        const result = await res.json();
        const breakdownData = result?.data?.breakdownData || [];

        console.log("BreakdownData from API:", breakdownData);

        // ✅ Transform API data for the chart
        const transformedData = (() => {
          // Step 1: Group data by week/month/year
          const grouped: Record<string, number> = {};

          breakdownData.forEach((item: any) => {
            const date = new Date(item.period);
            let key = "";

            if (selectedPeriod === "weekly") {
              key = date.toLocaleDateString("en-US", { weekday: "short" });
            } else if (selectedPeriod === "monthly") {
              key = date.toLocaleDateString("en-US", { month: "short" });
            } else if (selectedPeriod === "yearly") {
              key = date.getFullYear().toString();
            }

            // Sum revenues for same period
            grouped[key] = (grouped[key] || 0) + parseInt(item.revenue);
          });

          // Step 2: Convert grouped object into array for Recharts
          return Object.entries(grouped).map(([day, value]) => ({
            day,
            value,
            highlighted: value > 200,
          }));
        })();

        // ✅ Update chart data
        setRevenueData((prev) => ({
          ...prev,
          [selectedPeriod]:
            transformedData.length > 0
              ? transformedData
              : prev[selectedPeriod as keyof typeof prev],
        }));
      } catch (error: any) {
        toast.error(error.message || "Failed to load revenue data");
      }
    }

    fetchRevenueData();
  }, [selectedPeriod, token]);

  //! Fetch Pie Chart Data (Premium vs Free)

  useEffect(() => {
    async function fetchTrafficData() {
      try {
        const res = await fetch(`${ env.NEXT_PUBLIC_API_URL }/users/count-total-data`, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${ token }`,
            "Content-Type": "application/json",
          },
        });

        if (!res.ok) throw new Error(`HTTP error! status: ${ res.status }`);

        const json = await res.json();
        console.log("Parsed JSON result:", json);

        const stats = json?.data?.data;

        if (stats) {
          const premiumPercentage = parseFloat(stats.premiumPercentage?.replace("%", "")) || 0;
          const freePercentage = parseFloat(stats.freePercentage?.replace("%", "")) || 0;

          setTrafficData([
            {
              name: "Premium Users",
              value: premiumPercentage,
              percentage: premiumPercentage,
              color: "#02CCD8",
            },
            {
              name: "Free Users",
              value: freePercentage,
              percentage: freePercentage,
              color: "#f59e0b",
            },
          ]);
        } else {
          toast.error("No data found for PieChart");
        }
      } catch (error: any) {
        console.error("Error fetching traffic data:", error);
        toast.error(error.message || "Failed to load traffic data");
      }
    }

    fetchTrafficData();
  }, [token]);

  return (
    <div className="space-y-6">
      {/* Metrics Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        <AnimatePresence mode="wait">
          {loading ? (
            Array(4)
              .fill(0)
              .map((_, i) => (
                <motion.div
                  key={`skeleton-${ i }`}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                  className="flex flex-col gap-3 p-5 rounded-2xl bg-[#0f172a]/60 border border-gray-800 animate-pulse"
                >
                  <Skeleton className="h-8 w-8 rounded-full bg-gray-700" />
                  <Skeleton className="h-4 w-24 bg-gray-700" />
                  <Skeleton className="h-6 w-16 bg-gray-700" />
                </motion.div>
              ))
          ) : (
            metrics.map((metric, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{
                  duration: 0.4,
                  delay: index * 0.1,
                  ease: "easeOut",
                }}
              >
                <MetricCard
                  title={metric.title}
                  value={metric.value}
                  icon={metric.icon}
                  url={metric.url}
                />
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>

      {/* ✅ Charts Section */}
      <div className="flex flex-col xl:flex-row lg:flex-col gap-6">
        <div className="flex-1 xl:basis-2/3 basis-full flex flex-col">
          <RevenueBarChart
            weeklyData={revenueData.weekly}
            monthlyData={revenueData.monthly}
            yearlyData={revenueData.yearly}
            period={selectedPeriod}
            onPeriodChange={setSelectedPeriod}
            periods={periods}
          />
        </div>

        {/* ✅ Only this part updated to use API data */}
        <div className="flex-1 lg:basis-1/3 flex flex-col">
          <TrafficPieChart
            data={trafficData.length > 0 ? trafficData : []}
            title="Traffic by User Plan"
          />
        </div>
      </div>
    </div>
  );
}

