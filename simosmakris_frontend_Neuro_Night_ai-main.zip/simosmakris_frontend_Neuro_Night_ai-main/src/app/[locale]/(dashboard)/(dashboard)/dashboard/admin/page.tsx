"use client"

import { Suspense } from "react"
import { useAuth } from "@/components/AuthProvider"
import DashboardCardPage from "./_component/DashboardCard"


export default function AdminDashboardPage() {
  const { token } = useAuth()


  if (!token) return <p className="text-center mt-10 text-red-600">No access token</p>

  return (
    <div className=" bg-transparent">
      <div className="mx-auto p-6 space-y-6">
        {/* {loadingStats && <p className="text-center mt-10 text-muted-foreground">Loading dashboard stats...</p>} */}

        {/* {errorStats && <p className="text-center mt-10 text-destructive">{errorStats}</p>} */}

        <div className="lg:flex gap-10">
          <div className="space-y-6 flex-1">
            <Suspense fallback={<p className="text-center text-muted-foreground">Loading dashboard...</p>}>
              <DashboardCardPage />
            </Suspense>
          </div>
        </div>
      </div>
    </div>
  )
}
