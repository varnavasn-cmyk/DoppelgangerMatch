/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import React, { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/components/AuthProvider";

interface Plan {
  id: string;
  planName: string;
  amount: number;
}

const CreatePlanForm = () => {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [selectedPlanId, setSelectedPlanId] = useState("");
  const [openDropdown, setOpenDropdown] = useState(false);
  const [price, setPrice] = useState("");
  // const [discountPrice, setDiscountPrice] = useState('');
  const [loading, setLoading] = useState(false);

  const user = useAuth();

  // 🔹 Fetch all plans on mount
  useEffect(() => {
    const fetchPlans = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/plans`);
        const data = await res.json();
        if (data.success) {
          setPlans(data.data);
        } else {
          toast.error(data.message || "Failed to fetch plans");
        }
      } catch (error) {
        console.error(error);
        toast.error("Something went wrong while fetching plans!");
      }
    };

    fetchPlans();
  }, []);

  // 🔹 Submit Handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedPlanId) {
      toast.error("Please select a plan!");
      return;
    }

    if (!price.trim()) {
      toast.error("Price is required!");
      return;
    }

    const numericPrice = Number(price);

    if (isNaN(numericPrice) || numericPrice <= 0) {
      toast.error("Please enter a valid price!");
      return;
    }

    try {
      setLoading(true);

      const payload: Record<string, any> = {
        amount: numericPrice,
      };

      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/plans/${selectedPlanId}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${user?.token}`,
          },
          body: JSON.stringify(payload),
        }
      );

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data?.message || "Update failed!");
      }

      toast.success("Plan updated successfully!");
      console.log("Updated Plan:", data.data);

      // reset
      setPrice("");
      setSelectedPlanId("");
      window.location.reload();
    } catch (error: any) {
      console.error(error);
      toast.error(error.message || "Failed to update plan!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-h-screen w-full items-start p-6">
      <div className="w-full rounded-xl bg-[#121A2E] space-y-6 shadow-2xl p-4">
        {/* 🔹 Plan Name Dropdown */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2 relative">
            <label className="md:text-xl text-lg font-medium text-white">
              Plan Name
            </label>
            <button
              type="button"
              onClick={() => setOpenDropdown(!openDropdown)}
              className="w-full bg-[#1A223A] border-none text-white 
                focus-visible:ring-1 focus-visible:ring-teal-400 
                rounded-md px-3 py-2 flex justify-between items-center"
            >
              {selectedPlanId
                ? plans.find((p) => p.id === selectedPlanId)?.planName
                : "Select Plan"}
              <ChevronDown
                className={`ml-2 transform transition-transform duration-300 ${
                  openDropdown ? "rotate-180" : "rotate-0"
                }`}
                size={18}
              />
            </button>

            {/* 🔹 Dropdown List */}
            <div
              className={`absolute z-10 w-full bg-[#1A223A] rounded-md shadow-lg 
                transition-all duration-300 origin-top
                ${
                  openDropdown
                    ? "max-h-60 opacity-100 scale-100"
                    : "max-h-0 opacity-0 scale-95"
                } overflow-hidden`}
            >
              {plans.map((plan) => (
                <div
                  key={plan.id}
                  onClick={() => {
                    setSelectedPlanId(plan.id);
                    setPrice(plan.amount.toString());
                    setOpenDropdown(false);
                  }}
                  className="px-4 py-2 text-white hover:bg-teal-600 cursor-pointer"
                >
                  {plan.planName}
                </div>
              ))}
            </div>
          </div>

          {/* 🔹 Price Input */}
          <div className="space-y-2">
            <label
              htmlFor="price"
              className="md:text-xl text-lg font-medium text-white"
            >
              Price ($)
            </label>
            <Input
              id="price"
              type="text"
              inputMode="decimal"
              value={price}
              onChange={(e) => setPrice(e.target.value.replace(/[^\d.]/g, ""))}
              placeholder="Enter Price"
              className="bg-[#1A223A] border-none text-white placeholder:text-gray-400 
              focus-visible:ring-1 focus-visible:ring-teal-400"
            />
          </div>
        </div>

        {/* 🔹 Submit */}
        <div className="pt-2">
          <Button
            onClick={handleSubmit}
            disabled={loading}
            className="bg-[#00FFFF99] hover:bg-[#00FFFF99] font-extrabold text-white px-6 py-2 rounded-lg"
          >
            {loading ? "Updating..." : "Submit"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CreatePlanForm;
