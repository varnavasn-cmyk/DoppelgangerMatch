/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import { useTransition, useState } from "react";
import { useRouter } from "next/navigation";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import DeleteModal from "@/components/shared/DeleteModal";
import { deleteBlogAction } from "@/app/[locale]/api/blog/delete/deleteBlog";

type DeleteButtonProps = {
  id: string;
};

export default function DeleteButton({ id }: DeleteButtonProps) {
  const router = useRouter();
  const [isOpen, setIsOpen] = useState(false);
  const [isPending, startTransition] = useTransition();

  const handleDelete = () => {
    startTransition(async () => {
      try {
        const res = await deleteBlogAction(id);
        toast.success(res.message || "Blog deleted successfully");
        router.refresh();
        setIsOpen(false);
      } catch (error: any) {
        toast.error(error.message || "Failed to delete blog");
      }
    });
  };

  return (
    <>
      <Button
        size="lg"
        variant="ghost"
        onClick={() => setIsOpen(true)}
        disabled={isPending}
      >
        <Trash2 className="text-red-500 size-6" />
      </Button>

      <DeleteModal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onConfirm={handleDelete}
      />
    </>
  );
}
