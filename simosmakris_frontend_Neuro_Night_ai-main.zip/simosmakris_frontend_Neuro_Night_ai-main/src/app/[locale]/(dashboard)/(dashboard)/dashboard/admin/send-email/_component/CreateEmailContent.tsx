/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import React, { useRef, useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import JoditEditor from "jodit-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/components/AuthProvider";
import { env } from "@/env";
import { joditConfig } from "../../../../../../../../../config/jodit-config";

const CreateEmailContent = () => {
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const editor = useRef<any>(null);

  // ✅ Save form data to localStorage so user doesn’t lose progress
  useEffect(() => {
    const formData = {
      subject,
      message,
    };
    localStorage.setItem("emailFormData", JSON.stringify(formData));
  }, [subject, message]);

  // ✅ Load saved data when page reloads
  useEffect(() => {
    const savedData = localStorage.getItem("emailFormData");
    if (savedData) {
      const parsed = JSON.parse(savedData);
      setSubject(parsed.subject || "");
      setMessage(parsed.message || "");
    }
  }, []);

  const { token } = useAuth();
  if (!token) {
    toast.error("Authorization token not found!");
    setIsSubmitting(false);
    return;
  }
  const handleSubmit = async () => {
    if (!subject || !message) {
      toast.error("Subject and message are required!");
      return;
    }

    setIsSubmitting(true);

    try {
      const res = await fetch(
        `${env.NEXT_PUBLIC_API_URL}/subscriber/send-promotion-email`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            subject,
            message,
          }),
        }
      );

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data?.message || "Something went wrong!");
      }

      toast.success(data.message || "Promotion email sent successfully!");
      localStorage.removeItem("emailFormData");
      setSubject("");
      setMessage("");
    } catch (error: any) {
      console.error("❌ Error:", error);
      toast.error(error.message || "Failed to send email!");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-h-screen w-full items-start">
      <div className="w-full rounded-xl space-y-6 shadow-2xl p-6">
        {/* Email Subject */}
        <div className="space-y-2 bg-[#121A2E]">
          <Input
            id="emailSubject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="Enter your email subject"
            className="bg-[#1A223A] border-none text-white placeholder:text-gray-400 focus-visible:ring-1 focus-visible:ring-teal-400"
          />
        </div>

        {/* Email Body */}
        <div className="space-y-2">
          <JoditEditor
            ref={editor}
            value={message}
            config={joditConfig}
            onBlur={(newContent) => setMessage(newContent)}
            onChange={(newContent) => setMessage(newContent)}
            className="text-black"
          />
        </div>

        {/* Submit */}
        <div className="flex justify-end pb-4">
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="bg-teal-500 hover:bg-teal-600 text-white px-6 py-2 rounded-xl"
          >
            {isSubmitting ? "Sending..." : "Send Email"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CreateEmailContent;
