"use client";

import { usePrefixedPath } from "@/lib/localePath";
import { cn } from "@/lib/utils";
import Link from "next/link";
import { usePathname } from "next/navigation";

type ActiveLinkProps = {
  exact?: boolean;
} & React.ComponentProps<"a">;

export default function DashboardActiveLink({
  href = "",
  className,
  children,
}: ActiveLinkProps) {
  const pathname = usePathname();
  const isActive = pathname === href;
  const getPrefixedPath = usePrefixedPath();

  return (
    <Link
      href={getPrefixedPath(href)}
      className={cn(
        "block w-full text-sm hover:bg-white rounded whitespace-nowrap truncate",
        isActive && "is-active-link bg-white !text-black",
        className
      )}
      prefetch
    >
      {children}
    </Link>
  );
}
