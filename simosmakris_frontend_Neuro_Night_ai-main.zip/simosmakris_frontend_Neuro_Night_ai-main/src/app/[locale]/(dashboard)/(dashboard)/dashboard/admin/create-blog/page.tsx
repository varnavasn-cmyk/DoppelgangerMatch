import React from 'react';
import CreateBlogContentPage from './_component/CreateBlogContent';

const CreateBlogPage = () => {
  return (
    <div>
      <CreateBlogContentPage />
    </div>
  );
};

export default CreateBlogPage;