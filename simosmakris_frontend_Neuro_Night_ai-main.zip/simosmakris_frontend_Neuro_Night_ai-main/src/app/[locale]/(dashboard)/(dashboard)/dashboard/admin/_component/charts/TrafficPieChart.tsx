/* eslint-disable @typescript-eslint/no-explicit-any */
"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from "recharts"

interface TrafficData {
  name: string
  value: number
  percentage: number
  color: string
}

interface TrafficPieChartProps {
  data: TrafficData[]
  title?: string
}

const CustomLegend = ({ payload }: any) => {
  return (
    <div className="flex flex-col gap-2 mt-4">
      {payload?.map((entry: any, index: number) => (
        <div key={index} className="flex items-center justify-between text-sm w-10/12 mx-auto">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
            <span className="text-foreground">{entry.value}</span>
          </div>
          <span className="text-foreground font-medium">{entry.payload.percentage}%</span>
        </div>
      ))}
    </div>
  )
}

export function TrafficPieChart({ data, title = "Traffic by User Plan" }: TrafficPieChartProps) {
  return (
    <Card className="bg-white/10 border-white/10 [box-shadow:10px_0_20px_0_rgba(2,204,216,0.05)] h-full">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-foreground">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={data} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="value">
                {data.map((entry, index) => (
                  <Cell key={`cell-${ index }`} fill={entry.color} />
                ))}
              </Pie>
              <Legend content={<CustomLegend />} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}

