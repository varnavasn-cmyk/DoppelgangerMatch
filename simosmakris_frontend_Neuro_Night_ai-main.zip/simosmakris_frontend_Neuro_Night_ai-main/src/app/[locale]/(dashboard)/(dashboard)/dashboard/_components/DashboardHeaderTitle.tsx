import Heading from "@/components/Heading";


export default function DashboardHeaderTitle({
  children,
}: React.PropsWithChildren) {
  return (
    <Heading as="h2" size="h5" className="capitalize">
      <div className="truncate w-30 md:w-52 lg:w-fit text-white">{children}</div>
    </Heading>
  );
}
