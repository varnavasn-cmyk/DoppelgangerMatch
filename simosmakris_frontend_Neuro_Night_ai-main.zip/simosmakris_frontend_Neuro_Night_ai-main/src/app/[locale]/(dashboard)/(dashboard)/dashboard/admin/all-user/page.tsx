import React from 'react';
import AllUserContainerPage from './_components/AllUserContainer';

type AllUserProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}

const AllUserPage = async ({ searchParams }: AllUserProps) => {
  const resolvedParams = await searchParams;
  return <AllUserContainerPage searchParams={resolvedParams} />;
};

export default AllUserPage;