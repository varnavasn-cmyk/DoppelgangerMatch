import React from 'react';
import CreateEmailContent from './_component/CreateEmailContent';

const SendEmailPage = () => {
  return (
    <div>
      <CreateEmailContent />
    </div>
  );
};

export default SendEmailPage;