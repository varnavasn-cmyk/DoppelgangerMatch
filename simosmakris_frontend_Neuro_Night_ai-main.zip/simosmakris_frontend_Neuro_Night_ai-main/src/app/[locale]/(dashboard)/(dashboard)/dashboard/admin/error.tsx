"use client";
export { default } from "@/components/ErrorPage";
