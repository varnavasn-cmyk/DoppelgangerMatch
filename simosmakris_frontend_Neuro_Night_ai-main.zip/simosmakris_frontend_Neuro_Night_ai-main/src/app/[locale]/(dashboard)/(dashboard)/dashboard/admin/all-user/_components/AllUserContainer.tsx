import Pagination from "@/components/shared/table/components/Pagination";
import {
  Table,
  TableBody,
  TableBodyItem,
  TableHeader,
  TableHeaderItem,
  TableRow,
} from "@/components/shared/table/components/Table";
import fetchTableData from "@/components/shared/table/lib/fetchTableData";
import sortTableData from "@/components/shared/table/lib/sortTableData";
import { SortDirection } from "@/components/shared/table/types/table.type";
import {
  DEFAULT_ITEMS_PER_PAGE,
  DEFAULT_PAGE,
} from "@/components/shared/table/utils/constant";
import { env } from "@/env";
import { getAccessToken } from "@/lib/auth";
import Image from "next/image";
import UserDeleteButton from "./UserDeleteButton";

// -------------------- API Types --------------------
type User = {
  id: string;
  email: string;
  fullName: string;
  profilePic: string;
  role: string;
  isSubscribed: boolean;
};

type ApiMeta = {
  page: number;
  limit: number;
  total: number;
  totalPage: number;
};

type UsersApiResponse = {
  success: boolean;
  message: string;
  meta: ApiMeta;
  data: User[];
};

// -------------------- Table Types --------------------
type UserTableRow = {
  id: string;
  profilePic: string;
  fullName: string;
  email: string;
  role: string;
  isSubscribed: string;
};

type TableHeader = {
  key: keyof UserTableRow;
  label: string;
};

type SearchParams = {
  page?: string;
  limit?: string;
  sort?: string;
  q?: string;
};

// -------------------- Helpers --------------------
function parseSearchParams(params: SearchParams): {
  page: number;
  limit: number;
  sortField: string;
  sortDirection: SortDirection;
  q?: string;
} {
  const page = Number(params.page) || DEFAULT_PAGE;
  const limit = Number(params.limit) || DEFAULT_ITEMS_PER_PAGE;
  const [sortField = "", sortDirection = ""] = (params.sort || "").split(":");

  return {
    page,
    limit,
    sortField,
    sortDirection: sortDirection as SortDirection,
    q: params?.q,
  };
}

function normalizeUserData(rows: User[]): UserTableRow[] {
  return rows.map((row) => ({
    id: row.id,
    profilePic: row.profilePic,
    fullName: row.fullName,
    email: row.email,
    role: row.role,
    isSubscribed: row.isSubscribed ? "Yes" : "No",
  }));
}

// -------------------- Component --------------------
export default async function AllUserContainerPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const resolvedSearchParams = searchParams;
  const token = await getAccessToken();

  const { page, limit, sortField, sortDirection, q } =
    parseSearchParams(resolvedSearchParams);

  const queryString = new URLSearchParams({
    page: page.toString(),
    limit: limit.toString(),
    ...(q && { q }),
  }).toString();

  const response = await fetchTableData<UsersApiResponse>(
    `${ env.API_BASE_URL }/users?${ queryString }`,
    { headers: { Authorization: token || "" } }
  );

  const apiResponse = Array.isArray(response) ? response[0] : response;

  if (!apiResponse?.data?.length) {
    return <div>No users found</div>;
  }

  const tableDataRaw: User[] = apiResponse.data;
  const meta: ApiMeta = apiResponse.meta;

  const normalizedData: UserTableRow[] = normalizeUserData(tableDataRaw);

  const tableHeader: readonly TableHeader[] = [
    { key: "profilePic", label: "Profile" },
    { key: "fullName", label: "Full Name" },
    { key: "email", label: "Email" },
    { key: "role", label: "Role" },
    { key: "isSubscribed", label: "Subscribed" },
  ] as const;

  const sorted: UserTableRow[] = sortTableData(
    normalizedData,
    sortField as keyof UserTableRow,
    sortDirection
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold">All Users</h2>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            {tableHeader.map(({ key }) => (
              <TableHeaderItem
                key={key}
                prop={key}
                currentSort={sortField}
                sortDirection={sortDirection}
              />
            ))}
            <th>Action</th>
          </TableRow>
        </TableHeader>

        <TableBody>
          {sorted.length > 0 ? (
            sorted.map((item: UserTableRow) => (
              <TableRow key={item.id}>
                {tableHeader.map(({ key }) => (
                  <TableBodyItem key={key}>
                    {key === "profilePic" ? (
                      item.profilePic ? (
                        <Image
                          src={item.profilePic}
                          alt={item.fullName}
                          width={60}
                          height={60}
                          className="rounded-full object-cover"
                          unoptimized
                        />
                      ) : (
                        <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center text-sm text-gray-500">
                          N/A
                        </div>
                      )
                    ) : (
                      item[key] ?? "N/A"
                    )}
                  </TableBodyItem>
                ))}
                <td>
                  <UserDeleteButton id={item.id} />
                </td>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableBodyItem colSpan={tableHeader.length + 1}>
                <div className="text-center py-6 text-gray-500">
                  No Data Found
                </div>
              </TableBodyItem>
            </TableRow>
          )}
        </TableBody>
      </Table>

      <Pagination
        totalPages={meta.totalPage}
        currentPage={page}
        pageSize={limit}
      />
    </div>
  );
}
