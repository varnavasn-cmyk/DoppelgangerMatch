import React from 'react';

const UserLookalikePage = () => {
  return (
    <div>
      <h1>User Lookalike</h1>
    </div>
  );
};

export default UserLookalikePage;