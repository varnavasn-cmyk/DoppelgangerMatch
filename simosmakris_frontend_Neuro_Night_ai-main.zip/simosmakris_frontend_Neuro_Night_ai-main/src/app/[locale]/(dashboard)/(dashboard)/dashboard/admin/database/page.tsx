import { Card } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

const DatabasePage = () => {
  return (
    <div className="max-h-screen bg-slate-900 flex p-6">
      {/* Main Content */}
      <div className="flex-1">

        {/* Main Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Lookalike Photo Card */}
          <Link href="/dashboard/admin/database/lookalike-photo">
            <Card className="bg-white/10 border-white/10 [box-shadow:10px_0_20px_0_rgba(2,204,216,0.05)] min-h-[300px] flex items-center justify-center relative">
              <h2 className="text-lg md:text-xl lg:text-2xl xl:text-3xl font-semibold text-white text-center">Normal People Lookalike Photo</h2>
            </Card>
          </Link>

          {/* Celebrity Lookalike Photo Card */}
          <Link href="/dashboard/admin/database/celebrity-lookalike">
            <Card className="bg-white/10 border-white/10 [box-shadow:10px_0_20px_0_rgba(2,204,216,0.05)] min-h-[300px] flex items-center justify-center relative">
              <h2 className="text-lg md:text-xl lg:text-2xl xl:text-3xl  font-semibold text-white text-center">Celebrity People Lookalike Photo</h2>
            </Card>
          </Link>
        </div>

        {/* Connection Arrow */}
        <div className="flex justify-center my-8">
          <div className="flex items-center gap-4">
            <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center">
              <div className="w-3 h-3 bg-white rounded-full"></div>
            </div>
            <div className="w-16 h-px bg-slate-600"></div>
            <ArrowRight className="text-slate-400 w-5 h-5" />
            <div className="w-16 h-px bg-slate-600"></div>
            <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center">
              <div className="w-3 h-3 bg-white rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default DatabasePage
