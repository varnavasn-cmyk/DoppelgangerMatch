import { requireAuth } from "@/lib/auth";
import {
  DashboardHeader,
  DashboardLayout,
  DashboardSidebar,
  SidebarProvider,
} from "../_components";
import { dashboardNavigation } from "@/data/dashboardNavbar";
// import { redirect } from "next/navigation";
// import { unauthorizedPath } from "@/paths";
import SidebarContent from "../_components/DashboardSidebarContent";

export default async function AdminDashboardLayout({
  children,
}: React.PropsWithChildren) {

  const data = await requireAuth();
  const userRole = data?.data.role || { role: "" };
  console.log("userRole: ", userRole);

  // if (userRole !== "SUPER_ADMIN" || "ADMIN") return redirect(unauthorizedPath());

  return (
    <>
      <SidebarProvider>
        <DashboardLayout
          header={<DashboardHeader />}
          sidebar={
            <DashboardSidebar>
              <SidebarContent
                mainItems={dashboardNavigation.admin}
              />
            </DashboardSidebar>
          }
        >
          <div className="mt-4">{children}</div>
        </DashboardLayout>
      </SidebarProvider>
    </>
  );
}
