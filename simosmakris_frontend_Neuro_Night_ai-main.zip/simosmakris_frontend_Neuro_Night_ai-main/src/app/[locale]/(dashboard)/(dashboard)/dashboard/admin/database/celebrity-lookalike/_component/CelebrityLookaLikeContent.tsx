"use client";

import React, { useState, useMemo, useEffect } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import {
  Trash2,
  CloudUpload,
  X,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { toast } from "sonner";
import CelebrityLookaLikeImageUploadPopup from "./CelebrityLookaLikeImageUploadPopup";
import CelebrityDeleteConfirmModal from "./CelebrityDeleteConfirmModal";
import { deleteCelebrityImagesAction } from "@/app/[locale]/api/celebrity/celebrity-database/delete/deleteCelebrityImage";

interface ImageItem {
  key: string;
  imageUrl: string;
  filename: string;
  size: number;
  lastModified: string;
}

interface Props {
  images: ImageItem[];
}

const CelebrityLookaLikeContent: React.FC<Props> = ({
  images: initialImages,
}) => {
  const router = useRouter(); // Added: Get router instance for refresh

  const [images, setImages] = useState<ImageItem[]>(initialImages);
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [selectMode, setSelectMode] = useState(false);

  // Added: Sync local state with props when initialImages changes (e.g., after refresh)
  useEffect(() => {
    setImages(initialImages);
  }, [initialImages]);

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(20);

  // Calculate paginated images
  const paginatedImages = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return images.slice(startIndex, endIndex);
  }, [images, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(images.length / itemsPerPage);

  const handleToggleSelectMode = () => {
    if (selectMode) {
      setSelectedImages([]);
    }
    setSelectMode((prev) => !prev);
  };

  const toggleSelect = (key: string) => {
    setSelectedImages((prev) =>
      prev.includes(key) ? prev.filter((id) => id !== key) : [...prev, key]
    );
  };

  // Select all images on current page
  const handleSelectAll = () => {
    const currentPageKeys = paginatedImages.map((img) => img.key);
    const allSelected = currentPageKeys.every((key) =>
      selectedImages.includes(key)
    );

    if (allSelected) {
      // Deselect all on current page
      setSelectedImages((prev) =>
        prev.filter((key) => !currentPageKeys.includes(key))
      );
    } else {
      // Select all on current page
      setSelectedImages((prev) => {
        const newSelection = [...prev];
        currentPageKeys.forEach((key) => {
          if (!newSelection.includes(key)) {
            newSelection.push(key);
          }
        });
        return newSelection;
      });
    }
  };

  const handleDelete = () => {
    if (selectedImages.length === 0) {
      toast.error("No images selected for deletion!");
      return;
    }
    setIsConfirmOpen(true);
  };

  const confirmDelete = async () => {
    const previousImages = [...images];
    setImages((prev) =>
      prev.filter((img) => !selectedImages.includes(img.key))
    );
    setSelectedImages([]);
    setIsConfirmOpen(false);

    // Adjust current page if needed
    const newTotalPages = Math.ceil(
      (images.length - selectedImages.length) / itemsPerPage
    );
    if (currentPage > newTotalPages && newTotalPages > 0) {
      setCurrentPage(newTotalPages);
    }

    try {
      await deleteCelebrityImagesAction(selectedImages);
      toast.success("Selected images deleted successfully!");
    } catch (error) {
      console.error(error);
      toast.error("Failed to delete images! Restoring previous state...");
      setImages(previousImages);
    }
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleItemsPerPageChange = (value: number) => {
    setItemsPerPage(value);
    setCurrentPage(1);
  };

  // Check if all images on current page are selected
  const allCurrentPageSelected = useMemo(() => {
    const currentPageKeys = paginatedImages.map((img) => img.key);
    return (
      currentPageKeys.length > 0 &&
      currentPageKeys.every((key) => selectedImages.includes(key))
    );
  }, [paginatedImages, selectedImages]);

  // Added: Callback to refresh data after successful upload
  const handleUploadSuccess = () => {
    router.refresh();
  };

  return (
    <div className="relative pb-24">
      {/* --------- Desktop Buttons --------- */}
      <div className="absolute -top-[90px] right-0 z-50 hidden md:flex items-center gap-4">
        {selectMode && (
          <button
            className="px-4 py-2 rounded-lg cursor-pointer transition-colors bg-[#00FFFF]/10 hover:bg-[#00FFFF]/20 text-[#00FFFF]"
            onClick={handleSelectAll}
          >
            {allCurrentPageSelected ? "Deselect All" : "Select All"}
          </button>
        )}

        <button
          className={`px-4 py-2 rounded-lg cursor-pointer transition-colors ${
            selectMode
              ? "bg-red-500/20 hover:bg-red-500/30"
              : "bg-[#00FFFF]/10 hover:bg-[#00FFFF]/20"
          }`}
          onClick={handleToggleSelectMode}
        >
          <Trash2
            className={`w-6 h-6 ${
              selectMode ? "text-red-500" : "text-red-400"
            }`}
          />
        </button>

        <button
          className="flex items-center gap-1 text-white px-4 py-2 bg-[#00FFFFB2] hover:bg-[#00FFFFB2]/90 rounded-lg cursor-pointer"
          onClick={() => setIsOpen(true)}
        >
          <CloudUpload className="w-6 h-6" /> Upload
        </button>

        {/* <button
          className="flex items-center gap-1 text-white px-4 py-2 bg-[#00FFFFB2] hover:bg-[#00FFFFB2]/90 rounded-lg cursor-pointer"
          onClick={() => console.log('download')}
        >
          <CloudDownload className="w-6 h-6" /> Download
        </button> */}
      </div>

      {/* --------- Mobile Menu Button --------- */}
      <div className="absolute -top-[90px] right-0 z-50 md:hidden">
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="bg-gray-800 hover:bg-gray-700 text-white p-2 rounded"
        >
          {isMenuOpen ? (
            <X className="w-6 h-6" />
          ) : (
            <svg
              className="h-6 w-6"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          )}
        </button>

        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              key="menu"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.25 }}
              className="absolute right-0 mt-2 w-40 bg-[#0b1120] shadow-lg rounded-lg p-2 flex flex-col gap-2"
            >
              {selectMode && (
                <button
                  className="flex items-center gap-2 text-white bg-[#00FFFF]/10 hover:bg-[#00FFFF]/20 px-4 py-2 rounded-lg cursor-pointer"
                  onClick={handleSelectAll}
                >
                  {allCurrentPageSelected ? "Deselect" : "Select All"}
                </button>
              )}

              <button
                className="flex items-center gap-2 text-white bg-[#00FFFF]/10 hover:bg-[#00FFFF]/20 px-4 py-2 rounded-lg cursor-pointer"
                onClick={handleToggleSelectMode}
              >
                <Trash2 className="text-red-500" /> Delete
              </button>

              <button
                className="flex items-center gap-1 text-white px-4 py-2 bg-[#00FFFFB2] hover:bg-[#00FFFFB2]/90 rounded-lg cursor-pointer"
                onClick={() => setIsOpen(true)}
              >
                <CloudUpload className="w-6 h-6" /> Upload
              </button>

              {/* <button
                className="flex items-center gap-1 text-white px-4 py-2 bg-[#00FFFFB2] hover:bg-[#00FFFFB2]/90 rounded-lg cursor-pointer"
                onClick={() => console.log('download')}
              >
                <CloudDownload className="w-6 h-6" /> Download
              </button> */}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* --------- Pagination Info & Images Per Page --------- */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-4">
        <div className="text-white text-sm">
          Showing{" "}
          {paginatedImages.length > 0
            ? (currentPage - 1) * itemsPerPage + 1
            : 0}{" "}
          - {Math.min(currentPage * itemsPerPage, images.length)} of{" "}
          {images.length} images
        </div>

        <div className="flex items-center gap-2">
          <label className="text-white text-sm">Images per page:</label>
          <select
            value={itemsPerPage}
            onChange={(e) => handleItemsPerPageChange(Number(e.target.value))}
            className="bg-[#0b1120] text-white border border-gray-700 rounded px-3 py-1 text-sm cursor-pointer"
          >
            <option value={10}>10</option>
            <option value={20}>20</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
            <option value={500}>500</option>
          </select>
        </div>
      </div>

      {/* --------- Image Grid --------- */}

      {paginatedImages.length === 0 ? (
        <div>
          <h1 className="text-2xl text-center text-white">No images found</h1>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          <AnimatePresence mode="popLayout">
            {paginatedImages.map((img) => (
              <motion.div
                key={img.key}
                layout
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.3 }}
                className={`relative rounded-xl overflow-hidden border ${
                  selectedImages.includes(img.key)
                    ? "border-[#00FFFFB2]"
                    : "border-transparent"
                }`}
              >
                {selectMode && (
                  <button
                    onClick={() => toggleSelect(img.key)}
                    className="absolute top-2 right-2 bg-black/50 p-1 rounded z-10"
                  >
                    {selectedImages.includes(img.key) ? (
                      <div className="w-5 h-5 bg-[#00FFFF] rounded-sm" />
                    ) : (
                      <div className="w-5 h-5 border border-white rounded-sm" />
                    )}
                  </button>
                )}

                <Image
                  src={img.imageUrl}
                  alt={img.filename}
                  width={200}
                  height={200}
                  className="w-full h-52 object-cover"
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* --------- Pagination Controls --------- */}
      {totalPages > 1 && (
        <div className="flex justify-center items-center gap-2 mt-8">
          <button
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="p-2 rounded-lg bg-[#00FFFF]/10 hover:bg-[#00FFFF]/20 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-[#00FFFF]" />
          </button>

          <div className="flex gap-2">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => {
              // Show first page, last page, current page, and pages around current
              if (
                page === 1 ||
                page === totalPages ||
                (page >= currentPage - 1 && page <= currentPage + 1)
              ) {
                return (
                  <button
                    key={page}
                    onClick={() => handlePageChange(page)}
                    className={`px-4 py-2 rounded-lg transition-colors ${
                      currentPage === page
                        ? "bg-[#00FFFFB2] text-white"
                        : "bg-[#00FFFF]/10 text-[#00FFFF] hover:bg-[#00FFFF]/20"
                    }`}
                  >
                    {page}
                  </button>
                );
              } else if (page === currentPage - 2 || page === currentPage + 2) {
                return (
                  <span key={page} className="px-2 text-gray-500">
                    ...
                  </span>
                );
              }
              return null;
            })}
          </div>

          <button
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className="p-2 rounded-lg bg-[#00FFFF]/10 hover:bg-[#00FFFF]/20 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronRight className="w-5 h-5 text-[#00FFFF]" />
          </button>
        </div>
      )}

      {/* -------- Floating Delete Button -------- */}
      <AnimatePresence>
        {selectMode && selectedImages.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            transition={{ duration: 0.25 }}
            className="fixed bottom-6 right-6 flex items-center gap-3 bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-full shadow-lg cursor-pointer z-50"
            onClick={handleDelete}
          >
            <span>({selectedImages.length}) Delete</span>
            <Trash2 className="w-5 h-5" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* -------- Upload Popup -------- */}
      <CelebrityLookaLikeImageUploadPopup
        open={isOpen}
        onClose={() => setIsOpen(false)}
        onUploadSuccess={handleUploadSuccess}
      />

      {/* -------- Confirmation Modal -------- */}
      <CelebrityDeleteConfirmModal
        open={isConfirmOpen}
        onClose={() => setIsConfirmOpen(false)}
        onConfirm={confirmDelete}
      />
    </div>
  );
};

export default CelebrityLookaLikeContent;
