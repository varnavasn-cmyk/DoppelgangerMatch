/* eslint-disable @typescript-eslint/no-explicit-any */


'use client';

import React, { useRef, useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { UploadCloudIcon, X } from 'lucide-react';
import JoditEditor from 'jodit-react';
import { joditConfig } from '../../../../../../../../../config/jodit-config';
import Image from 'next/image';

const CreateBlogContentPage = () => {
  const [thumbnail, setThumbnail] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const editor = useRef<any>(null);

  // Save form data in localStorage whenever it changes
  useEffect(() => {
    const formData = {
      title,
      description,
      image: thumbnail ? URL.createObjectURL(thumbnail) : null,
    };
    localStorage.setItem('blogFormData', JSON.stringify(formData));
  }, [title, description, thumbnail]);

  // Remove thumbnail
  const handleRemoveThumbnail = () => {
    setThumbnail(null);
    toast.info('Thumbnail removed!');
  };

  // ✅ API integration

  console.log(thumbnail, "image file");
  const handleSubmit = async () => {
    if (!title || !description) {
      toast.error("Title and description are required!");
      return;
    }

    if (!thumbnail) {
      toast.error("Thumbnail is required!");
      return;
    }

    setIsSubmitting(true);

    try {
      const formData = new FormData();
      const memorialData = {
        title: title,
        description: description,
      };

      formData.append("data", JSON.stringify(memorialData));
      formData.append("file", thumbnail);

      const res = await fetch("/api/create-blog", {
        method: "POST",
        body: formData,
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data?.message || "Something went wrong!");
      }

      toast.success(data.message || "Blog created successfully!");
      localStorage.removeItem("blogFormData");
      setTitle("");
      setDescription("");
      setThumbnail(null);
    } catch (error: any) {
      console.error("❌ Error:", error);
      toast.error(error.message || "Failed to create blog!");
    } finally {
      setIsSubmitting(false);
    }
  };


  return (
    <div className="max-h-screen w-full  items-start">
      <div className="w-full rounded-xl space-y-6 shadow-2xl p-6">

        {/* Title */}
        <div className="space-y-2 bg-[#121A2E]">
          <Input
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Enter your blog title"
            className="bg-[#1A223A] border-none text-white placeholder:text-gray-400 focus-visible:ring-1 focus-visible:ring-teal-400"
          />
        </div>

        {/* Description */}
        <div className="space-y-2">
          <JoditEditor
            ref={editor}
            value={description}
            config={joditConfig}
            onBlur={(newContent) => setDescription(newContent)}
            onChange={(newContent) => setDescription(newContent)}
            className="text-black"
          />
        </div>

        {/* Thumbnail upload */}
        <div className="flex flex-col space-y-2">
          <div className="flex items-center gap-4">
            {!thumbnail && (
              <label className="cursor-pointer bg-teal-500 hover:bg-teal-600 text-white px-4 py-2 rounded-xl flex items-center gap-2">
                <UploadCloudIcon size={24} />
                <span>Upload Thumbnail</span>
                <input
                  type="file"
                  name="thumbnail"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => setThumbnail(e.target.files?.[0] || null)}
                />
              </label>
            )}
          </div>

          {/* Image Preview */}
          {thumbnail && (
            <div className="relative w-32 h-32 mt-2">
              <Image
                src={URL.createObjectURL(thumbnail)}
                alt="Thumbnail Preview"
                className="h-full w-full object-cover rounded-md border border-gray-600"
                width={200}
                height={200}
              />
              {/* Remove button */}
              <button
                type="button"
                onClick={handleRemoveThumbnail}
                className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
              >
                <X size={16} />
              </button>
            </div>
          )}
        </div>

        {/* Submit */}
        <div className="flex justify-end pb-4">
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="bg-teal-500 hover:bg-teal-600 text-white px-6 py-2 rounded-xl"
          >
            {isSubmitting ? 'Submitting...' : 'Create Post'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CreateBlogContentPage;
