"use client";

import { ChevronsRight, LogOut } from "lucide-react";
import { motion } from "framer-motion";
// import React, { createElement } from "react";
import React from "react";
import { cn } from "@/lib/utils";
import { useSidebar } from "./SidebarProvider";
import Logo from "@/components/Logo";
import { persistor } from "@/redux/store";


export default function Sidebar({ children }: React.PropsWithChildren) {
  const { handlePointerEnter, handlePointerLeave, isCollapsedSidebar } =
    useSidebar();

  return (
    <motion.nav
      className={cn(
        "h-screen flex flex-col common_dashboard_bg_color gap-4 z-[60] sticky top-0 whitespace-nowrap border-r border-r-common_dashboard_bg_color-100 [box-shadow:10px_0_20px_0_rgba(2,204,216,0.04)]"
      )}
      style={{
        width: isCollapsedSidebar
          ? "var(--_sidebar-collapsed)"
          : "var(--_sidebar-expanded)",
      }}
      animate={{
        width: isCollapsedSidebar
          ? "var(--_sidebar-collapsed)"
          : "var(--_sidebar-expanded)",
      }}
      whileHover={{
        width: "var(--_sidebar-expanded)",
      }}
      onPointerEnter={handlePointerEnter}
      onPointerLeave={handlePointerLeave}
    >
      <div className="absolute right-0 top-0 z-10">
        <SidebarToggleButton />
      </div>
      <SidebarHeader />

      <div className="flex-1 space-y-[var(--_sidebar-spacing)]">{children}</div>

      <SidebarFooter />
    </motion.nav>
  );
}

function SidebarHeader() {
  return (
    <div className="p-[var(--_sidebar-spacing)] flex gap-2 items-center relative min-h-[var(--_sidebar-header-height)] max-h-[var(--_sidebar-header-height)] shadow-xs">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="shrink-0 flex w-full justify-center p-8"
      >
        <Logo className="max-h-20" />
      </motion.div>
    </div>
  );
}

function SidebarFooter() {
  const { isExpanded } = useSidebar();

  const handleLogoutDashboard = async () => {
    try {
      // 🧹 Redux Persist clear
      await persistor.purge();

      // 🧹 LocalStorage clear
      localStorage.removeItem("accessToken");
      localStorage.removeItem("refreshToken");
      localStorage.removeItem("savedEmail");
      localStorage.removeItem("savedPassword");
      localStorage.removeItem("savedRememberMe");

      // 🧹 Backend cookies clear
      await fetch("/api/auth/logout", { method: "GET" });

      // 🚪 Redirect
      window.location.href = "/";
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  const { isCollapsedSidebar } = useSidebar();

  return (
    <div className="p-4">
      <div className="flex gap-2 items-center cursor-pointer text-primary xl:text-3xl md:text-2xl text-xl text-center"
        onClick={handleLogoutDashboard}
      >
        {
          isCollapsedSidebar ? (
            <LogOut className="size-4" />
          ) : (
            <div className="flex gap-2 text-xl text-center items-center">
              <LogOut className="size-4" />
              <h5 >Logout</h5>
            </div>
          )
        }
      </div>

      {isExpanded && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mt-2"
        ></motion.div>
      )}
    </div>
  );
}
export function SidebarToggleButton() {
  const { isExpanded, toggleSidebarCollapse } = useSidebar();
  return (
    <button className="p-1 cursor-pointer" onClick={toggleSidebarCollapse}>
      <ChevronsRight
        className={cn(
          "size-4 text-gray-500",
          isExpanded ? "-scale-100" : "scale-100"
        )}
      />
    </button>
  );
}
