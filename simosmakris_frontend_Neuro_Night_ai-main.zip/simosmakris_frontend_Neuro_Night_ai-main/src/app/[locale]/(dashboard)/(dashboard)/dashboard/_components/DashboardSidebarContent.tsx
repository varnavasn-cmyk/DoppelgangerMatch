"use client";

import { useSidebar } from "./SidebarProvider";
import { motion } from "framer-motion";
import DashboardActiveLink from "./DashboardActiveLink";
import { cn } from "@/lib/utils";

import {
  LayoutDashboard,
  CreditCard,
  Database,
  ScrollText,
  Users,
} from "lucide-react";
import { useAuth } from "@/components/AuthProvider";
import { dashboardNavigation } from "@/data/dashboardNavbar";

export type SidebarItemType = {
  name: string;
  href: string;
  icon: string;
  children?: SidebarItemType[];
};

type SidebarContentType = {
  mainItems: SidebarItemType[];
};

const icons = {
  layoutDashboardIcon: LayoutDashboard,
  databaseIcon: Database,
  blogIcon: ScrollText,
  planUpdateIcon: CreditCard,
  subscribeIcon: Users,
};

export default function SidebarContent({ mainItems }: SidebarContentType) {
  const auth = useAuth();
  console.log("auth: ", auth);

  let finalMainItems: SidebarItemType[] = [];

  if (auth?.user?.role === "SUPER_ADMIN" || "ADMIN") {
    finalMainItems = dashboardNavigation.admin;
  } else {
    finalMainItems = mainItems;
  }

  return (
    <div className="h-full flex flex-col justify-between gap-6 px-2">
      <ul className={cn("space-y-2")}>
        {finalMainItems.map((item) => {
          const Icon = icons[item.icon as keyof typeof icons];
          return (
            <li key={item.name} className="text-white hover:text-[#0F172A]">
              <DashboardActiveLink
                className={cn(
                  "flex items-center whitespace-nowrap h-10 font-semibold"
                )}
                href={item.href}
              >
                <span className="flex h-10 w-12 shrink-0 items-center justify-center">
                  <Icon className="size-4" />
                </span>
                <AnimatedLabel>
                  <span className="">{item.name}</span>
                </AnimatedLabel>
              </DashboardActiveLink>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

const animatedLabelVariants = {
  collapsed: {
    opacity: 0,
  },
  expanded: {
    opacity: 1,
  },
};

function AnimatedLabel({ children }: React.PropsWithChildren) {
  const { isExpanded } = useSidebar();

  return (
    isExpanded && (
      <motion.span
        variants={animatedLabelVariants}
        initial="collapsed"
        animate="expanded"
      >
        {children}
      </motion.span>
    )
  );
}
