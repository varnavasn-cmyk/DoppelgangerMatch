'use client';

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Upload } from 'lucide-react';
import { toast } from 'sonner';

interface UploadPopupProps {
  open: boolean;
  onClose: () => void;
  onUploadSuccess?: () => void;
}

const CelebrityLookaLikeImageUploadPopup: React.FC<UploadPopupProps> = ({ open, onClose, onUploadSuccess }) => {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [uploadedCount, setUploadedCount] = useState(0);

  useEffect(() => {
    if (open) {
      setUploadedCount(0);
      setProgress(0);
    }
  }, [open]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const allowedTypes = [
      'image/tiff',
      'image/webp',
      'image/jpg',
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/bmp',
    ];

    const invalidFiles = Array.from(files).filter(
      (file) => !allowedTypes.includes(file.type)
    );

    if (invalidFiles.length > 0) {
      toast.error('Some files have unsupported types');
      return;
    }

    const formData = new FormData();
    Array.from(files).forEach((file) => {
      formData.append('files', file);
    });
    formData.append('folder', 'celebritybucket');

    try {
      setUploading(true);
      setProgress(0);
      setUploadedCount(0);

      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/celebrity/add', true);

      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          const percentComplete = Math.min(
            10,
            Math.round((event.loaded / event.total) * 100)
          );
          setProgress(percentComplete);
        }
      };

      xhr.onload = () => {
        try {
          const data = JSON.parse(xhr.responseText);

          if (xhr.status === 200 && data?.status === 'success') {
            // Make sure the progress visually reaches 100%
            setProgress(100);

            toast.success('🎉 Image(s) uploaded successfully!');

            // Added: Trigger refresh after success (optimistic UI update)
            onUploadSuccess?.();

            setTimeout(() => {
              setUploadedCount(files.length);

              // Smooth close after 0.5s
              setTimeout(() => {
                setProgress(0);
                setUploadedCount(0);
                setUploading(false);
                onClose();
              }, 500);
            }, 400);
          } else if (xhr.status === 422 || data?.status === 'validation_Success') {
            setUploading(false);
            const validationMsg =
              data?.validation_results?.[0]?.message ||
              data?.message ||
              'Validation failed!';
            toast.error(`⚠️ ${validationMsg}`);
          } else {
            setUploading(false);
            toast.error(data?.message || 'Upload failed');
          }
        } catch (err) {
          console.error('Response parse error:', err);
          setUploading(false);
          toast.error('Invalid server response');
        }
      };
      xhr.onerror = () => {
        setUploading(false);
        toast.error('❌ Something went wrong during upload');
      };

      xhr.send(formData);
    } catch (err) {
      console.error(err);
      setUploading(false);
      toast.error('❌ Unexpected error occurred');
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          key="upload-popup"
          className="fixed inset-0 z-[999] flex items-center justify-center bg-black/50 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="relative w-full max-w-lg mx-auto bg-[#00FFFF]/10 rounded-2xl shadow-xl overflow-hidden"
          >
            <button
              onClick={onClose}
              disabled={uploading}
              className="absolute top-3 right-3 p-1 rounded-full hover:bg-white/10 disabled:opacity-50"
            >
              <X className="text-white" />
            </button>

            <div className="p-10 flex flex-col items-center justify-center text-center text-white min-h-[300px] w-full">
              <AnimatePresence mode="wait">
                {uploading ? (
                  <motion.div
                    key="progress-bar"
                    className="w-full flex flex-col items-center gap-4"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <p className="text-lg font-medium">
                      Uploading... {progress}%
                    </p>
                    <div className="w-full bg-white/20 rounded-full h-4 overflow-hidden">
                      <div
                        className="bg-[#00FFFFB2] h-4 transition-all duration-300 ease-in-out"
                        style={{ width: `${progress}%` }}
                      ></div>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="file-upload"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="flex flex-col items-center"
                  >
                    <Upload className="w-10 h-10 mb-3 text-white" />
                    <h2 className="text-2xl font-semibold mb-2">
                      Upload Image(s)
                    </h2>
                    <p className="text-sm mb-6">
                      Click to browse or drag multiple images here
                      <br />
                      Supports JPG, PNG, WebP, GIF, BMP, TIFF
                    </p>
                    <label
                      htmlFor="fileInput"
                      className="cursor-pointer px-5 py-3 bg-[#00FFFFB2] hover:bg-[#00FFFFB2]/90 rounded-lg font-medium text-white"
                    >
                      Choose Files
                    </label>
                    <input
                      id="fileInput"
                      type="file"
                      className="hidden"
                      multiple
                      accept=".jpg,.jpeg,.png,.webp,.gif,.bmp,.tiff"
                      onChange={handleFileChange}
                      disabled={uploading}
                    />
                    {uploadedCount > 0 && (
                      <p className="text-sm mt-3 text-green-300">
                        {uploadedCount} file(s) uploaded successfully
                      </p>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CelebrityLookaLikeImageUploadPopup;
