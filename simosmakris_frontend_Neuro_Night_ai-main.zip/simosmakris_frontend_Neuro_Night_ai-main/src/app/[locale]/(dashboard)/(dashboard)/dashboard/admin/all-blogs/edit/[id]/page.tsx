'use client';
import React from 'react';
import UpdateBlogForm from '../../_components/UpdateBlogForm';
import { useParams } from "next/navigation";

interface Params {
  [id: string]: string;
}

const UpdateBlogPage = () => {

  const { id } = useParams<Params>();

  return (
    <div>
      <UpdateBlogForm blogId={id} />
    </div>
  );
};

export default UpdateBlogPage; 
