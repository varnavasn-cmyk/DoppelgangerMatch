"use client"

import { AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"

interface DeleteUserModalProps {
  open: boolean
  onClose: () => void
  onConfirm: () => void
}

export default function CelebrityDeleteConfirmModal({ open, onClose, onConfirm }: DeleteUserModalProps) {
  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="w-full lg:max-w-xl md:max-w-lg max-w-xs rounded-2xl bg-white md:p-8 p-4 shadow-xl md:ml-0 ml-8">
        <h2 className="mb-4 text-center md:text-2xl text-lg font-bold text-black">Delete Photos</h2>

        <p className="mb-6 md:text-base text-xs text-black">
          Are you sure you want to delete this image?
          <br />
          This action cannot be undone.
        </p>

        <div className="mb-6 rounded-lg border-l-4 border-orange-600 bg-orange-50 p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-6 w-6 flex-shrink-0 text-orange-700" />
            <div>
              <h3 className="mb-1 md:text-lg text-sm font-semibold text-orange-900">Warning</h3>
              <p className="md:text-sm text-xs text-orange-700">By Deleting this photo, you won&apos;t be able to access the system.</p>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between gap-4">
          <Button
            onClick={onClose}
            className="rounded-lg bg-gray-900 px-6 py-2.5 md:text-base text-xs font-medium text-white hover:bg-gray-800"
          >
            No, Cancel
          </Button>
          <Button
            onClick={onConfirm}
            variant="outline"
            className="rounded-lg border-2 border-gray-900 bg-white px-6 py-2.5 md:text-base text-xs font-medium text-black hover:bg-gray-50 hover:text-red-500"
          >
            Yes, Delete
          </Button>
        </div>
      </div>
    </div>
  )
}
