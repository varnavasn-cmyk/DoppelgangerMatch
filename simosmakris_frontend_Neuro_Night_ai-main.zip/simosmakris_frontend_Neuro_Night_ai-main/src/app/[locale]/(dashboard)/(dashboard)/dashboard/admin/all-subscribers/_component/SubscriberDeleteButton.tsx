"use client";

import { Button } from "@/components/ui/button";
import { SquareMinus } from "lucide-react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";
import { toast } from "sonner";
import { env } from "@/env";
import DeleteModal from "@/components/shared/DeleteModal";
import { useState } from "react";

export default function SubscriberDeleteButton({ id }: { id: string }) {
  const router = useRouter();
  const { token } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const handleDelete = async () => {
    try {
      const res = await fetch(`${ env.NEXT_PUBLIC_API_URL }/subscriber/${ id }`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${ token }`,
        },
      });

      const data = await res.json();
      if (data.success) {
        toast.success("Subscriber removed successfully!");
        router.refresh();
      } else {
        toast.error("Failed to remove subscriber!");
      }
    } catch (error) {
      console.error(error);
      toast.error("An error occurred while removing subscriber.");
    } finally {
      setIsOpen(false);
    }
  };

  return (
    <>

      <Button
        variant="ghost"
        size="lg"
        onClick={() => setIsOpen(true)}
        className="text-red-500 hover:text-red-700"
      >
        <SquareMinus className="size-5" />
      </Button>

      <DeleteModal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onConfirm={handleDelete}
      />
    </>
  );
}
