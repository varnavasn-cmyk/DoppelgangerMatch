import React from "react";
import AllBlogContainerPage from "./_components/AllBlogContainer";

type AllBlogsPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

const AllBlogsPage = async ({ searchParams }: AllBlogsPageProps) => {
  const resolvedParams = await searchParams;

  return (
    <div>
      <AllBlogContainerPage searchParams={resolvedParams} />
    </div>
  );
};

export default AllBlogsPage;
