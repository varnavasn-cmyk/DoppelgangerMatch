export default function DashboardLayout({ children }: React.PropsWithChildren) {
  return <div className="common_dashboard_bg_color">{children}</div>;
}
