// import { NextResponse } from 'next/server';
// import { env } from 'process';


// export async function GET(
//   _req: Request,
//   { params }: { params: { id: string } }
// ) {
//   try {
//     const { id } = params;
//     if (!id) {
//       return NextResponse.json(
//         { success: false, message: 'Blog ID is required' },
//         { status: 400 }
//       );
//     }

//     const response = await fetch(`${env.NEXT_PUBLIC_BASE_URL}/blogs/${id}`, {
//       method: 'GET',
//       headers: { 'Content-Type': 'application/json' },
//       cache: 'no-store', // prevent caching stale data
//     });

//     const data = await response.json();

//     if (!response.ok || !data.success) {
//       return NextResponse.json(
//         { success: false, message: data?.message || 'Failed to fetch blog' },
//         { status: response.status }
//       );
//     }

//     return NextResponse.json(data);
//   } catch (error) {
//     console.error('❌ Error fetching blog:', error);
//     return NextResponse.json(
//       { success: false, message: 'Internal Server Error' },
//       { status: 500 }
//     );
//   }
// }

import { NextRequest, NextResponse } from "next/server";

export async function PATCH(request: NextRequest) {
  try {
    const url = new URL(request.url);
    const segments = url.pathname.split("/").filter(Boolean);
    const id = segments[segments.length - 1];

    const formData = await request.formData(); 

    const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/blogs/${id}`, {
      method: "PATCH",
      body: formData,
    });

    const data = await response.json();

    if (!response.ok || !data.success) {
      return NextResponse.json(
        { success: false, message: data?.message || "Failed to update blog" },
        { status: response.status }
      );
    }

    return NextResponse.json(data);
  } catch (error) {
    console.error("❌ Error updating blog:", error);
    return NextResponse.json(
      { success: false, message: "Internal Server Error" },
      { status: 500 }
    );
  }
}
