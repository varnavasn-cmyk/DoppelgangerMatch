"use server";


import { env } from "@/env";
import { cookies } from "next/headers";

export async function deleteBlogAction(id: string) {
  const cookieStore = cookies();
  const accessToken = (await cookieStore).get("accessToken")?.value;

  if (!accessToken) {
    throw new Error("You are not authorized to delete this blog");
  }

  const res = await fetch(`${env.API_BASE_URL}/blogs/delete-blog/${id}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
    cache: "no-store",
  });

  const data = await res.json();

  if (!res.ok) {
    throw new Error(data.message || "Failed to delete blog");
  }

  return data;
}
