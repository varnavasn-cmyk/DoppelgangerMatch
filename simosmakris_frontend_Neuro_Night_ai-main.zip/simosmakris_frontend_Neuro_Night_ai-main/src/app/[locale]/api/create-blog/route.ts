/* eslint-disable @typescript-eslint/no-explicit-any */
import { getServerAuth } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    
    const formData = await req.formData();
    
    const dataString = formData.get("data") as string | null;
    const file = formData.get("file") as File | null;

    if (!dataString || !file) {
      return NextResponse.json(
        { success: false, message: "Missing required fields" },
        { status: 400 }
      );
    }

    const parsedData = JSON.parse(dataString);
    console.log("📦 Parsed Data:", parsedData);

    const forwardFormData = new FormData();
    forwardFormData.append("data", JSON.stringify(parsedData));
    forwardFormData.append("file", file);

    const user = await getServerAuth();
    const token = user?.accessToken;

    if (!token) {
      return NextResponse.json(
        { success: false, message: "No token found" },
        { status: 401 }
      );
    }
    
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/blogs/create-blog`,
      {
        method: "POST",
        headers: {
          Authorization: `${token}`,
        },
        body: forwardFormData,
      }
    );

    const data = await res.json();

    if (!res.ok) {
      return NextResponse.json(data, { status: res.status });
    }

    return NextResponse.json(data, { status: 200 });
  } catch (error: any) {
    console.error("❌ API Proxy Error:", error);
    return NextResponse.json(
      { success: false, message: error.message || "Internal Server Error" },
      { status: 500 }
    );
  }
}
