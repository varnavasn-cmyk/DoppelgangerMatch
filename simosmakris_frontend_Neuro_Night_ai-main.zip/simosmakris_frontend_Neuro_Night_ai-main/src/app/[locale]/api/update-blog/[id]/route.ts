/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextRequest, NextResponse } from "next/server";
import { env } from "@/env";
import { getServerAuth } from "@/lib/auth";

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id: blogId } = await context.params;
    
    const formData = await req.formData();

    const title = formData.get("title") as string;
    const description = formData.get("description") as string;
    const file = formData.get("file") as File | null;

    const backendFormData = new FormData();
    backendFormData.append(
      "data",
      JSON.stringify({
        title,
        description,
      })
    );
    if (file) {
      backendFormData.append("file", file);
    }

    const token = await getServerAuth();

    if (!token) {
      return NextResponse.json(
        { success: false, message: "Unauthorized: No token found" },
        { status: 401 }
      );
    }

    const backendRes = await fetch(
      `${env.NEXT_PUBLIC_API_URL}/blogs/update-blog/${blogId}`,
      {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: backendFormData,
      }
    );

    const text = await backendRes.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error("Invalid JSON response from backend");
    }

    if (!backendRes.ok) {
      return NextResponse.json(
        { success: false, message: data?.message || "Update failed!" },
        { status: backendRes.status }
      );
    }

    return NextResponse.json(data);
  } catch (error: any) {
    console.error("❌ Update Blog Error:", error);
    return NextResponse.json(
      { success: false, message: error.message || "Something went wrong!" },
      { status: 500 }
    );
  }
}