"use server";

import { env } from "@/env";
import { getServerAuth } from "@/lib/auth";

export async function deleteCelebrityImagesAction(keys: string[]) {
  const accessToken = await getServerAuth();
  
  if (!accessToken) {
    throw new Error("You are not authorized to delete images");
  }

  if (!keys || !Array.isArray(keys) || keys.length === 0) {
    throw new Error("No image keys provided");
  }

  const res = await fetch(`${env.API_BASE_URL}/celebrity-database`, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
    body: JSON.stringify({ keys }),
    cache: "no-store",
  });

  const data = await res.json();

  if (!res.ok) {
    throw new Error(data?.message || "Failed to delete images");
  }

  return data;
}
