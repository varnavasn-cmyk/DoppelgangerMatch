import { env } from "@/env";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const formData = await req.formData();
    const files = formData.getAll("files") as File[];
    const folder = (formData.get("folder") as string) || "celebritybucket";

    if (!files || files.length === 0) {
      return NextResponse.json(
        { success: false, message: "No files provided" },
        { status: 400 }
      );
    }
    const uploadForm = new FormData();

    files.forEach((file) => {
      uploadForm.append("files", file);
    });

    uploadForm.append("folder", folder);

    const response = await fetch(`${env.API_AI_BASE_URL}/celebrity/add`, {
      method: "POST",
      body: uploadForm,
    });

    const body = await response.json();
    const { status, message } = body;

    if (!response.ok) {
      return NextResponse.json(
        { success: false, message: response.statusText },
        { status: response.status }
      );
    }

    if (status === "validation_Success") {
      return NextResponse.json(
        {
          success: false,
          message: body?.validation_results?.[0]?.message || message,
          details: body?.validation_results || [],
        },
        { status: 422 }
      );
    }

    if (status === "success") {
      return NextResponse.json(body, { status: 200 });
    }

    return NextResponse.json(
      { success: false, message: "Unexpected response from server" },
      { status: 500 }
    );
  } catch (error: unknown) {
    console.error("❌ Upload Error:", error);
    return NextResponse.json(
      { success: false, message: (error as Error).message },
      { status: 500 }
    );
  }
}
