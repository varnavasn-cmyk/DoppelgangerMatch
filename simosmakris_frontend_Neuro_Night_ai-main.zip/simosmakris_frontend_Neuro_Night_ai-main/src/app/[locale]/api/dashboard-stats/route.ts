/* eslint-disable @typescript-eslint/no-explicit-any */
import { env } from '@/env';
import { getServerAuth } from '@/lib/auth';
import { NextResponse } from 'next/server';

export async function GET() {
  const authData = await getServerAuth();
  const token = authData?.accessToken;
  
  
  if (!token) {
    return NextResponse.json(
      { error: "No authentication token found" }, 
      { status: 401 }
    );
  }

  try {    
    const res = await fetch(
      `${env.API_BASE_URL}/users/count-total-data`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}` // Fixed typo: was "AAuthorization"
        },
        cache: "no-store",
      }
    );

    if (!res.ok) {
      const errorText = await res.text();
      throw new Error(`API returned ${res.status}: ${errorText}`);
    }

    const data = await res.json();
    
    return NextResponse.json(data);
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Failed to fetch dashboard stats" },
      { status: 500 }
    );
  }
}