import { NextResponse } from "next/server";
import { env } from "process";


export async function POST(req: Request) {
  try {
    const formData = await req.formData();
    const files = formData.getAll("files") as File[];
    const folder = formData.get("folder") as string | null;

    if (!files || !folder) {
      return NextResponse.json(
        { success: false, message: "No files provided" },
        { status: 400 }
      );
    }

    const uploadForm = new FormData();
    files.forEach((file) => {
      uploadForm.append("files", file);
    }) 

    uploadForm.append("folder", folder);
    

    const response = await fetch(`${env.API_AI_BASE_URL}/normal/add`, {
      method: "POST",
      body: uploadForm,
    });
    console.log("Normal Image Files: ", response);

    const body = await response.json().catch(() => null);

    if (!response.ok) {
      return NextResponse.json(
        body ?? { success: false, message: response.statusText },
        { status: response.status }
      );
    }

    return NextResponse.json(body, { status: 200 });
  } catch (error: unknown) {
    console.error("Upload Error:", error);
    return NextResponse.json(
      { success: false, message: (error as Error).message },
      { status: 500 }
    );
  }
}
