import { env } from "@/env";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const { email } = await request.json();

    const response = await fetch(`${env.API_BASE_URL}/auth/forgot-password`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });

    const body = await response.json().catch(() => null);

    if (!response.ok) {
      return NextResponse.json(
        body ?? { success: false, message: response.statusText },
        { status: response.status }
      );
    }
    
    return NextResponse.json(body, { status: 200 });
  } catch (error: unknown) {
    console.error("Forgot Password Error:", error);

    return NextResponse.json(
      { success: false, message: (error as Error).message },
      { status: 500 }
    );
  }
}
