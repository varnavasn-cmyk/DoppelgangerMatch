// import { cookies } from "next/headers";
// import { NextResponse } from "next/server";

// export async function GET(req: Request, { params }: { params: { locale: string } }) {
//   const { searchParams } = new URL(req.url);
//   const token = searchParams.get("token");
//   const locale = params.locale;

//   if (!token) {
//     return NextResponse.redirect(new URL(`/${locale}/error`, req.url));
//   }

//   (await cookies()).set({
//     name: "access_token",
//     value: token,
//     httpOnly: true,
//     secure: process.env.NODE_ENV === "production",
//     path: "/",
//     sameSite: "lax",
//     maxAge: 7 * 24 * 60 * 60,
//   });

//   await (localStorage as Storage).setItem("access_token", token);

//   return NextResponse.redirect(new URL(`/${locale}`, req.url));
// }


import { cookies } from "next/headers";
import { NextResponse } from "next/server";

export async function GET(
  req: Request, 
  { params }: { params: { locale: string } }
) {
  const { searchParams } = new URL(req.url);
  const token = searchParams.get("token");
  const locale = params.locale;
  console.log("Search Token:", token);

  if (!token) {
    return NextResponse.redirect(new URL(`/${locale}/error`, req.url));
  }

  // Cookie set করুন
  (await cookies()).set({
    name: "access_token",
    value: token,
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    path: "/",
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60,
  });

  // localStorage এ set করার জন্য একটি intermediate page এ redirect করুন
  // যেখানে client-side script token টি localStorage এ save করবে
  const redirectUrl = new URL(`/${locale}/auth/callback`, req.url);
  redirectUrl.searchParams.set("token", token);
  
  return NextResponse.redirect(redirectUrl);
}