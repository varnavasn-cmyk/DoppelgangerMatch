"use server";

import { env } from "@/env";
import { getServerAuth } from "@/lib/auth";

export async function deleteUserAction(userId: string) {
  const user = await getServerAuth();

  const accessToken = user?.accessToken;
  if (!accessToken) {
    throw new Error("Unauthorized");
  }

  const res = await fetch(`${env.API_BASE_URL}/users/${userId}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
    cache: "no-store",
  });

  const data = await res.json();

  if (!res.ok) {
    throw new Error(data?.message || "Failed to delete user");
  }

  return data;
}
