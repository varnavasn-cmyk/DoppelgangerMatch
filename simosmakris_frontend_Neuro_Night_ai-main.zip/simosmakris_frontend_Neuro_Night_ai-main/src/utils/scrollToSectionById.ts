// "use client";

// import { useRouter } from "next/navigation";

// // for single page navigation
// // use:
// // const handleScrollToSubscription = () => {
// //   scrollToSection("sales-benefits");
// // };

// export const scrollToSection = (sectionId: string) => {
//   const section = document.getElementById(sectionId);
//   if (section) {
//     section.scrollIntoView({ behavior: "smooth" });
//   }
// };

// // for different page navigation
// // use:
// //  const ScrollToSectionOnPage = useScrollToSectionOnPage();
// //   const handleScrollToSubscription = () => {
// //     ScrollToSectionOnPage("/", "sales-benefits");
// //   };

// export const useScrollToSectionOnPage = () => {
//   const router = useRouter();

//   const scrollToSectionOnPage = (path: string, sectionId: string) => {
//     // Navigate to the desired path with query parameter
//     router.push(`${path}?sectionId=${sectionId}`);

//     setTimeout(() => {
//       const section = document.getElementById(sectionId);
//       if (section) {
//         section.scrollIntoView({ behavior: "smooth" });
//       }
//     }, 200);
//   };

//   return scrollToSectionOnPage;
// };

"use client";

import { usePrefixedPath } from "@/lib/localePath";
import { useRouter, usePathname } from "next/navigation";
import { useEffect } from "react";

// ------------------------------------
// Single Page Scroll
// ------------------------------------
export const scrollToSection = (sectionId: string) => {
  if (typeof document === "undefined") return; // SSR-safe

  const section = document.getElementById(sectionId);
  if (section) {
    section.scrollIntoView({ behavior: "smooth" });
  }
};

// ------------------------------------
// Cross-Page Scroll Hook
// ------------------------------------
export const useScrollToSectionOnPage = () => {
  const router = useRouter();
  const pathname = usePathname();
    const getPrefixedPath = usePrefixedPath();

  const scrollToSectionOnPage = (path: string, sectionId: string) => {
    if (typeof window === "undefined") return;

    // If already on the target page
    if (pathname === path) {
      setTimeout(() => {
        const section = document.getElementById(sectionId);
        if (section) {
          section.scrollIntoView({ behavior: "smooth" });
        }
      }, 100); // slight delay to ensure DOM is ready
    } else {
      // Navigate to the page with section query
      router.push(getPrefixedPath(`${path}?sectionId=${sectionId}`));
    }
  };

  // Auto-scroll if query param exists
  useEffect(() => {
    if (typeof window === "undefined") return;

    const params = new URLSearchParams(window.location.search);
    const sectionId = params.get("sectionId");
    if (sectionId) {
      setTimeout(() => {
        const section = document.getElementById(sectionId);
        if (section) {
          section.scrollIntoView({ behavior: "smooth" });
        }
      }, 100);
    }
  }, [pathname]);

  return scrollToSectionOnPage;
};
