// utils/cookieHelper.ts
import { setCookie, getCookie, deleteCookie } from 'cookies-next';

export interface UserData {
  userId: string | undefined;
  visitCount: string | undefined;
  lastVisit: string | undefined;
  sessionStart: string | undefined;
}

// ইউজার আইডি সেভ করুন
export function saveUserId(userId: string): void {
  setCookie('user_id', userId, {
    maxAge: 365 * 24 * 60 * 60, // ১ বছর
    path: '/',
    sameSite: 'lax'
  });
}

// ইউজার আইডি পান
export function getUserId(): string | undefined {
  const userId = getCookie('user_id');
  return userId?.toString();
}

// ভিজিট কাউন্ট ট্র্যাক করুন
export function trackVisit(): number {
  const visits = getCookie('visit_count');
  const currentCount = visits ? parseInt(visits.toString()) : 0;
  const newCount = currentCount + 1;
  
  setCookie('visit_count', newCount.toString(), {
    maxAge: 30 * 24 * 60 * 60, // ৩০ দিন
    path: '/'
  });
  
  return newCount;
}

// শেষ ভিজিট সময় সেভ করুন
export function saveLastVisit(): string {
  const now = new Date().toISOString();
  setCookie('last_visit', now, {
    maxAge: 365 * 24 * 60 * 60,
    path: '/'
  });
  return now;
}

// সেশন শুরু সময় সেভ করুন
export function saveSessionStart(): string {
  const now = new Date().toISOString();
  setCookie('session_start', now, {
    maxAge: 30 * 60, // ৩০ মিনিট
    path: '/'
  });
  return now;
}

// সেশন শুরু সময় পান
export function getSessionStart(): string | undefined {
  const session = getCookie('session_start');
  return session?.toString();
}

// পেজ ভিউ ট্র্যাক করুন
export function trackPageView(pageName: string): void {
  const pageViews = getCookie('page_views');
  let views: Record<string, number> = {};
  
  if (pageViews) {
    try {
      views = JSON.parse(pageViews.toString());
    } catch {
      views = {};
    }
  }
  
  views[pageName] = (views[pageName] || 0) + 1;
  
  setCookie('page_views', JSON.stringify(views), {
    maxAge: 30 * 24 * 60 * 60,
    path: '/'
  });
}

// সব পেজ ভিউ পান
export function getPageViews(): Record<string, number> | null {
  const pageViews = getCookie('page_views');
  if (!pageViews) return null;
  
  try {
    return JSON.parse(pageViews.toString());
  } catch {
    return null;
  }
}

// সব ইউজার ডাটা পান
export function getAllUserData(): UserData {
  return {
    userId: getCookie('user_id')?.toString(),
    visitCount: getCookie('visit_count')?.toString(),
    lastVisit: getCookie('last_visit')?.toString(),
    sessionStart: getCookie('session_start')?.toString()
  };
}

// সব cookie মুছে ফেলুন
export function clearAllCookies(): void {
  deleteCookie('user_id');
  deleteCookie('visit_count');
  deleteCookie('last_visit');
  deleteCookie('session_start');
  deleteCookie('page_views');
}

// Unique ID জেনারেট করুন
export function generateUserId(): string {
  return 'user_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
}