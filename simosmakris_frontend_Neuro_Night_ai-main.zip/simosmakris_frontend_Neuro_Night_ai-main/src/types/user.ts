/* eslint-disable @typescript-eslint/no-explicit-any */
export type UserToken = {
  id: string;
  fullName: string;
  email: string;
  role: "SUPER_ADMIN" | "ADMIN" | "USER";
  isVerified: boolean;
  iat: number;
  exp: number;
};

export type AuthMe = {
  success: boolean;
  message: string; 
  accessToken: string;
  data: {
    id: string;
    fullName: string;
    email: string;
    profilePic: string;
    isVerified: boolean;
    role: "SUPER_ADMIN" | "ADMIN" | "USER";
    isSubscribed: boolean;
    planExpiration: string | Date | any;
    isResentOtp: boolean;
  };
};

export type Me = {
    id: string;
    fullName: string;
    email: string;
    profilePic: string;
    isVerified: boolean;
    role: "SUPER_ADMIN" | "ADMIN" | "USER";
    isSubscribed: boolean;
    planExpiration: string | Date | any;
    isResentOtp: boolean;
  }