// utils/uploadLimit.ts
export const MAX_FREE_UPLOADS = 3;

export const getGuestUploadCount = () => {
  if (typeof window === "undefined") return 0;
  const count = localStorage.getItem("guest_upload_count");
  return count ? parseInt(count, 10) : 0;
};

export const incrementGuestUploadCount = () => {
  if (typeof window === "undefined") return;
  const count = getGuestUploadCount();
  localStorage.setItem("guest_upload_count", String(count + 1));
};

export const canGuestUpload = () => {
  return getGuestUploadCount() < MAX_FREE_UPLOADS;
};