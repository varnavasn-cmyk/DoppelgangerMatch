// lib/locale.ts
import { getLocale } from "next-intl/server";
import { useLocale } from "next-intl";



// ✅ Server-side helper (async)
export async function prefixLocalePath(path: string): Promise<string> {
  const locale = await getLocale();
  return `/${locale}${path.startsWith("/") ? path : `/${path}`}`;
}

// ✅ Client-side hook (safe for components)
export function usePrefixedPath(): (path: string) => string {
  const locale = useLocale();
  return (path: string) =>
    `/${locale}${path.startsWith("/") ? path : `/${path}`}`;
}
