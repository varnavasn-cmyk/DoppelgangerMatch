
import { z } from "zod";
import { createEnv } from '@t3-oss/env-nextjs';

export const env = createEnv({
  server: {
    API_BASE_URL: z.string().url(),
    API_AI_BASE_URL: z.string().url(),
  },
  client: {
    NEXT_PUBLIC_API_URL: z.string().url(),
    NEXT_PUBLIC_APP_NAME: z.string().min(1),
    NEXT_PUBLIC_APP_ENV: z.enum(["development", "production", "test"]),
    NEXT_PUBLIC_APP_URL: z.string().url().min(1),
  },
  runtimeEnv: {
    API_BASE_URL: process.env.API_BASE_URL,
    API_AI_BASE_URL: process.env.API_AI_BASE_URL,
    
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL,
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
    NEXT_PUBLIC_APP_NAME: process.env.NEXT_PUBLIC_APP_NAME,
    NEXT_PUBLIC_APP_ENV: process.env.NEXT_PUBLIC_APP_ENV,
  },
});
