import * as paths from "@/paths";

export const dashboardNavigation = {
  admin: [
    {
      name: "Overview",
      icon: "layoutDashboardIcon",
      href: paths.adminDashboardPath(),
    },
    {
      name: "Database",
      icon: "databaseIcon",
      href: paths.adminDashboardDatabasePath(),
    },
    {
      name: "Create Blog",
      icon: "blogIcon",
      href: paths.adminDashboardCreateBlogPath(),
    },
    {
      name: "All Blogs",
      icon: "blogIcon",
      href: paths.adminDashboardAllBlogsPath(),
    },
    {
      name: "All Subscribers",
      icon: "subscribeIcon",
      href: paths.adminDashboardAllSubscribersPath(),
    },
    {
      name: "Plan Update",
      icon: "planUpdateIcon",
      href: paths.adminDashboardPlanUpdatePath(),
    },
  ],
  
  
};
